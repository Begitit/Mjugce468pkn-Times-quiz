// ---------- localStorage keys (unchanged from prior versions — do not rename) ----------
export const UNLOCK_KEY = "tt_unlocked";
export const APP_PASSCODE = "VeggiesNotsugar";
export const TEACHER_PASSCODE = "Deletesugar";
export const USERS_KEY = "times-tables-users-v1";
export const stateKey = (u) => `times-tables-state-v1:${u}`;
export const logKey = (u) => `times-tables-log-v1:${u}`;
export const masteryKey = (u) => `times-tables-mastery-v1:${u}`;

export const QUIZ_LENGTH_PRESETS = [10, 20, 50];
export const LADDER_LENGTH_PRESETS = [10, 20];
export const AVG_HISTORY_COUNT = 6;

export const DEFAULT_QUIZ_SETTINGS = {
  operation: "mult",
  order: "sequential",
  answerMode: "mc",
  start: 1,
  end: 10,
  length: 20,
  excludeEasy: false,
  excludeEasyMode: "auto",
  speedMode: "normal",
  divideSymbols: ["obelus"],
};

export const DEFAULT_LADDER_SETTINGS = {
  operation: "mult",
  start: 1,
  end: 10,
  practiceStart: 1,
  length: 20,
  excludeEasy: false,
  excludeEasyMode: "auto",
  speedMode: "normal",
  divideSymbols: ["obelus"],
};

// The four ways a division fact can be displayed to the child. "obelus"
// (÷) is the default and the only one selected out of the box; a kid who
// hasn't seen fraction notation or long-division brackets yet won't be
// confused by a question using them unless a parent/teacher turns that
// symbol on deliberately. When more than one is selected, one is picked
// at random per division question. render(a, b) returns a plain-text
// form (a = dividend, b = divisor) for contexts that need a string, not
// JSX (e.g. the missed-facts log stays on canonical "÷" regardless —
// see app.jsx submitAnswer/advanceAfterAnswer, which doesn't call this).
export const DIVIDE_SYMBOLS = [
  { key: "obelus", label: "Divide sign", render: (a, b) => `${a} \u00F7 ${b}` },
  { key: "slash", label: "Slash", render: (a, b) => `${a} / ${b}` },
  { key: "fraction", label: "Fraction bar", render: (a, b) => `${a}/${b}` },
  { key: "bracket", label: "Long division sign", render: (a, b) => `${b}\u27CC${a}` },
];

// Challenge Tests has no Range/Operation/etc. controls of its own (the
// pool is fixed by the level chosen) — Speed is the only setting it
// needs, so this is deliberately minimal rather than reusing the full
// quiz/ladder settings shape.
export const DEFAULT_CHALLENGE_SETTINGS = {
  speedMode: "normal",
};

// Exclude Easy's "Auto" behavior: off for any range that touches 1-10
// (beginners still need 1s/10s drilled), on once the whole range is 11+.
export function autoExcludeEasy(start, end) {
  return Math.min(start, end) > 10;
}

// The highest partner number a ladder mastery test actually reaches, once
// Exclude Easy is applied — e.g. End=10 with Exclude Easy on only reaches 9,
// same as End=9. Used to catch a range that's too small to count, instead
// of checking the raw End value (which misses that case).
export function highestPartnerReached(end, excludeEasy) {
  const nums = fullToNumbers(end, excludeEasy);
  return nums.length ? nums[nums.length - 1] : 0;
}

export const DEFAULT_GLOBAL_SETTINGS = {
  dropWorstScore: false,
  slowThresholdSeconds: 5,
};

// Only usernames matching BD followed by a number (optionally spaced,
// e.g. "BD33", "BD 10") ever see the developer settings-preview toggle.
export function isDevUser(name) {
  return typeof name === "string" && /^BD[\s-]*\d+$/i.test(name.trim());
}

export const DEFAULT_LADDER = {
  currentNumber: null,
  mastered: [],
  masteredEnd: {},
  tempMastered: [],
  tempMasteredEnd: 0,
  seqCursor: {},
  lastMode: "mc-seq",
  excludeMastered: false,
};

// Older saved ladder states may predate the excludeMastered field, which left
// neither Practice-Facts button highlighted. Normalize on every load.
export function normalizeLadder(s) {
  if (!s) return { ...DEFAULT_LADDER };
  return { ...DEFAULT_LADDER, ...s, excludeMastered: s.excludeMastered === true };
}

// An End of 10, 12, or 20 is a recognized milestone width — a pass under
// any other End (including anything 9 or below) is provisional/"short"
// (yellow) rather than a real, permanent title-earning pass (green).
export function isCanonicalEnd(end) {
  return end === 10 || end === 12 || end === 20;
}
// v49 (audit item 4): a Test ALL pass rounds the End DOWN to the nearest
// standard End: 9 or lower -> null (yellow / practice), 10-11 -> 10,
// 12-19 -> 12, 20 -> 20. The rounded End is what gets recorded and shown.
export function passEndFor(end) {
  if (end >= 20) return 20;
  if (end >= 12) return 12;
  if (end >= 10) return 10;
  return null;
}

// Returns the title info for ladder step number n, given the End it was
// (or would be) earned under. Returns null when no canonical title
// applies at that number/End combination (13-19 need End=20; 11-12 need
// End=12 or 20 specifically). `bare` is used for milestone buttons and
// tier-start numbers; `numbered` is used for the current-title display.
export function titleForNumber(n, endUsed) {
  if (n >= 1 && n <= 4) return { bare: `Math Learner ${n}`, numbered: `Math Learner ${n}` };
  if (n === 5) return { bare: "Junior Math Wiz", numbered: "Junior Math Wiz" };
  if (n >= 6 && n <= 9) return { bare: "Junior Math Wiz", numbered: `Jr. Math Wiz ${n}` };
  if (n === 10) return { bare: "Math Wiz!", numbered: "Math Wiz!" };
  if (n === 11 || n === 12) {
    if (endUsed === 20) return { bare: "Royal Math Wiz", numbered: `Royal Math Wiz ${n}` };
    if (endUsed === 12) return { bare: "Senior Math Wiz", numbered: `Senior Math Wiz ${n}` };
    return null;
  }
  if ((n === 13 || n === 14) && endUsed === 20) return { bare: "Royal Math Wiz", numbered: `Royal Math Wiz ${n}` };
  if (n >= 15 && n <= 19 && endUsed === 20) {
    return n === 15 ? { bare: "Crown Math Wiz", numbered: "Crown Math Wiz" } : { bare: "Crown Math Wiz", numbered: `Crown Math Wiz ${n}` };
  }
  if (n === 20) return { bare: "Math Wiz King", numbered: "Math Wiz King" };
  return null;
}

// ---------- storage I/O ----------
async function readJSON(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
async function writeJSON(key, value) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

export const loadUsers = () => readJSON(USERS_KEY, { names: [], lastUser: null });
export const saveUsers = (v) => writeJSON(USERS_KEY, v);
export const loadState = (u) => readJSON(stateKey(u), null);
export const saveState = (u, v) => writeJSON(stateKey(u), v);
export const loadLog = (u) => readJSON(logKey(u), []);
export const saveLog = (u, v) => writeJSON(logKey(u), v);
export const loadMastery = (u) => readJSON(masteryKey(u), null);
export const saveMastery = (u, v) => writeJSON(masteryKey(u), v);
export async function deleteUserData(u) {
  try { window.localStorage.removeItem(stateKey(u)); } catch {}
  try { window.localStorage.removeItem(logKey(u)); } catch {}
  try { window.localStorage.removeItem(masteryKey(u)); } catch {}
  try { window.localStorage.removeItem(introKey(u)); } catch {}
}

// v45: how many times the intro has been shown to a user (per user, counted
// once each time the app is opened). Not included in Backup files.
export const introKey = (u) => `times-tables-intro-v1:${u}`;
export function readIntroCount(u) {
  try { const n = parseInt(window.localStorage.getItem(introKey(u)), 10); return Number.isFinite(n) ? n : 0; } catch { return 0; }
}
export function writeIntroCount(u, n) {
  try { window.localStorage.setItem(introKey(u), String(n)); } catch {}
}

// v45: the user's current title (same rule as the header): two chains,
// Chain B (11–20) outranks Chain A once it has begun; a tie at 11/12 shows
// the Royal form. Used by the header and to spot a NEW title on a pass.
// v49: chain B (Royal/Crown/King) wins whenever it has begun; it only
// counts numbers passed at End 20. Chain A (Learner..Senior) counts 11 and
// 12 only when passed at End 12 or more, and its 11/12 title is always the
// Senior form (the old Royal tie-break is gone — audit items 1 and 5a).
export function currentTitleFor(mastered, masteredEnd) {
  const { chainAHighest, chainBHighest } = chainHighestReached(mastered, masteredEnd);
  if (chainBHighest != null) return titleForNumber(chainBHighest, 20)?.numbered ?? null;
  if (chainAHighest == null) return null;
  return titleForNumber(chainAHighest, chainAHighest >= 11 ? 12 : 10)?.numbered ?? null;
}

// ---------- helpers ----------
export function shuffle(arr) {
  const t = arr.slice();
  for (let i = t.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [t[i], t[j]] = [t[j], t[i]];
  }
  return t;
}

export function rangeNumbers(start, end, excludeEasy) {
  const lo = Math.min(start, end), hi = Math.max(start, end);
  const out = [];
  for (let n = lo; n <= hi; n++) if (!excludeEasy || (n !== 1 && n !== 10)) out.push(n);
  return out;
}

export function fullToNumbers(end, excludeEasy) {
  return rangeNumbers(1, end, excludeEasy);
}

// The ladder's step list spans the tab's own Start–End, unlike a per-number
// practice pool, which always draws partners from 1..End regardless of Start.
export function ladderStepNumbers(settings) {
  return rangeNumbers(settings.start, settings.end, settings.excludeEasy);
}

// Numbers shown as ladder steps: everything in the current range, plus any
// number the user has ever mastered (even if it now falls outside the
// range) so mastery is never lost from view, sorted ascending.
export function ladderDisplayNumbers(settings, masteredList) {
  const inRange = ladderStepNumbers(settings);
  const union = new Set([...inRange, ...(masteredList || [])]);
  return Array.from(union).sort((a, b) => a - b);
}

// Full pool for the Quizzes tab: every ordered pair within [start,end].
export function fullRangePool({ operation, start, end, excludeEasy }) {
  const nums = rangeNumbers(start, end, excludeEasy);
  const facts = [];
  nums.forEach((a) => {
    nums.forEach((b) => {
      if (operation === "mult" || operation === "both") {
        facts.push({ op: "×", a, b, answer: a * b, key: `m-${a}-${b}` });
      }
      if (operation === "div" || operation === "both") {
        const prod = a * b;
        facts.push({ op: "÷", a: prod, b: a, answer: b, key: `d-${a}-${b}` });
      }
    });
  });
  return facts;
}

export function quizAllCount(settings) {
  return fullRangePool(settings).length;
}

// Per-number pool for the Ladder tab: the selected number against 1..end.
// ---------- Facts Passed Rule (v44) ----------
// A fact counts as passed if either of its two numbers was passed (green
// only — yellow never counts) with an End that reaches the other number.
// Worked out on demand from ladder.mastered + ladder.masteredEnd; the app
// does not track individual facts. A mastered number with no recorded End
// (very old data) falls back to its Challenge band's End.
// Known gap: only the End is saved, not whether SKIP was on, so ×1/×10
// facts of a number passed with SKIP on count as passed though never asked.
export function passedEndOf(n, mastered, masteredEnd) {
  if (!mastered || !mastered.includes(n)) return null;
  const e = masteredEnd && masteredEnd[n];
  return e != null ? e : challengeMasteredEnd(n);
}
export function factPassed(x, y, mastered, masteredEnd) {
  const ex = passedEndOf(x, mastered, masteredEnd);
  if (ex != null && ex >= y) return true;
  const ey = passedEndOf(y, mastered, masteredEnd);
  return ey != null && ey >= x;
}
// The two numbers a fact is "about": × → its factors; ÷ → divisor and quotient.
export function factNumbers(f) {
  return f.op === "×" ? [f.a, f.b] : [f.b, f.answer];
}
// Misses allowed on a pass attempt: 1 per FULL 100 questions
// (under 100 → 0, 100–199 → 1, 200–299 → 2).
export function allowedMisses(totalQuestions) {
  return Math.floor(totalQuestions / 100);
}

export function numberPool(number, { operation, end, excludeEasy }) {
  const partners = fullToNumbers(end, excludeEasy);
  const facts = [];
  partners.forEach((n) => {
    if (operation === "mult" || operation === "both") {
      facts.push({ op: "×", a: number, b: n, answer: number * n, key: `m-${number}-${n}`, partner: n });
    }
    if (operation === "div" || operation === "both") {
      const prod = number * n;
      facts.push({ op: "÷", a: prod, b: number, answer: n, key: `d-${number}-${n}`, partner: n });
      if (n !== number) {
        facts.push({ op: "÷", a: prod, b: n, answer: number, key: `d2-${number}-${n}`, partner: n });
      }
    }
  });
  return facts;
}

// Every fact for a number, ignoring the operation/practice-facts settings —
// what the pass test tests (both operations, every fact). Before v42 this
// was "type-random"; since v42 it's the separate "type-test" mode
// (Type In · Random · Test ALL, Ladder only) and type-random is practice.
// v49 (audit item 2, choice B): Test ALL on numbers 1-10 always includes
// the 1 and 10 partners (×1, ×10, ÷1, ÷10), whatever SKIP is set to, so an
// End 10 + SKIP On pass is a true green. SKIP still applies to 11 and up.
export function masteryTestPool(number, settings) {
  const excludeEasy = number <= 10 ? false : settings.excludeEasy;
  return numberPool(number, { ...settings, excludeEasy, operation: "both" });
}

// v44: is this Test ALL an upgrade test? — the number is already passed
// (green) and the current End is a canonical End bigger than the End it
// was passed with (e.g. Senior 12 at End 12 → Royal 12 at End 20).
export function isUpgradeTest(number, settings, progress) {
  if (number == null || !progress) return false;
  const old = passedEndOf(number, progress.mastered, progress.masteredEnd);
  const rounded = passEndFor(settings.end);
  return old != null && rounded != null && rounded > old;
}
// v44: the Test ALL pool. Unpassed number → every fact (unchanged).
// Upgrade test → only the facts not yet passed under the Facts Passed Rule.
// v52: a number green at 12 with NO yellow, tested at End 13-19, is a real
// pass attempt for the yellow pill (handled like yellow attempts in 1-10).
// Like an upgrade test it asks only the facts not yet passed (the ×13…×End
// ones). Already yellow → practice only (v49 choice A).
export function isYellowAboveAttempt(number, settings, progress) {
  if (number == null || !progress || !yellowAboveTwelve(settings.end)) return false;
  if ((progress.tempMastered || []).includes(number)) return false;
  return passedEndOf(number, progress.mastered, progress.masteredEnd) === 12;
}
export function ladderTestPool(number, settings, progress) {
  const pool = masteryTestPool(number, settings);
  if (!isUpgradeTest(number, settings, progress) && !isYellowAboveAttempt(number, settings, progress)) return pool;
  return pool.filter((f) => !factPassed(number, f.partner, progress.mastered, progress.masteredEnd));
}
// v44: New Facts Only uses the Facts Passed Rule (was: skip a fact if its
// partner number is passed, ignoring End).
function newFactsOnly(pool, number, progress) {
  return pool.filter((f) => !factPassed(number, f.partner, progress.mastered || [], progress.masteredEnd || {}));
}

// v51: Practice Start (Ladder only) — where the partners of a PRACTICE
// quiz begin (e.g. Practice Start 9 → the 12s ask 12×9…12×End and the
// matching divides). Never more than the End; Test ALL ignores it.
export function practiceStartOf(settings) {
  const hi = Math.max(settings.start, settings.end);
  const ps = Number.isFinite(settings.practiceStart) ? settings.practiceStart : 1;
  return Math.max(1, Math.min(hi, ps));
}
export function practicePool(number, settings) {
  const ps = practiceStartOf(settings);
  const pool = numberPool(number, settings);
  return ps <= 1 ? pool : pool.filter((f) => f.partner >= ps);
}
// v51: extra answer time for longer Type In answers on Fast / Fastest
// (Normal never gets any): +0.5 s for 2 digits, +1 s for 3 or more.
export function extraTimeMs(answer, speedMode, answerMode) {
  if (answerMode !== "type" || !speedMode || speedMode === "normal") return 0;
  const digits = String(Math.abs(answer)).length;
  return digits >= 3 ? 1000 : digits === 2 ? 500 : 0;
}
// v51: a pass at End 13-19 is green at 12 AND a yellow badge for the End
// actually reached ("Yellow above 12").
export function yellowAboveTwelve(end) {
  return end >= 13 && end <= 19;
}

export function ladderAllCount(number, mode, settings, excludeMastered, progress) {
  if (number == null) return 0;
  if (mode === "type-test") return ladderTestPool(number, settings, progress).length;
  let pool = practicePool(number, settings);
  if (excludeMastered) pool = newFactsOnly(pool, number, progress);
  return pool.length;
}

function withDisplay(facts, order) {
  const ordered = order === "random" ? shuffle(facts) : facts;
  return ordered.map((f, i) => ({ ...f, id: `${i}-${f.key}`, isRepeat: false }));
}

// Cycles through `pool` starting at `cursor`, producing exactly `length`
// questions (wrapping/repeating if length exceeds the pool size).
function cyclingQueue(pool, order, length, cursor = 0) {
  if (pool.length === 0) return { queue: [], nextCursor: 0 };
  let source, start;
  if (order === "random") {
    source = shuffle(pool);
    start = 0;
  } else {
    source = pool;
    start = cursor % pool.length;
  }
  const out = [];
  for (let i = 0; i < length; i++) {
    out.push({ ...source[(start + i) % source.length], id: `${i}-${source[(start + i) % source.length].key}`, isRepeat: false });
  }
  return { queue: out, nextCursor: order === "random" ? 0 : (start + length) % source.length };
}

export function poolSignature(settings) {
  const lo = Math.min(settings.start, settings.end), hi = Math.max(settings.start, settings.end);
  return `${settings.operation}|${lo}|${hi}|${settings.excludeEasy}`;
}

// Builds the Quizzes-tab queue. Handles the "ALL" length specially: one pass
// over the whole pool, no repeats, instead of the cycling/wrap behavior used
// for fixed lengths.
export function buildQuizQueue(settings, cursor = 0) {
  const pool = fullRangePool(settings);
  if (settings.length === "ALL") {
    return { queue: withDisplay(pool, settings.order), nextCursor: 0 };
  }
  return cyclingQueue(pool, settings.order, settings.length, cursor);
}

// Builds a Ladder-tab practice queue for a given number + mode, respecting
// the Practice Facts (excludeMastered) setting. Type In · Random always uses
// every fact for the number, regardless of length, operation, or practice
// facts settings (matches existing mastery-test behavior).
export function buildLadderQueue(number, mode, settings, cursor, excludeMastered, progress) {
  const order = ladderModeOrder(mode);
  if (mode === "type-test") {
    const pool = ladderTestPool(number, settings, progress);
    return { queue: withDisplay(pool, order), nextCursor: null };
  }
  let pool = practicePool(number, settings);
  if (excludeMastered) pool = newFactsOnly(pool, number, progress);
  if (pool.length === 0) return { queue: [], nextCursor: cursor };
  if (settings.length === "ALL") {
    return { queue: withDisplay(pool, order), nextCursor: 0 };
  }
  return cyclingQueue(pool, order, settings.length, cursor);
}

// Generates plausible wrong choices for multiple-choice mode.
export function makeChoices(fact) {
  const answer = fact.answer;
  const lastDigit = answer % 10;
  const seen = new Set([answer]);

  function farOff() {
    let candidate, tries = 0;
    do {
      const step = 10 * (1 + Math.floor(Math.random() * 4));
      candidate = answer + (Math.random() < 0.5 ? 1 : -1) * step;
      tries++;
    } while ((candidate <= 0 || seen.has(candidate)) && tries < 30);
    if (candidate <= 0 || seen.has(candidate)) candidate = answer + 10 * (seen.size + 1);
    seen.add(candidate);
    return candidate;
  }
  function sameLastDigit() {
    const str = String(answer);
    const prefix = str.length >= 2 ? str.slice(0, -2) : "";
    let candidate, tries = 0;
    do {
      const mid = Math.floor(Math.random() * 10);
      candidate = parseInt(prefix + String(lastDigit) + String(mid), 10);
      tries++;
    } while ((candidate <= 0 || candidate === answer || seen.has(candidate)) && tries < 30);
    if (candidate <= 0 || candidate === answer || seen.has(candidate)) candidate = answer + 100;
    seen.add(candidate);
    return candidate;
  }
  function nearMultipleOfTen() {
    const dir = answer - 10 > 0 ? (Math.random() < 0.5 ? 1 : -1) : 1;
    const candidate = answer + dir * 10;
    seen.add(candidate);
    return candidate;
  }

  return shuffle([answer, nearMultipleOfTen(), farOff(), sameLastDigit()]);
}

export function averageOf(entries, dropWorst) {
  if (entries.length === 0) return null;
  let list = entries;
  if (dropWorst && entries.length > 1) {
    let worstIdx = 0;
    entries.forEach((e, i) => { if (e.percentCorrect < entries[worstIdx].percentCorrect) worstIdx = i; });
    list = entries.filter((_, i) => i !== worstIdx);
  }
  return Math.round(list.reduce((sum, e) => sum + e.percentCorrect, 0) / list.length);
}

// v41: 1–12 was missing, so after a reload with 1–12 in use the Custom
// button was highlighted (and would read "Custom Range: 1–12") instead
// of the 1–12 preset. Must list every preset button in RangeSection.
// v53: the Ladder has no 1–20 preset — it passes allow1to20 = false.
export function isDefaultRange(start, end, allow1to20 = true) {
  return (start === 1 && end === 10) || (start === 1 && end === 12) || (start === 11 && end === 20) || (allow1to20 && start === 1 && end === 20);
}

export function formatMinSec(ms) {
  if (ms == null) return null;
  const totalSec = Math.round(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export const OPERATION_ABBREV = { mult: "MPLY", div: "Div.", both: "Both" };

export const QUESTIONS_MODES = [
  { key: "mc-seq", label: "Choose · In Order" },
  { key: "mc-random", label: "Choose · Random" },
  { key: "type-seq", label: "Type In · In Order" },
  { key: "type-random", label: "Type In · Random" },
];

// Ladder-only 5th mode (v42): the pass test. Random order, Type In, every
// question for the number (both operations), ignores Quiz Length and
// Practice Facts. The ONLY mode that can pass a ladder number.
export const LADDER_TEST_MODE = { key: "type-test", label: "Type In · Random · Test ALL" };
export const LADDER_MODES = [...QUESTIONS_MODES, LADDER_TEST_MODE];
export function ladderModeOrder(mode) {
  return mode === "type-test" || mode.endsWith("random") ? "random" : "sequential";
}

export function modeKeyFromSettings(order, answerMode) {
  return `${answerMode === "mc" ? "mc" : "type"}-${order === "random" ? "random" : "seq"}`;
}
export function isCustomLength(length) {
  return length !== "ALL" && !QUIZ_LENGTH_PRESETS.includes(length);
}

export function settingsFromModeKey(key) {
  const [am, ord] = key.split("-");
  return { answerMode: am === "mc" ? "mc" : "type", order: ord === "random" ? "random" : "sequential" };
}

// ---------- Challenge Tests ----------
// Each band fixes the End/Exclude-Easy its own numbers are tested under —
// used both to build a running quiz and to compute the totals below.
// 5/10/12 keep ones-and-tens ("excludeEasy: false") only for numbers 1-5,
// as a one-time proof of the mechanics — 15 and 20 exclude them
// throughout, on the assumption anyone reaching that range already knows
// 1s/10s.
export const CHALLENGE_LEVELS = [
  { level: 5, numbers: [1, 2, 3, 4, 5], end: 10, excludeEasy: false },
  { level: 10, numbers: [6, 7, 8, 9, 10], end: 10, excludeEasy: true },
  { level: 12, numbers: [11, 12], end: 12, excludeEasy: true },
  { level: 15, numbers: [13, 14, 15], end: 20, excludeEasy: true },
  { level: 20, numbers: [16, 17, 18, 19, 20], end: 20, excludeEasy: true },
];

export function isChallengeLevel(n) {
  return CHALLENGE_LEVELS.some((l) => l.level === n);
}

// Which band's End/Exclude-Easy a given ladder number's own comprehensive
// test uses — fixed, regardless of which Challenge screen is asking.
function numberChallengeParams(n) {
  const band = CHALLENGE_LEVELS.find((l) => l.numbers.includes(n));
  return band ? { end: band.end, excludeEasy: band.excludeEasy } : null;
}

// The End to record in ladder.masteredEnd when backfilling a number from
// a Challenge pass — its own fixed band End, not the level's End (matters
// for 1-10, whose band End is always 10 regardless of which higher
// Challenge backfilled them).
export function challengeMasteredEnd(n) {
  const params = numberChallengeParams(n);
  return params ? params.end : null;
}

function addChallengeFacts(mult, div, number, { end, excludeEasy }) {
  const partners = fullToNumbers(end, excludeEasy);
  partners.forEach((p) => {
    const mk = `m-${Math.min(number, p)}-${Math.max(number, p)}`;
    if (!mult.has(mk)) mult.set(mk, { op: "×", a: Math.min(number, p), b: Math.max(number, p), answer: number * p, key: mk });
    const prod = number * p;
    const dk1 = `d-${number}-${p}`;
    if (!div.has(dk1)) div.set(dk1, { op: "÷", a: prod, b: number, answer: p, key: dk1 });
    if (p !== number) {
      const dk2 = `d-${p}-${number}`;
      if (!div.has(dk2)) div.set(dk2, { op: "÷", a: prod, b: p, answer: number, key: dk2 });
    }
  });
}

// The full, self-contained question set for "own everything through
// `level`" — every number 1..level tested against its own fixed band,
// deduped so each real-world question ("present every qualifying
// question once") appears once: mult as an unordered pair, div as
// (divisor, quotient).
function challengeComprehensiveFacts(level) {
  const mult = new Map();
  const div = new Map();
  for (let n = 1; n <= level; n++) {
    const params = numberChallengeParams(n);
    if (params) addChallengeFacts(mult, div, n, params);
  }
  return { mult, div };
}

// Raw total for `level` — assumes nothing has been passed yet.
export function challengeTotalCount(level) {
  const { mult, div } = challengeComprehensiveFacts(level);
  return mult.size + div.size;
}

// The actual remaining question pool for `level`, given which individual
// numbers are already mastered (any source — free-play Ladder or an
// earlier Challenge pass). This is also what a Challenge run is built
// from — starting the quiz and computing "left" both read from here, so
// the button's count always matches what actually gets asked.
// v44: uses the Facts Passed Rule — start from the level's full set and
// remove every fact either of whose numbers covers it, counting ANY passed
// number (even above the level) at its real End. Was: each passed number
// <= level removed its fixed band set, ignoring the real End. Identical in
// normal in-order use; only ever asks fewer.
export function challengeRunPool(level, masteredList = [], masteredEnd = {}) {
  const { mult, div } = challengeComprehensiveFacts(level);
  return [...mult.values(), ...div.values()].filter((f) => {
    const [x, y] = factNumbers(f);
    return !factPassed(x, y, masteredList, masteredEnd);
  });
}

export function challengeLeftCount(level, masteredList = [], masteredEnd = {}) {
  return challengeRunPool(level, masteredList, masteredEnd).length;
}

// Reference number: what's left for `level` if the step immediately below
// it (in CHALLENGE_LEVELS order) had been fully, comprehensively passed —
// i.e. numbers 1..previousLevel all mastered. This doesn't look at actual
// progress; it's a fixed per-level number, useful for comparing "jump
// straight here" against "build up to it in order."
export function challengeLeftIfPreviousPassed(level) {
  const idx = CHALLENGE_LEVELS.findIndex((l) => l.level === level);
  if (idx <= 0) return challengeTotalCount(level);
  const prevLevel = CHALLENGE_LEVELS[idx - 1].level;
  const assumed = [];
  for (let n = 1; n <= prevLevel; n++) assumed.push(n);
  return challengeLeftCount(level, assumed);
}

// A level counts as passed once every number it comprehensively covers,
// 1..level, is mastered — matching "you own every number below it" on a
// pass, from any combination of prior Challenges or free-play Ladder use.
export function isChallengePassed(level, masteredList = []) {
  for (let n = 1; n <= level; n++) if (!masteredList.includes(n)) return false;
  return true;
}

// Highest number reached in each title chain with no unexplained gap
// below it — shared by the username title (app.jsx) and the milestone
// pill gating (setup.jsx's LadderPanel), so the two can never disagree.
// Chain A (1-12, Learner -> Junior -> Wiz -> Senior) treats 1 and 10 as
// "skippable" when Exclude Easy is on: an UNmastered 1 or 10 doesn't
// break the chain (they're not real steps under the current setting),
// but an ALREADY mastered one — say, from a Challenge Test, or from
// before Exclude Easy was turned on — still counts and keeps its
// credit. Skippable only ever means "not required," never "forgotten
// if already earned." Chain B (11-20, Royal -> Crown -> King) is
// unaffected by Exclude Easy, since it never touches 1 or 10.
// v49: no skipping — chain A needs every number 1..n, including the 1s and
// 10s, whatever SKIP is set to (audit item 5b). Chain A counts 11/12 only
// when passed at End 12 or more; chain B counts a number only when passed
// at End 20 (audit item 5a).
export function chainHighestReached(masteredList, masteredEnd) {
  const endOf = (n) => passedEndOf(n, masteredList, masteredEnd || {});
  let chainAHighest = null;
  for (let n = 1; n <= 12; n++) {
    const e = endOf(n);
    if (e != null && (n <= 10 || e >= 12)) chainAHighest = n; else break;
  }
  let chainBHighest = null;
  for (let n = 11; n <= 20; n++) {
    const e = endOf(n);
    if (e != null && e >= 20) chainBHighest = n; else break;
  }
  return { chainAHighest, chainBHighest };
}
