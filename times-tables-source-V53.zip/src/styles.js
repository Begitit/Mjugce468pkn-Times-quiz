const FONT = '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
const MONO = '"JetBrains Mono", ui-monospace, "SF Mono", "Cascadia Code", monospace';

export const s = {
  appBg: { minHeight: "100vh", width: "100%", background: "#16232E", display: "flex", justifyContent: "center", alignItems: "flex-start", padding: "24px 14px", position: "relative", overflow: "hidden", fontFamily: FONT },
  gridOverlay: { position: "absolute", inset: 0, backgroundImage: "linear-gradient(rgba(255,255,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.035) 1px, transparent 1px)", backgroundSize: "28px 28px", pointerEvents: "none" },
  container: { position: "relative", width: "100%", maxWidth: 420 },
  card: { background: "#1F3040", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: "24px 20px 20px", boxShadow: "0 20px 50px rgba(0,0,0,0.35)" },
  headerRow: { display: "flex", alignItems: "center", gap: 14, marginBottom: 22 },
  times: { fontFamily: MONO, fontSize: 30, color: "#E8B94A", background: "rgba(232,185,74,0.12)", borderRadius: 12, width: 52, height: 52, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  h1: { color: "#EDEAE0", fontSize: 21, fontWeight: 700, margin: 0, letterSpacing: "-0.01em" },
  subtitle: { color: "rgba(237,234,224,0.55)", fontSize: 13, margin: "3px 0 0" },
  section: { marginBottom: 18 },
  // v52: capitalized section titles at 80% brightness (was 60%); the
  // mixed-case sub-labels keep 60% via subLabelColor.
  sectionLabel: { color: "rgba(237,234,224,0.8)", fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 8 },
  subLabelColor: "rgba(237,234,224,0.6)",
  sectionNote: { color: "rgba(237,234,224,0.55)", fontSize: 13, margin: "-2px 0 8px" },
  segGroup: { display: "flex", flexWrap: "wrap", alignItems: "flex-end", gap: 6 },
  segGroupStacked: { display: "flex", flexDirection: "column", gap: 6 },
  segBtn: { flex: "1 1 auto", minWidth: 64, padding: "9px 10px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.35)", background: "rgba(255,255,255,0.03)", color: "rgba(237,234,224,0.75)", fontSize: 13, fontWeight: 600, transition: "all 0.15s ease" },
  segBtnStacked: { width: "100%", flex: "none" },
  segBtnActive: { background: "#E8B94A", color: "#16232E", borderColor: "#E8B94A" },
  customRow: { display: "flex", flexWrap: "nowrap", alignItems: "flex-end", gap: 10, marginTop: 10 },
  dash: { color: "rgba(237,234,224,0.4)", paddingBottom: 8 },
  numberField: { display: "flex", flexDirection: "column", gap: 4 },
  numberFieldLabel: { color: "rgba(237,234,224,0.55)", fontSize: 13 },
  numberInput: { width: 60, height: 44, padding: "8px 6px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.2)", color: "#EDEAE0", fontFamily: MONO, fontSize: 17, textAlign: "center", boxSizing: "border-box" },
  stepperRow: { display: "flex", alignItems: "stretch", gap: 4 },
  stepperBtn: { width: 44, height: 44, borderRadius: 8, border: "1px solid rgba(255,255,255,0.25)", background: "rgba(255,255,255,0.05)", color: "#EDEAE0", fontSize: 22, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", boxSizing: "border-box", touchAction: "manipulation", WebkitUserSelect: "none", userSelect: "none", WebkitTouchCallout: "none", WebkitTapHighlightColor: "transparent" },
  nameInput: { width: "100%", padding: "12px 14px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "#EDEAE0", fontFamily: FONT, fontSize: 18 },
  passRow: { display: "flex", gap: 8, alignItems: "stretch", marginBottom: 14 },
  passToggleBtn: { padding: "0 14px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.35)", background: "rgba(255,255,255,0.06)", color: "rgba(237,234,224,0.8)", fontSize: 13, fontWeight: 600 },
  primaryBtn: { width: "100%", marginTop: 6, padding: "14px", borderRadius: 12, border: "none", background: "#E8B94A", color: "#16232E", fontSize: 15, fontWeight: 700, letterSpacing: "0.01em" },
  progressRow: { display: "flex", alignItems: "center", gap: 10, marginBottom: 6 },
  progressTrack: { flex: 1, height: 6, borderRadius: 3, background: "rgba(255,255,255,0.08)", overflow: "hidden" },
  progressFill: { height: "100%", background: "#E8B94A", transition: "width 0.3s ease" },
  quitBtn: { width: 28, height: 28, borderRadius: 8, border: "1px solid rgba(255,255,255,0.35)", background: "rgba(255,255,255,0.03)", color: "rgba(237,234,224,0.6)", fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  progressLabel: { color: "rgba(237,234,224,0.45)", fontSize: 12, marginBottom: 18 },
  questionBox: { border: "2px solid rgba(255,255,255,0.12)", borderRadius: 16, padding: "36px 20px 24px", textAlign: "center", transition: "border-color 0.2s ease" },
  question: { fontFamily: MONO, fontSize: 42, fontWeight: 700, color: "#EDEAE0", letterSpacing: "-0.02em", marginBottom: 26 },
  repeatBanner: { color: "#E0785A", fontSize: 13, fontWeight: 800, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 10 },
  op: { color: "#E8B94A" },
  answerForm: { display: "flex", gap: 10, justifyContent: "center" },
  answerInput: { width: 110, padding: "12px 14px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "#EDEAE0", fontFamily: MONO, fontSize: 22, textAlign: "center" },
  submitBtn: { padding: "12px 20px", borderRadius: 10, border: "none", background: "#E8B94A", color: "#16232E", fontSize: 15, fontWeight: 700 },
  choiceGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 },
  choiceBtn: { padding: "16px 10px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.35)", background: "rgba(255,255,255,0.03)", color: "#EDEAE0", fontFamily: MONO, fontSize: 21, fontWeight: 600 },
  choiceCorrect: { background: "rgba(143,191,138,0.18)", borderColor: "#8FBF8A", color: "#8FBF8A" },
  choiceDim: { opacity: 0.35 },
  feedbackText: { marginTop: 18, fontSize: 14, fontWeight: 600 },
  missedBox: { marginBottom: 20 },
  missedLabel: { color: "rgba(237,234,224,0.6)", fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 10 },
  missedList: { display: "flex", flexWrap: "wrap", gap: 6 },
  missedChip: { fontFamily: MONO, fontSize: 13, padding: "5px 10px", borderRadius: 8, background: "rgba(224,120,90,0.14)", color: "#E0785A", border: "1px solid rgba(224,120,90,0.25)" },
  secondaryBtn: { width: "100%", marginTop: 10, padding: "12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.12)", background: "#1E3A8A", color: "#EDEAE0", fontSize: 14, fontWeight: 600 },
  backupRow: { display: "flex", gap: 8, marginTop: 10 },
  backupBtn: { flex: 1, padding: "10px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.35)", background: "transparent", color: "rgba(237,234,224,0.65)", fontSize: 12, fontWeight: 600 },
  userBarWrap: { marginBottom: 12 },
  // Single merged container — top row plus (when open) the expanded list,
  // separated only by a divider, not two separate bordered boxes.
  userBarContainer: { borderRadius: 12, background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", overflow: "hidden" },
  userBarTopRow: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 8px 10px 14px" },
  userBarName: { color: "#EDEAE0", fontSize: 18, fontWeight: 700 },
  userBarToggle: { height: 28, boxSizing: "border-box", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "2px 12px", borderRadius: 6, border: "1px solid rgba(255,255,255,0.35)", background: "rgba(255,255,255,0.04)", color: "rgba(237,234,224,0.7)", fontSize: 9, fontWeight: 600, lineHeight: 1.2, flexShrink: 0 },
  userPanelInner: { padding: "10px 12px 12px", borderTop: "1px solid rgba(255,255,255,0.08)" },
  userRow: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 0" },
  userRowName: { flex: 1, textAlign: "left", padding: "8px 10px", borderRadius: 8, border: "1px solid transparent", background: "transparent", color: "rgba(237,234,224,0.75)", fontSize: 14, fontWeight: 600 },
  userRowNameActive: { background: "rgba(232,185,74,0.12)", color: "#E8B94A" },
  userDeleteBtn: { height: 32, boxSizing: "border-box", display: "inline-flex", alignItems: "center", padding: "0 10px", borderRadius: 8, border: "1px solid rgba(224,120,90,0.55)", background: "rgba(224,120,90,0.08)", color: "#E0785A", fontSize: 12, fontWeight: 600 },
  userAddRow: { display: "flex", gap: 8, marginTop: 8, paddingTop: 10, borderTop: "1px solid rgba(255,255,255,0.08)" },
  userAddInput: { flex: "1 1 auto", minWidth: 0, maxWidth: "78%", padding: "9px 10px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.2)", color: "#EDEAE0", fontSize: 14 },
  userAddBtn: { padding: "9px 14px", borderRadius: 8, border: "none", background: "#E8B94A", color: "#16232E", fontSize: 13, fontWeight: 700 },
  userAddBtnDisabled: { background: "rgba(255,255,255,0.15)", color: "rgba(237,234,224,0.4)" },
  userLimitNote: { color: "rgba(237,234,224,0.45)", fontSize: 11, marginTop: 6 },
  devToggleWrap: { display: "flex", justifyContent: "center", marginBottom: 10 },
  devToggleBtn: { padding: "4px 10px", borderRadius: 999, border: "1px solid rgba(255,255,255,0.2)", background: "rgba(255,255,255,0.04)", color: "rgba(237,234,224,0.55)", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em" },
  devToggleBtnActive: { background: "rgba(232,185,74,0.18)", color: "#E8B94A", borderColor: "rgba(232,185,74,0.4)" },
  previewWrap: { position: "relative" },
  previewNote: { textAlign: "center", color: "#E8B94A", fontSize: 11, fontWeight: 600, marginBottom: 8 },
  statsRow: { display: "flex", gap: 10, marginBottom: 20 },
  statBox: { flex: 1, padding: "14px 12px", borderRadius: 12, background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", textAlign: "center" },
  statLabel: { color: "rgba(237,234,224,0.55)", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 6 },
  statValue: { fontFamily: MONO, fontSize: 24, fontWeight: 700, color: "#E8B94A" },
  historyList: { marginBottom: 20, maxHeight: 320, overflowY: "auto" },
  historyRow: { display: "flex", flexDirection: "column", alignItems: "stretch", gap: 4, padding: "10px 4px", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: 13 },
  historyTopLine: { display: "flex", alignItems: "center", gap: 10 },
  historyDate: { color: "rgba(237,234,224,0.75)", width: 52, flexShrink: 0 },
  historyMode: { color: "rgba(237,234,224,0.75)", flex: 1 },
  historyDetailLine: { display: "flex", flexWrap: "wrap", gap: 10, fontSize: 11, color: "rgba(237,234,224,0.75)", paddingLeft: 62 },
  historyTimeValue: { color: "#FFFFFF" },
  historyPercent: { fontFamily: MONO, fontWeight: 700, color: "#8FBF8A", width: 44, textAlign: "right" },
};

export const globalCss = `
  input[type=number]::-webkit-inner-spin-button,
  input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  input[type=number] {
    -moz-appearance: textfield;
  }
  * { box-sizing: border-box; }
  button { font-family: ${FONT}; cursor: pointer; }

  /* Senior Math Wiz 12 pill: on narrow (phone) screens, let the whole
     title wrap naturally below the badge as it already does. On wider
     screens (tablet/desktop), force a break after "Senior" instead so
     the badge and "Senior" share the first line. */
  .tt-senior-narrow { display: inline; }
  .tt-senior-wide { display: none; }
  @media (min-width: 481px) {
    .tt-senior-narrow { display: none; }
    .tt-senior-wide { display: inline; }
  }
`;
