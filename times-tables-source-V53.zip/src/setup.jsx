import { useState, useRef, useEffect } from "react";
import { s } from "./styles.js";
import { Section, SegGroup, NumberField, ConfirmModal, YesNoModal, DiamondIcon, CrownIcon, TitleWithIcon, MilestoneButton } from "./components.jsx";
import { TEACHER_PASSCODE } from "./logic.js";
import {
  QUESTIONS_MODES, LADDER_MODES, modeKeyFromSettings, settingsFromModeKey,
  isDefaultRange, QUIZ_LENGTH_PRESETS, LADDER_LENGTH_PRESETS,
  quizAllCount, ladderAllCount, passEndFor, practiceStartOf,
  titleForNumber, rangeNumbers,
  CHALLENGE_LEVELS, challengeTotalCount, challengeLeftCount, challengeLeftIfPreviousPassed, isChallengePassed, chainHighestReached,
  DIVIDE_SYMBOLS,
} from "./logic.js";

// Flat, monocolor shield badge used as the ladder's per-number marker.
// star=true draws a gold star on top (mastered); numeral draws a plain
// digit on top (one clean pass, sized 20% smaller than the mastered
// shield). outline=true draws an unfilled, stroke-only shield in `fill`'s
// color instead — used for yellow/temp (short-range) progress, which
// isn't a real permanent pass the way a filled green shield is; its
// numeral renders in black rather than the usual off-white. Sized in em
// so it scales with the button's own font-size (zoom / accessibility
// text-size settings). Positioned absolute (button must be
// position:relative) so its size never affects the button's own box —
// every button in the row stays the same size as its plain-number
// siblings regardless of badge size.
function ShieldBadge({ fill, star, numeral, outline, active, size: sizeOverride, style }) {
  const size = sizeOverride || (star ? "2.1em" : "1.68em");
  // Star/numeral color: on temp (outline) badges it always matches the
  // shield's own current stroke color (yellow untapped, black tapped),
  // so the content never reads as a fixed color independent of the
  // badge. On real (filled) badges it's always gold.
  const shieldStroke = outline ? (active ? "#000000" : fill) : "none";
  const contentColor = outline ? shieldStroke : "#E8B94A";
  // The numeral specifically (not the star) was hard to read as gold on
  // a green fill, so it gets its own yellow on real (filled) badges —
  // the star keeps the original gold either way.
  const numeralColor = outline ? shieldStroke : "#FFF176";
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 26"
      style={{ position: "absolute", right: "0.73em", top: "50%", transform: "translateY(-50%)", pointerEvents: "none", ...style }}
    >
      <path
        d="M12,2 Q15,5 21,6 V13 C21 19 17 23 12 25 C7 23 3 19 3 13 V6 Q9,5 12,2 Z"
        fill={outline ? "none" : fill}
        stroke={shieldStroke}
        strokeWidth={outline ? 1.5 : 0}
      />
      {star && (
        // Tapped/outline star is stroke-only, and an SVG stroke draws
        // centered on the path — so it bleeds outward beyond the star's
        // own points regardless of stroke width. Scaled down (not a
        // thinner stroke) so it clears the shield edge instead.
        <g transform={outline && active ? "translate(12,13.25) scale(0.9) translate(-12,-13.25)" : undefined}>
          <path
            d="M12,6.2 L13.91,11.37 L19.42,11.59 L15.09,15.00 L16.59,20.31 L12,17.25 L7.41,20.31 L8.91,15.00 L4.58,11.59 L10.09,11.37 Z"
            fill={outline && active ? "none" : contentColor}
            stroke={outline && active ? "#000000" : "none"}
            strokeWidth={outline && active ? 1 : 0}
          />
        </g>
      )}
      {numeral != null && (
        <text x="12" y="18" textAnchor="middle" fontSize="12" fontWeight="700" fill={numeralColor}>
          {numeral}
        </text>
      )}
    </svg>
  );
}

// Thin upward-pointing triangle — the "this is your current ladder step"
// marker. Drawn as a shape rather than a font glyph so it stays skinny at
// any size; uses currentColor so it always matches the button's own text
// color (dim by default, dark when the button is actively tapped/gold).
// Also absolutely positioned, for the same reason as ShieldBadge above.
function TriangleMarker({ color }) {
  return (
    <svg
      width="1.26em"
      height="1.26em"
      viewBox="0 0 12 12"
      style={{ position: "absolute", right: "0.73em", top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}
    >
      <path d="M6,0.25 L8.53,11.75 L3.47,11.75 Z" fill={color || "currentColor"} />
    </svg>
  );
}

// Short-range (temp-End) version of the current-step triangle: yellow
// always, plus a black circle behind it when tapped so it stays visible
// against the gold tapped background (plain yellow-on-gold would have
// nearly no contrast). The circle is scaled up by the same ratio the
// triangle itself grew by, so the visual margin around it stays
// consistent with the design preview this was built from.
function TriangleMarkerTemp({ active }) {
  const YELLOW = "#FFF176";
  if (!active) return <TriangleMarker color={YELLOW} />;
  return (
    <svg
      width="1.89em"
      height="1.89em"
      viewBox="-3 -3 18 18"
      style={{ position: "absolute", right: "0.55em", top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}
    >
      <circle cx="6" cy="6" r="8.6" fill="#000000" />
      <path d="M6,0.25 L8.53,11.75 L3.47,11.75 Z" fill={YELLOW} />
    </svg>
  );
}

// Design-only swatch of every ladder-button state — mastered, one-pass,
// current step, locked, and out-of-range (both mastered and not).
// Hardcoded example numbers, no real ladder data involved. Shown only
// inside the BD# dev-preview toggle. Laid out as one row per style, two
// columns (untapped, tapped), so the two states of each style sit side
// by side for direct comparison. Labels get a max-width of 125% of the
// button's own width — text that fits within that wraps normally like
// any inline content; text that doesn't fit falls to a second line
// rather than stretching the column.
const GALLERY_STYLES = [
  { label: "Passed", n: 5, badge: "star" },
  { label: "Your step", n: 7, badge: "triangle" },
  { label: "Not passed yet", n: 8, badge: "locked" },
  { label: "Practice passed", n: 4, badge: "tempStar" },
  { label: "Your practice step", n: 11, badge: "tempCurrent" },
];

function BadgeGallery() {
  const quiet = "rgba(237,234,224,0.65)";
  const YELLOW = "#FFF176";
  const GOLD = "#E8B94A";
  const BTN_W = 92;

  function renderCell(style, active) {
    const mastered = style.badge === "star" || style.badge === "starOutOfRange";
    const outOfRange = style.badge === "outOfRange" || style.badge === "starOutOfRange";
    const locked = style.badge === "locked";
    const tempMastered = style.badge === "tempStar";
    const tempCurrent = style.badge === "tempCurrent";
    const hasShield = mastered || tempMastered || tempCurrent || style.badge === "triangle";
    const buttonStyle = {
      ...s.segBtn,
      position: "relative",
      minWidth: BTN_W,
      ...(!active && !mastered && !tempMastered && !tempCurrent ? { color: quiet, borderColor: quiet } : {}),
      ...(active ? s.segBtnActive : {}),
      ...(tempMastered && !active ? { color: YELLOW, borderColor: GOLD, borderWidth: 2, padding: "8px 9px" } : {}),
      ...(tempCurrent && !active ? { color: YELLOW, borderColor: GOLD, borderWidth: 2, padding: "8px 9px" } : {}),
      ...(mastered && !active ? { color: "#46AB68", borderColor: "rgba(70,171,104,0.6)", borderWidth: 2, padding: "8px 9px" } : {}),
      // v43: "Not passed yet" is no longer faded — any unpassed number can be passed.
      ...(outOfRange && !mastered && !tempMastered ? { opacity: 0.55, borderStyle: "dashed", borderWidth: 2, padding: "8px 9px" } : {}),
      // v52: the practice-passed example matches the real yellow pill (v51):
      // it shows its End ("4s to 7") with room for the shield on the right.
      ...(tempMastered ? { borderWidth: 2, padding: "8px 2.9em 8px 9px" } : {}),
    };
    return (
      <div key={style.label + (active ? "-on" : "-off")} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
        <button disabled style={buttonStyle}>
          <span style={{ position: "relative", left: hasShield && !tempMastered ? "-1.1em" : 0 }}>{style.n}s{tempMastered ? " to 7" : ""}</span>
          {style.badge === "star" || style.badge === "starOutOfRange" ? (
            <ShieldBadge fill="#46AB68" star />
          ) : style.badge === "tempStar" ? (
            <ShieldBadge fill={YELLOW} outline star active={active} />
          ) : style.badge === "triangle" ? (
            <TriangleMarker />
          ) : style.badge === "tempCurrent" ? (
            <TriangleMarkerTemp active={active} />
          ) : null}
        </button>
        <span style={{ maxWidth: BTN_W * 1.25, whiteSpace: "normal", fontSize: 13, color: "rgba(237,234,224,0.55)", textAlign: "center" }}>
          {style.label}
          {active ? ", tapped" : ""}
        </span>
      </div>
    );
  }

  return (
    <>
      <div style={{ height: 12 }} />
      <p style={{ ...s.subtitle, margin: "0 0 14px" }}>
        These buttons only show what each one looks like.
      </p>
      <div style={{ position: "relative" }}>
        <div style={{ position: "absolute", left: "50%", top: 0, bottom: 0, width: 1, background: "rgba(255,255,255,0.15)" }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 10 }}>
          <span style={{ textAlign: "center", fontSize: 13, letterSpacing: "0.05em", color: "rgba(237,234,224,0.55)", textTransform: "uppercase" }}>Ready</span>
          <span style={{ textAlign: "center", fontSize: 13, letterSpacing: "0.05em", color: "rgba(237,234,224,0.55)", textTransform: "uppercase" }}>When Tapped</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, alignItems: "start" }}>
          {GALLERY_STYLES.map((style) => [renderCell(style, false), renderCell(style, true)])}
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 18, paddingBottom: 30 }}>
        <div style={{ display: "flex", justifyContent: "center" }}>
          <div style={{ position: "relative" }}>
            <button disabled style={{ ...s.segBtn, position: "relative", minWidth: BTN_W, color: "#46AB68", borderColor: "rgba(70,171,104,0.6)", borderWidth: 2, padding: "8px 9px" }}>
              <span style={{ position: "relative", left: "-1.1em" }}>10s</span>
              <ShieldBadge fill="#46AB68" star />
            </button>
            <div style={{ position: "absolute", left: "100%", top: 0, marginLeft: 8, width: "max-content", display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
              <MilestoneButton title="Math Wiz!" minWidth={BTN_W} style={{ height: 35, display: "flex", alignItems: "center", justifyContent: "center", padding: "0 10px" }} />
              <span style={{ textAlign: "center", fontSize: 13, color: "rgba(237,234,224,0.55)", whiteSpace: "nowrap" }}>
                Important step button
              </span>
            </div>
          </div>
        </div>
        <div />
      </div>
    </>
  );
}

// Static reference list — every title in order. Not tied to any real
// user's progress, so 11+ is shown twice: once under the default path
// (Senior, reached via a range ending at 12), and again under the
// alternate path (Royal/Crown/King, reached via a range ending at 20).
function milestoneFor(n, endUsed) {
  if (n === 5) return "Junior Math Wiz";
  if (n === 10) return "Math Wiz!";
  if (n === 12 && endUsed === 12) return "Senior Math Wiz 12";
  if (n === 15 && endUsed === 20) return "Crown Math Wiz";
  if (n === 20) return "Math Wiz King";
  return null;
}

function LevelsList() {
  const rowStyle = { display: "flex", alignItems: "center", gap: 10, padding: "6px 0", borderBottom: "1px solid rgba(255,255,255,0.08)" };
  const numStyle = { width: 62, textAlign: "right", color: "#EDEAE0", fontSize: 13, flexShrink: 0, marginLeft: -36 };
  const titleStyle = { fontSize: 14, fontWeight: 600, color: "#EDEAE0", display: "flex", alignItems: "center", gap: 6 };

  function row(n, endUsed, icon) {
    const t = titleForNumber(n, endUsed);
    if (!t) return null;
    const milestoneTitle = milestoneFor(n, endUsed);
    // If the title's first word isn't "Math" (Junior/Senior/Royal/Crown),
    // split it out as its own flex item so it wraps together with the
    // icon on the first line, with only the remaining words dropping to
    // a second line — instead of the badge sitting alone while the
    // WHOLE title (as one atomic flex item) drops below it.
    // Only the actual milestone ("milepost") rows get the split — not
    // every row whose title happens not to start with "Math".
    const words = t.numbered.split(" ");
    const firstWord = words[0];
    const rest = words.slice(1).join(" ");
    const splitFirst = !!milestoneTitle && firstWord !== "Math";
    return (
      <div key={`${n}-${endUsed}`} style={{ ...rowStyle, justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0, flexShrink: 1 }}>
          <span style={numStyle}>{n}</span>
          <span style={{ ...titleStyle, minWidth: 0, flexWrap: "wrap" }}>
            {icon === "shield" && <ShieldBadge fill="#46AB68" star size="1.54em" style={{ position: "static", transform: "none" }} />}
            {icon === "diamond" && <DiamondIcon size="0.99em" />}
            {icon === "crown" && <CrownIcon size="1.26em" />}
            {icon === "king" && <CrownIcon size="2.52em" />}
            {splitFirst ? (
              <>
                <span style={{ whiteSpace: "nowrap" }}>{firstWord}</span>
                <span>{rest}</span>
              </>
            ) : (
              t.numbered
            )}
          </span>
        </div>
        {milestoneTitle && <MilestoneButton title={milestoneTitle} minWidth={150} allowShrink />}
      </div>
    );
  }

  return (
    <>
      <p style={{ ...s.subtitle, margin: "0 0 16px" }}>
        A title means you have passed every number step up through that step. Anytime you do a full pass on a number you own the number. When you have done a full pass on all the numbers below and through a number step, then you get that title.
      </p>
      <div style={{ ...rowStyle, borderBottom: "1px solid rgba(255,255,255,0.2)", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ ...numStyle, marginLeft: -16, color: "rgba(237,234,224,0.55)" }}>Number</span>
          <span style={{ fontSize: 13, color: "rgba(237,234,224,0.55)", paddingLeft: "calc(1.54em + 6px)", marginLeft: -16 }}>Title Won</span>
        </div>
        <span style={{ fontSize: 13, color: "rgba(237,234,224,0.55)", textAlign: "right", minWidth: 80 }}>Important Steps</span>
      </div>
      {Array.from({ length: 12 }, (_, i) => row(i + 1, 12, "shield"))}
      <p style={{ ...s.subtitle, margin: "16px 0 6px" }}>These are learned through times 20.</p>
      {Array.from({ length: 10 }, (_, i) => {
        const n = i + 11;
        const icon = n === 20 ? "king" : n >= 15 ? "crown" : "diamond";
        return row(n, 20, icon);
      })}
    </>
  );
}

// Config-driven so future tabs (Words Used, FAQ) are just new entries
// here plus a render branch below — no restructuring needed.
const GUIDE_TABS = [
  { key: "steps", label: "Steps" },
  { key: "gallery", label: "Buttons" },
];

export function GuideScreen({ onBack }) {
  const [tab, setTab] = useState("steps");
  return (
    <div style={s.card}>
      <div style={s.headerRow}>
        <span style={s.times}>?</span>
        <div>
          <h1 style={s.h1}>Guide</h1>
        </div>
      </div>
      <div style={s.segGroup}>
        {GUIDE_TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} style={{ ...s.segBtn, textTransform: "uppercase", ...(tab === t.key ? s.segBtnActive : {}) }}>
            {t.label}
          </button>
        ))}
      </div>
      <div style={{ height: 14 }} />
      {tab === "gallery" && <BadgeGallery />}
      {tab === "steps" && <LevelsList />}
      <div style={{ height: 14 }} />
      <button style={s.primaryBtn} onClick={onBack}>Go Back</button>
    </div>
  );
}

export function OperationSection({ settings, patch, displayOverride, note }) {
  return (
    <Section label="Math Types" note={note}>
      <SegGroup
        options={[{ v: "mult", l: "Multiply" }, { v: "div", l: "Divide" }, { v: "both", l: "Both" }]}
        value={displayOverride ?? settings.operation}
        onChange={(v) => patch({ operation: v })}
        disabled={!!displayOverride}
      />
    </Section>
  );
}

const OPERATION_SUGGESTION_NOTE = "A good idea is for each Type of Questions, do Multiply, then Divide, then Both.";

// Renders one division symbol's example with fixed illustrative numbers
// (6 and 2) so a parent/teacher can see exactly what each symbol looks
// like before turning it on. Fraction bar is the one case that needs a
// real stacked layout rather than a plain-text string.
function DivisionSymbolExample({ symbolKey }) {
  if (symbolKey === "fraction") {
    return (
      <span style={{ display: "inline-flex", flexDirection: "column", alignItems: "center", verticalAlign: "middle", lineHeight: 1.15 }}>
        <span>6</span>
        <span style={{ background: "currentColor", width: "1ch", height: "0.06em", margin: "0.08em 0" }} />
        <span>2</span>
      </span>
    );
  }
  if (symbolKey === "bracket") {
    return (
      <span style={{ display: "inline-flex", alignItems: "baseline" }}>
        <span>2</span>
        <span style={{ position: "relative", display: "inline-block", marginLeft: "0.15em", paddingLeft: "0.12em", paddingTop: "0.03em" }}>
          <span style={{ position: "absolute", left: 0, top: "0.02em", width: "0.06em", height: "1.32em", background: "currentColor" }} />
          <span style={{ position: "absolute", left: 0, top: "0.02em", height: "0.06em", width: "max(1.98em, 1ch)", background: "currentColor" }} />
          6
        </span>
      </span>
    );
  }
  const def = DIVIDE_SYMBOLS.find((d) => d.key === symbolKey);
  return <span>{def.render(6, 2)}</span>;
}

export function DivideSymbolsSection({ settings, patch }) {
  const selected = settings.divideSymbols && settings.divideSymbols.length ? settings.divideSymbols : ["obelus"];
  const toggle = (key) => {
    const has = selected.includes(key);
    const next = has ? selected.filter((k) => k !== key) : [...selected, key];
    // Never allow zero symbols selected — fall back to the default.
    patch({ divideSymbols: next.length ? next : ["obelus"] });
  };
  // Collapsible: starts collapsed every time the tab renders (not saved).
  // Collapsed shows only the title + Choose button; Choose reveals the note
  // and checkboxes and turns into Done, which collapses it again.
  const [open, setOpen] = useState(false);
  const header = (
    <span style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <span>Division Symbols</span>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        style={{ ...s.segBtn, flex: "0 0 auto", minWidth: 64, padding: "4px 12px", fontSize: 12, textTransform: "none", letterSpacing: "normal" }}
      >
        {open ? "Done" : "Choose"}
      </button>
    </span>
  );
  return (
    <Section label={header} note={open ? "Each of these equals 3. Pick the signs you want to use." : null}>
      {open && <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {DIVIDE_SYMBOLS.map((d) => (
          <label key={d.key} style={{ display: "flex", alignItems: "center", gap: 12, cursor: "pointer" }}>
            <input
              type="checkbox"
              checked={selected.includes(d.key)}
              onChange={() => toggle(d.key)}
              style={{ width: 20, height: 20, accentColor: "#E8B94A", cursor: "pointer", flexShrink: 0 }}
            />
            <span style={{ fontSize: 19, minWidth: 64, color: "#EDEAE0" }}><DivisionSymbolExample symbolKey={d.key} /></span>
            <span style={{ ...s.subtitle, margin: 0 }}>{d.label}</span>
          </label>
        ))}
      </div>}
    </Section>
  );
}

export function ExcludeEasySection({ settings, patch }) {
  const mode = settings.excludeEasyMode === "auto" ? "auto" : (settings.excludeEasy ? "on" : "off");
  const handle = (v) => {
    if (v === "auto") patch({ excludeEasyMode: "auto" });
    else patch({ excludeEasyMode: "manual", excludeEasy: v === "on" });
  };
  return (
    <Section label={<>SKIP <span style={{ textTransform: "none" }}>the</span> EASY FACTS 1×, 10×, ÷1, ÷10</>}>
      <SegGroup
        options={[{ v: "off", l: "Off" }, { v: "on", l: "On" }, { v: "auto", l: "Let App Pick" }]}
        value={mode}
        onChange={handle}
      />
    </Section>
  );
}

// v44: yellowEnd = the End the yellow (practice) badges were earned with,
// or null if there are none (Ladder passes it; Quizzes doesn't). When a
// range change would make the End bigger than that, the "Lose your yellow
// badges?" warning replaces "Change range?", and Continue clears them.
export function RangeSection({ settings, patch, customStart, setCustomStart, showTitleNote = true, yellowEnd = null, onClearYellow, subLabel = null, children = null, allow1to20 = true }) {
  // v53: the Ladder has no 1–20 preset (allow1to20={false}); a 1–20 range
  // set there with Custom shows as "Custom Range: 1–20". Quizzes keeps it.
  const preset =
    settings.start === 1 && settings.end === 10 ? "1-10" :
    settings.start === 1 && settings.end === 12 ? "1-12" :
    settings.start === 11 && settings.end === 20 ? "11-20" :
    allow1to20 && settings.start === 1 && settings.end === 20 ? "1-20" : "custom";
  const active = customStart ? "custom" : preset;
  const options = [
    { v: "1-10", l: "1–10" }, { v: "1-12", l: "1–12" },
    { v: "11-20", l: "11–20" }, ...(allow1to20 ? [{ v: "1-20", l: "1–20" }] : []),
  ];
  const presetRanges = { "1-10": [1, 10], "1-12": [1, 12], "11-20": [11, 20], "1-20": [1, 20] };

  const [draftStart, setDraftStart] = useState(settings.start);
  const [draftEnd, setDraftEnd] = useState(settings.end);
  const [pending, setPending] = useState(null);

  useEffect(() => {
    if (!customStart) { setDraftStart(settings.start); setDraftEnd(settings.end); }
  }, [settings.start, settings.end, customStart]);

  const requestChange = (start, end, custom = false) => {
    if (start === settings.start && end === settings.end) return;
    setPending({ start, end, custom });
  };

  const select = (v) => {
    if (v === "custom") {
      // v41: fill the boxes with the last custom range this user set on
      // this tab (settings.lastCustom, saved with the tab's settings), or
      // with the range in use if no custom range has ever been set.
      // Nothing changes until SET RANGE (+ confirm), same as before.
      // v53: tapping Custom again while open closes it, changing nothing.
      if (customStart) { setCustomStart(false); return; }
      const last = settings.lastCustom;
      setCustomStart(true);
      setDraftStart(last ? last.start : settings.start);
      setDraftEnd(last ? last.end : settings.end);
      return;
    }
    setCustomStart(false);
    const [start, end] = presetRanges[v];
    requestChange(start, end);
  };

  const applyCustom = () => {
    const start = Math.min(draftStart, draftEnd);
    const end = Math.max(draftStart, draftEnd);
    requestChange(start, end, true);
  };

  return (
    <Section label="Range">
      {/* v51: the Ladder labels its range buttons "Ladder Range" (Practice
          Start sits below them, in the same section). */}
      {subLabel && <div style={{ ...s.sectionLabel, textTransform: "none", marginTop: 14, color: s.subLabelColor }}>{subLabel}</div>}
      <div style={s.segGroup}>
        {options.map((o) => (
          <button key={o.v} onClick={() => select(o.v)} style={{ ...s.segBtn, ...(active === o.v ? s.segBtnActive : {}) }}>{o.l}</button>
        ))}
        <div style={{ flexBasis: "100%", height: 0 }} />
        {/* v41: Custom gets its own full-width row. While Custom is the
            selected mode it shows the range actually IN USE (settings, not
            the unsaved draft boxes), e.g. "Custom Range: 3–7"; with a preset
            in use it's plain "Custom". The dash between Start and End was
            dropped — it dangled at line end on phones. */}
        <button onClick={() => select("custom")} style={{ ...s.segBtn, flexBasis: "100%", ...(active === "custom" ? s.segBtnActive : {}) }}>{active === "custom" ? `Custom Range: ${settings.start}–${settings.end}` : "Custom"}</button>
        {customStart && (
          <>
            <NumberField label="Start" value={draftStart} onChange={setDraftStart} min={1} max={20} />
            <NumberField label="End" value={draftEnd} onChange={setDraftEnd} min={1} max={20} />
            <button
              onClick={applyCustom}
              style={{
                ...s.segBtn, flex: "0 0 auto", minWidth: 0, padding: "9px 12px",
                ...(Math.min(draftStart, draftEnd) !== settings.start || Math.max(draftStart, draftEnd) !== settings.end
                  ? { borderColor: "#E8B94A", color: "#E8B94A" }
                  : {}),
              }}
            >
              SET RANGE
            </button>
            {/* v47: Go Back closes the Start/End boxes without changing
                anything, and the range in use is highlighted again. */}
            <button
              onClick={() => setCustomStart(false)}
              style={{ ...s.segBtn, flex: "0 0 auto", minWidth: 0, padding: "9px 12px" }}
            >
              Go Back
            </button>
          </>
        )}
      </div>
      {pending && (
        <YesNoModal
          {...(yellowEnd != null && pending.end > yellowEnd
            ? { title: "Lose your yellow badges?", message: "Your new End number is bigger. This will take away your yellow practice badges. Green badges stay.", confirmLabel: "Yes Continue", cancelLabel: "Go Back" }
            : { title: "Change range?", message: `Change range to ${pending.start}–${pending.end}?` })}
          onConfirm={() => {
            // Remember the custom range: the one just set via SET RANGE, or —
            // when leaving a non-preset range for a preset — the one being
            // left (covers ranges set before v41, which had no lastCustom).
            const lastCustom = pending.custom
              ? { start: pending.start, end: pending.end }
              : preset === "custom" ? { start: settings.start, end: settings.end } : null;
            patch({ start: pending.start, end: pending.end, ...(lastCustom ? { lastCustom } : {}) });
            if (yellowEnd != null && pending.end > yellowEnd && onClearYellow) onClearYellow();
            setPending(null);
          }}
          onCancel={() => setPending(null)}
        />
      )}
      {/* v52: the whole Range note shows only while Custom is open. */}
      {showTitleNote && customStart && (
        <p style={{ ...s.subtitle, marginTop: 10, marginBottom: 0 }}>
          If your Custom End is 9 or lower, you are playing for practice and can get yellow badges but no new title. An End of 10 or 11 counts toward Math Wiz! Any End of 12 to 19 counts toward Senior Math Wiz 12.
        </p>
      )}
      {children}
    </Section>
  );
}

// v51: Practice Start (Ladder only) — where the partners of a practice quiz
// begin. Spinner 1..End plus Set Start (gold while the box differs from the
// setting in use, like SET RANGE). Test ALL ignores it.
function PracticeStartField({ settings, patch }) {
  // v52: a button (like Custom). Tapping it opens the spinner, Set Start,
  // Go Back and the note; Go Back closes it without changing anything.
  // The button shows the value in use when above 1 ("Practice Start: 9").
  const hi = Math.max(settings.start, settings.end);
  const inUse = practiceStartOf(settings);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(inUse);
  useEffect(() => { if (!open) setDraft(inUse); }, [inUse, open]);
  const shown = Math.min(draft, hi);
  const changed = shown !== inUse;
  return (
    <>
      <div style={{ height: 18 }} />
      <div style={s.segGroup}>
        <button
          onClick={() => { if (open) { setOpen(false); return; } setDraft(inUse); setOpen(true); }}
          style={{ ...s.segBtn, flexBasis: "100%", ...(open || inUse > 1 ? s.segBtnActive : {}) }}
        >
          {inUse > 1 ? `Practice Start: ${inUse}` : "Practice Start"}
        </button>
        {open && (
          <>
            <NumberField label="Start" value={shown} onChange={setDraft} min={1} max={hi} />
            <div style={{ flexBasis: "100%", height: 0 }} />
            <button
              onClick={() => { patch({ practiceStart: Math.max(1, shown) }); setOpen(false); }}
              style={{ ...s.segBtn, flex: "0 0 auto", minWidth: 0, padding: "9px 12px", ...(changed ? { borderColor: "#E8B94A", color: "#E8B94A" } : {}) }}
            >
              Set Start
            </button>
            <button
              onClick={() => setOpen(false)}
              style={{ ...s.segBtn, flex: "0 0 auto", minWidth: 0, padding: "9px 12px" }}
            >
              Go Back
            </button>
          </>
        )}
      </div>
      {open && (
        <p style={{ ...s.subtitle, marginTop: 10, marginBottom: 0 }}>This picks where your practice questions start, so you can skip lower facts you already know well.</p>
      )}
    </>
  );
}

const QUESTIONS_MODE_NOTE = "The In Order types remember your place. After the last finished quiz, this app will start next time right where you left off. You have to leave all the settings the same for this to work.";

export function QuestionsModeSection({ settings, patch, note, label = "Type of Questions", hideLabel }) {
  const value = modeKeyFromSettings(settings.order, settings.answerMode);
  const seg = (
    <SegGroup
      stacked
      options={QUESTIONS_MODES.map((m) => ({ v: m.key, l: m.label }))}
      value={value}
      onChange={(key) => patch(settingsFromModeKey(key))}
    />
  );
  if (hideLabel) {
    return (
      <div style={s.section}>
        {note && <div style={s.sectionNote}>{note}</div>}
        {seg}
      </div>
    );
  }
  return (
    <Section label={label} note={note}>
      {seg}
    </Section>
  );
}

const SPEED_CAPTION = "Wrong or slow answers get asked again. Normal is for learning. Fast has shorter times. Fastest has shorter times and no repeated questions.";

export function SpeedSection({ settings, patch, style }) {
  const value = settings.speedMode || "normal";
  return (
    <Section label="Speed" note={SPEED_CAPTION} style={style}>
      <SegGroup
        options={[{ v: "normal", l: "Normal" }, { v: "fast", l: "Fast" }, { v: "test", l: "Fastest" }]}
        value={value}
        onChange={(v) => patch({ speedMode: v })}
      />
    </Section>
  );
}

const ALL_NOTE = "ALL checks the settings above and gives every math question that fits the settings, one time each. Wrong or slow answers are repeated, but not with Speed Fastest.";

export function QuizLengthSection({ settings, patch, customLength, setCustomLength, presets, allCount }) {
  const active = customLength ? "custom" : (settings.length === "ALL" ? "ALL" : (presets.includes(settings.length) ? settings.length : "custom"));
  const showCustomField = customLength || active === "custom";
  return (
    <Section label="Quiz length" note={ALL_NOTE}>
      <div style={s.segGroup}>
        {presets.map((n) => (
          <button key={n} onClick={() => { setCustomLength(false); patch({ length: n }); }} style={{ ...s.segBtn, ...(active === n ? s.segBtnActive : {}) }}>{n}</button>
        ))}
        <button onClick={() => { setCustomLength(false); patch({ length: "ALL" }); }} style={{ ...s.segBtn, ...(active === "ALL" ? s.segBtnActive : {}) }}>{`ALL: ${allCount}`}</button>
        <button
          onClick={() => setCustomLength(!showCustomField)}
          style={{ ...s.segBtn, flex: "0 0 auto", minWidth: 0, padding: "9px 12px", ...(active === "custom" ? s.segBtnActive : {}) }}
        >
          Custom
        </button>
        {showCustomField && (
          <NumberField label="Questions" value={typeof settings.length === "number" ? settings.length : 20} onChange={(v) => patch({ length: v })} min={1} max={500} />
        )}
      </div>
    </Section>
  );
}

export function QuizzesPanel({ settings, patch, customStart, setCustomStart, customLength, setCustomLength, onStart, onHistory }) {
  const allCount = quizAllCount(settings);
  return (
    <>
      <p style={s.subtitle}>
        Want extra tough practice? This page asks EVERY question between the numbers you pick, Start to End, in the Range part below.
      </p>
      <div style={{ height: 36 }} />
      <OperationSection settings={settings} patch={patch} note={OPERATION_SUGGESTION_NOTE} />
      <div style={{ height: 18 }} />
      <DivideSymbolsSection settings={settings} patch={patch} />
      <div style={{ height: 18 }} />
      <QuestionsModeSection settings={settings} patch={patch} label="TYPE OF QUESTIONS - EASY TO HARD" note={QUESTIONS_MODE_NOTE} />
      <div style={{ height: 18 }} />
      <SpeedSection settings={settings} patch={patch} />
      <div style={{ height: 18 }} />
      <RangeSection settings={settings} patch={patch} customStart={customStart} setCustomStart={setCustomStart} showTitleNote={false} />
      <div style={{ height: 18 }} />
      <ExcludeEasySection settings={settings} patch={patch} />
      <div style={{ height: 18 }} />
      <QuizLengthSection settings={settings} patch={patch} customLength={customLength} setCustomLength={setCustomLength} presets={QUIZ_LENGTH_PRESETS} allCount={allCount} />
      <button style={s.primaryBtn} onClick={onStart}>Start Quiz</button>
      <button style={s.secondaryBtn} onClick={onHistory}>Scores History</button>
      <div style={{ height: 36 }} />
    </>
  );
}

// Splits a Challenge Tests title into up to two centered lines, always
// keeping "Math" and "Wiz"/"Wiz!" glued together (non-breaking space) so
// that pair never splits across a wrap. Titles with 3+ words force a line
// break positioned so a leading modifier ("Junior", "Crown"...) sits alone
// on line 1, or a trailing word ("King") sits alone on line 2 — whichever
// side doesn't separate Math from Wiz. 2-word titles ("Math Wiz!") stay a
// single glued line, no break needed.
function challengeTitleLines(bareTitle) {
  const words = bareTitle.toUpperCase().split(" ");
  if (words.length < 3) return [words.join("\u00A0")];
  const mathIdx = words.indexOf("MATH");
  if (mathIdx === 0) return [`${words[0]}\u00A0${words[1]}`, words.slice(2).join(" ")];
  return [words[0], words.slice(1).join("\u00A0")];
}

// Challenge Tests tab — each button is a fixed-content test (see
// CHALLENGE_LEVELS in logic.js) that a kid can jump straight to, skipping
// the numbers below it. Passing one backfills mastery for every number it
// covers, so the title and Levels-screen shield show up immediately.
export function ChallengesPanel({ masteredList, masteredEnd = {}, onStartChallenge, settings, patch }) {
  return (
    <>
      <p style={s.subtitle}>
        A Challenge Test is for students who know their times facts really, really well. It lets you jump ahead straight to an important step instead of learning and passing the ladder one number at a time. Pass it with every answer right, and you win that title AND every number below it — no extra practice needed. Longer tests let you miss 1 for every 100 questions.
      </p>
      <div style={{ height: 12 }} />
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {CHALLENGE_LEVELS.map(({ level, end }, i) => {
          const title = titleForNumber(level, end);
          const total = challengeTotalCount(level);
          const left = challengeLeftCount(level, masteredList, masteredEnd);
          const leftIfPrev = i === 0 ? null : challengeLeftIfPreviousPassed(level);
          const passed = isChallengePassed(level, masteredList);
          const lines = title ? challengeTitleLines(title.bare) : [`STEP\u00A0${level}`];
          const textNode = (
            <span style={{ display: "inline-block", textAlign: "center" }}>
              {lines[0]}
              {lines[1] && <><br />{lines[1]}</>}
            </span>
          );
          return (
            <button
              key={level}
              onClick={() => onStartChallenge(level)}
              disabled={left === 0}
              style={{
                ...s.segBtn,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                minWidth: 0,
                padding: "12px 14px",
                ...(passed ? { color: "#46AB68", borderColor: "rgba(70,171,104,0.6)", borderWidth: 2 } : {}),
              }}
            >
              <div style={{ flex: "1 1 auto", minWidth: 0 }}>
                <div style={{ fontSize: 11, textAlign: "center", marginBottom: 4, color: passed ? "rgba(70,171,104,0.75)" : "rgba(237,234,224,0.55)" }}>
                  {`Step ${level}`}
                </div>
                {title ? (
                  <TitleWithIcon title={title.bare} textNode={textNode} flankStar style={{ justifyContent: "center" }} />
                ) : (
                  textNode
                )}
              </div>
              <span style={{ fontSize: 12, opacity: 0.75, textAlign: "right", lineHeight: 1.5, flexShrink: 0, maxWidth: 130 }}>
                {passed ? (
                  "Passed"
                ) : (
                  <>
                    {left} left
                    <br />
                    {total} total
                    {leftIfPrev !== null && (
                      <>
                        <br />
                        {leftIfPrev} if last
                        <br />
                        challenge&nbsp;passed
                      </>
                    )}
                  </>
                )}
              </span>
            </button>
          );
        })}
      </div>
      <div style={{ height: 18 }} />
      <SpeedSection settings={settings} patch={patch} />
    </>
  );
}

export function LadderPanel({
  ladder, ladderNumbers, stepNumbers, onStartLadder, onSetLadderTrack, onSetLadderExcludeMastered, onClearYellow,
  settings, patch, customStart, setCustomStart, customLength, setCustomLength,
  onHistory, selectedMode, setSelectedMode, onExport, onImport, globalSettings, patchGlobalSettings,
  initialPreview = null,
}) {
  // v51: returning from a Ladder quiz that didn't pass opens on that number.
  const [previewNumber, setPreviewNumber] = useState(initialPreview != null ? initialPreview : ladder.currentNumber);
  const prevTrackRef = useRef(ladder.currentNumber);
  const [endWarningAck, setEndWarningAck] = useState(false);
  const fileRef = useRef(null);
  const [backupOpen, setBackupOpen] = useState(false);
  const [teacherUnlocked, setTeacherUnlocked] = useState(false);
  const [teacherModalOpen, setTeacherModalOpen] = useState(false);
  useEffect(() => { setEndWarningAck(false); }, [settings.end, settings.excludeEasy]);

  // Follow the ladder's track number when it actually advances (e.g. after
  // mastering a number), but don't fight the user's manual preview picks.
  useEffect(() => {
    if (ladder.currentNumber !== prevTrackRef.current) {
      prevTrackRef.current = ladder.currentNumber;
      setPreviewNumber(ladder.currentNumber);
    }
  }, [ladder.currentNumber]);

  // If the previewed number is no longer shown at all (rare — only if it's
  // neither in range nor ever mastered), fall back to the track number.
  useEffect(() => {
    if (previewNumber != null && !ladderNumbers.includes(previewNumber)) {
      setPreviewNumber(ladder.currentNumber);
    }
  }, [previewNumber, ladderNumbers, ladder.currentNumber]);

  const allCount = ladderAllCount(previewNumber, selectedMode, settings, ladder.excludeMastered, ladder);
  // v44: New Facts Only (Facts Passed Rule) can leave nothing to practice.
  const nothingNew = previewNumber != null && selectedMode !== "type-test" && ladder.excludeMastered && allCount === 0;

  // Sequential ("no skips") progress per chain, for gating the milestone
  // pill — same "stop at the first unmastered number" rule the username
  // title uses (shared helper, so the two can't drift apart). A number's
  // own badge/icon is NOT gated by this; only the milestone pill
  // (5/10/12/20) is.
  const { chainAHighest, chainBHighest } = chainHighestReached(ladder.mastered, ladder.masteredEnd);
  const sequentialProgressReaches = (n) => (chainAHighest != null && chainAHighest >= n) || (chainBHighest != null && chainBHighest >= n);

  return (
    <>
      <p style={s.subtitle}>
        Learn one number at a time. Pass <u>Type In · Random · Test ALL</u> with all answers correct to pass a number.
        <br /><br />
        2s is said TWOS. It means the 2 times facts: 2×1, 2×2, 2×3, and so on.
        <br />
        3s is said THREES. It means the 3 times facts, and so on.
      </p>
      <div style={{ height: 12 }} />
      {ladderNumbers.length === 0 ? (
        <p style={s.subtitle}>No numbers fit your Range. Change the Range or the SKIP the EASY FACTS setting below.</p>
      ) : (
        <>
          {stepNumbers.length === 0 && (
            <p style={s.subtitle}>No numbers fit your Range and SKIP the EASY FACTS settings. Here are the numbers you already passed.</p>
          )}
          <div style={s.segGroup}>
            {ladderNumbers.map((n) => {
              const mastered = ladder.mastered.includes(n);
              const tempMastered = (ladder.tempMastered || []).includes(n);
              const isCurrent = n === ladder.currentNumber;
              const isPreviewed = previewNumber === n;
              const quiet = "rgba(237,234,224,0.65)";
              const YELLOW = "#FFF176";
              const GOLD = "#E8B94A";
              const hasShield = mastered || tempMastered || isCurrent;
              const royalOrCrown = !mastered
                ? null
                // v49: Royal/Crown/King icons need a pass at End 20 (11-19 can
                // now also be green at End 10 or 12 — plain green shield then).
                : n < 11 || (ladder.masteredEnd?.[n] ?? 20) < 20
                ? null
                : n <= 14
                ? "diamond"
                : n <= 19
                ? "crown"
                : "king";
              const milestone = !mastered || !sequentialProgressReaches(n)
                ? null
                : n === 5 || n === 10 || n === 20
                ? titleForNumber(n, ladder.masteredEnd?.[n])
                : n === 12 && ladder.masteredEnd?.[12] !== 20
                ? titleForNumber(n, ladder.masteredEnd?.[n])
                : n === 15
                ? titleForNumber(n, ladder.masteredEnd?.[n])
                : null;
              const milestoneTitle = milestone ? (n === 12 ? milestone.numbered : milestone.bare) : null;
              const tempCurrent = isCurrent && passEndFor(settings.end) == null;
              // v51: yellow (practice) pills show their End ("12s to 16") and
              // grow wider as needed; green pills are unchanged. A number with
              // both gets two pills: green first, then yellow.
              const yellowEnd = ladder.tempMasteredEnd || settings.end;
              const yellowOnly = tempMastered && !mastered;
              const bothBadges = tempMastered && mastered;
              const yellowPillStyle = (active) => ({
                ...s.segBtn,
                position: "relative",
                minWidth: 92,
                ...(active ? s.segBtnActive : { color: YELLOW, borderColor: GOLD }),
                borderWidth: 2,
                padding: "8px 2.9em 8px 9px",
              });
              return (
                <div key={n} style={{ display: "contents" }}>
                  {yellowOnly ? (
                    <button onClick={() => setPreviewNumber(n)} style={yellowPillStyle(isPreviewed)}>
                      <span>{n}s to {yellowEnd}</span>
                      <ShieldBadge fill={YELLOW} outline star active={isPreviewed} />
                    </button>
                  ) : (
                  <button
                    onClick={() => setPreviewNumber(n)}
                    style={{
                      ...s.segBtn,
                      position: "relative",
                      minWidth: 92,
                      ...(!isPreviewed && !mastered && !tempMastered ? { color: quiet, borderColor: quiet } : {}),
                      ...(isCurrent && !tempCurrent && !isPreviewed ? { color: "#EDEAE0", borderColor: "#EDEAE0" } : {}),
                      ...(isPreviewed ? s.segBtnActive : {}),
                      ...(tempMastered && !mastered && !isPreviewed ? { color: YELLOW, borderColor: GOLD, borderWidth: 2, padding: "8px 9px" } : {}),
                      ...(tempCurrent && !isPreviewed ? { color: YELLOW, borderColor: GOLD, borderWidth: 2, padding: "8px 9px" } : {}),
                      ...(mastered && !isPreviewed ? { color: "#46AB68", borderColor: "rgba(70,171,104,0.6)", borderWidth: 2, padding: "8px 9px" } : {}),
                    }}
                  >
                    <span style={{ position: "relative", left: hasShield ? (royalOrCrown === "king" ? "-1.6em" : "-1.1em") : 0 }}>{n}s</span>
                    {royalOrCrown === "diamond" ? (
                      <DiamondIcon size="1.8em" style={{ position: "absolute", right: "0.73em", top: "50%", transform: "translateY(-50%)" }} />
                    ) : royalOrCrown === "crown" ? (
                      <CrownIcon size="1.8em" style={{ position: "absolute", right: "0.73em", top: "50%", transform: "translateY(-50%)" }} />
                    ) : royalOrCrown === "king" ? (
                      <CrownIcon size="3.6em" style={{ position: "absolute", right: "0.2em", top: "50%", transform: "translateY(-50%)" }} />
                    ) : mastered ? (
                      <ShieldBadge fill="#46AB68" star />
                    ) : tempMastered ? (
                      <ShieldBadge fill={YELLOW} outline star active={isPreviewed} />
                    ) : tempCurrent ? (
                      <TriangleMarkerTemp active={isPreviewed} />
                    ) : isCurrent ? (
                      <TriangleMarker />
                    ) : (
                      ""
                    )}
                  </button>
                  )}
                  {bothBadges && (
                    <button onClick={() => setPreviewNumber(n)} style={yellowPillStyle(isPreviewed)}>
                      <span>{n}s to {yellowEnd}</span>
                      <ShieldBadge fill={YELLOW} outline star active={isPreviewed} />
                    </button>
                  )}
                  {milestone && <MilestoneButton title={milestoneTitle} />}
                </div>
              );
            })}
          </div>
          {/* v43: one note for ANY tapped passed number (green or yellow),
              in or out of range. Replaces the old outside-range note and the
              "This isn't your current ladder step" note + link (any unpassed
              in-range number can now be passed with Test ALL). */}
          {/* v51: green and yellow get their own notes; a number with both
              badges shows both. */}
          {previewNumber != null && ladderNumbers.includes(previewNumber) && ladder.mastered.includes(previewNumber) && (
            <p style={{ ...s.subtitle, marginTop: 12, marginBottom: 0 }}>This number is already passed. You can still practice it.</p>
          )}
          {previewNumber != null && ladderNumbers.includes(previewNumber) && (ladder.tempMastered || []).includes(previewNumber) && (
            <p style={{ ...s.subtitle, marginTop: 12, marginBottom: 0 }}>This number has a practice pass through {ladder.tempMasteredEnd || settings.end}. You can still practice it.</p>
          )}
        </>
      )}
      {/* v43: standard 36px section gap before RANGE (was 18). */}
      <div style={{ height: 36 }} />
      <RangeSection
        settings={settings} patch={patch} customStart={customStart} setCustomStart={setCustomStart}
        yellowEnd={(ladder.tempMastered || []).length > 0 ? (ladder.tempMasteredEnd || 0) : null}
        onClearYellow={onClearYellow}
        subLabel="Ladder Range"
        allow1to20={false}
      >
        <PracticeStartField settings={settings} patch={patch} />
      </RangeSection>
      <div style={{ height: 18 }} />
      <ExcludeEasySection settings={settings} patch={patch} />
      {/* v49 (audit 5b): titles need the 1s and 10s, which SKIP On hides. */}
      {settings.excludeEasy && Math.min(settings.start, settings.end) <= 10 && (
        <p style={{ ...s.subtitle, marginTop: -6, marginBottom: 10 }}>To win a title through Step 10 or Step 12, set SKIP the EASY FACTS to Let App Pick, or to Off. The 1s and 10s are steps you need to pass.</p>
      )}
      {/* v49 (audit 2): Test ALL on 1-10 always asks ×1/×10 (choice B), so
          only End 9 or lower is too small for a green pass. */}
      {passEndFor(settings.end) == null && selectedMode === "type-test" && !endWarningAck && (
        <p style={{ ...s.subtitle, color: "#E8B94A", marginBottom: 10 }}>
          This range is too small to pass a Math Wiz Ladder step. You can win a yellow practice badge.{" "}
          <button
            onClick={() => setEndWarningAck(true)}
            style={{ background: "none", border: "none", padding: 0, color: "#E8B94A", fontWeight: 600, cursor: "pointer", textDecoration: "underline", font: "inherit" }}
          >
            Continue Practicing
          </button>
          {" "}or{" "}
          <button
            onClick={() => { setCustomStart(true); setEndWarningAck(true); }}
            style={{ background: "none", border: "none", padding: 0, color: "#E8B94A", fontWeight: 600, cursor: "pointer", textDecoration: "underline", font: "inherit" }}
          >
            Change Range
          </button>
          .
        </p>
      )}
      <div style={{ height: 18 }} />
      <OperationSection settings={settings} patch={patch} displayOverride={selectedMode === "type-test" ? "both" : null} note={OPERATION_SUGGESTION_NOTE} />
      <div style={{ height: 18 }} />
      <DivideSymbolsSection settings={settings} patch={patch} />
      {previewNumber != null && ladderNumbers.includes(previewNumber) && (
        <>
          <div style={{ height: 18 }} />
          {/* v53: text at 80% like the other section titles (number full). */}
          <div style={{ ...s.sectionLabel, textTransform: "none" }}>
            <span style={{ color: "#EDEAE0" }}>{previewNumber}s</span> — TYPE OF QUESTIONS - EASY TO HARD
          </div>
          {/* v42: 5 modes on the Ladder — the usual 4 (all practice) plus
              Type In · Random · Test ALL, the only way to pass a number.
              Stacked, so the 5th is its own full-width row like the rest. */}
          <div style={s.section}>
            <div style={s.sectionNote}>{QUESTIONS_MODE_NOTE}</div>
            <SegGroup
              stacked
              options={LADDER_MODES.map((m) => ({ v: m.key, l: m.label }))}
              value={selectedMode}
              onChange={setSelectedMode}
            />
          </div>
          <p style={{ ...s.subtitle, marginTop: 8, marginBottom: 18 }}>
            <u>Type In · Random · Test ALL</u> gives ALL questions for that number — both Multiply and Divide. It is the only way to pass a number.
          </p>
        </>
      )}
      <div style={{ height: 18 }} />
      <Section label="Which Facts">
        <SegGroup
          options={[{ v: false, l: "All Facts" }, { v: true, l: "New Facts Only" }]}
          value={ladder.excludeMastered}
          onChange={onSetLadderExcludeMastered}
        />
      </Section>
      <p style={{ ...s.subtitle, marginTop: -8, marginBottom: 0 }}>
        New Facts Only skips facts already passed. <u>Type In · Random · Test ALL</u> always tests everything, no matter this setting.
      </p>
      {previewNumber != null && ladderNumbers.includes(previewNumber) ? (
        <>
          <div style={{ height: 36 }} />
          <SpeedSection settings={settings} patch={patch} />
          <div style={{ height: 18 }} />
        </>
      ) : (
        <div style={{ height: 36 }} />
      )}
      <QuizLengthSection settings={settings} patch={patch} customLength={customLength} setCustomLength={setCustomLength} presets={LADDER_LENGTH_PRESETS} allCount={allCount} />
      {nothingNew && (
        <p style={{ ...s.subtitle, marginTop: 0, marginBottom: 10 }}>All these facts are passed. Pick All Facts to practice them.</p>
      )}
      <button style={{ ...s.primaryBtn, ...(nothingNew ? { opacity: 0.5, cursor: "default" } : {}) }} disabled={previewNumber == null || nothingNew} onClick={() => onStartLadder(previewNumber, selectedMode)}>Start Quiz</button>
      <button style={s.secondaryBtn} onClick={onHistory}>Scores History</button>
      <div style={{ height: 36 }} />
      {/* Backup collapsible: one centered Backup button (same height as
          Teacher Settings). Opens the save/restore row + explanation and
          becomes Done; Done hides them. Always starts closed (not saved). */}
      <div style={{ display: "flex", justifyContent: "center" }}>
        <button style={{ ...s.backupBtn, flex: "none", padding: "16px 20px" }} onClick={() => setBackupOpen((o) => !o)}>{backupOpen ? "Done" : "Backup"}</button>
      </div>
      {backupOpen && (
        <>
          <div style={{ ...s.backupRow, marginTop: 12 }}>
            <button style={s.backupBtn} onClick={onExport}>Save Backup File</button>
            <button style={s.backupBtn} onClick={() => fileRef.current && fileRef.current.click()}>Restore from File</button>
          </div>
          <p style={{ ...s.subtitle, marginTop: 10, marginBottom: 0 }}>This is for saving history and settings for all users to use on another browser or device.</p>
        </>
      )}
      <input
        ref={fileRef}
        type="file"
        accept="application/json"
        style={{ position: "absolute", width: 1, height: 1, padding: 0, margin: -1, overflow: "hidden", clip: "rect(0,0,0,0)", whiteSpace: "nowrap", border: 0 }}
        onChange={(e) => { onImport(e.target.files && e.target.files[0]); e.target.value = ""; }}
      />
      <div style={{ height: 1, background: "rgba(237,234,224,0.65)", margin: "12px 0" }} />
      <div style={{ display: "flex", justifyContent: "center" }}>
        {teacherUnlocked ? (
          <NumberField label="Answer time threshold (seconds)" value={globalSettings.slowThresholdSeconds ?? 5} onChange={(v) => patchGlobalSettings({ slowThresholdSeconds: v })} min={1} max={30} />
        ) : (
          <button style={{ ...s.backupBtn, flex: "none", padding: "16px 20px" }} onClick={() => setTeacherModalOpen(true)}>Teacher Settings</button>
        )}
      </div>
      {teacherModalOpen && (
        <ConfirmModal
          title="Teacher Settings"
          onSubmit={async (code) => {
            if (code === TEACHER_PASSCODE) { setTeacherUnlocked(true); setTeacherModalOpen(false); return true; }
            return false;
          }}
          onCancel={() => setTeacherModalOpen(false)}
        />
      )}
    </>
  );
}
