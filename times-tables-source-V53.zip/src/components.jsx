import { useState, useEffect } from "react";
import { s } from "./styles.js";
import { APP_PASSCODE, UNLOCK_KEY } from "./logic.js";

export function PasscodeGate({ children }) {
  const [unlocked, setUnlocked] = useState(() => {
    try { return window.localStorage.getItem(UNLOCK_KEY) === "true"; } catch { return false; }
  });
  const [value, setValue] = useState("");
  const [wrong, setWrong] = useState(false);
  const [show, setShow] = useState(false);

  if (unlocked) return children;

  const submit = () => {
    if (value === APP_PASSCODE) {
      try { window.localStorage.setItem(UNLOCK_KEY, "true"); } catch {}
      setUnlocked(true);
    } else {
      setWrong(true);
    }
  };

  return (
    <div style={s.appBg}>
      <div style={s.card}>
        <h1 style={s.h1}>Enter Password</h1>
        <div style={s.passRow}>
          <input
            style={{ ...s.nameInput, marginBottom: 0 }}
            type={show ? "text" : "password"}
            placeholder="Password"
            value={value}
            onChange={(e) => { setValue(e.target.value); setWrong(false); }}
            onKeyDown={(e) => { if (e.key === "Enter") submit(); }}
          />
          <button type="button" style={s.passToggleBtn} onClick={() => setShow((v) => !v)}>{show ? "Hide" : "Show"}</button>
        </div>
        {wrong && <p style={{ color: "#E8664A", fontSize: 13 }}>Incorrect password.</p>}
        <button style={s.primaryBtn} onClick={submit}>Continue</button>
      </div>
    </div>
  );
}

const overlayStyle = { position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, zIndex: 50 };

export function ConfirmModal({ title, onSubmit, onCancel }) {
  const [value, setValue] = useState("");
  const [show, setShow] = useState(false);
  const [wrong, setWrong] = useState(false);

  const submit = async () => {
    const ok = await onSubmit(value);
    if (!ok) { setWrong(true); setValue(""); }
  };

  return (
    <div style={overlayStyle} onClick={onCancel}>
      <div style={s.card} onClick={(e) => e.stopPropagation()}>
        <h1 style={s.h1}>{title}</h1>
        {/* v53: 10 px box→Confirm and Confirm→Go Back, like the other pop-ups. */}
        <div style={{ ...s.passRow, marginTop: 14, marginBottom: 0 }}>
          <input
            style={{ ...s.nameInput, marginBottom: 0 }}
            type={show ? "text" : "password"}
            placeholder="Password"
            value={value}
            autoFocus
            onChange={(e) => { setValue(e.target.value); setWrong(false); }}
            onKeyDown={(e) => { if (e.key === "Enter") submit(); if (e.key === "Escape") onCancel(); }}
          />
          <button type="button" style={s.passToggleBtn} onClick={() => setShow((v) => !v)}>{show ? "Hide" : "Show"}</button>
        </div>
        {wrong && <p style={{ color: "#E8664A", fontSize: 13, margin: "10px 0 0" }}>Incorrect password.</p>}
        <button style={{ ...s.primaryBtn, display: "block", marginTop: 10 }} onClick={submit}>Confirm</button>
        <button style={{ ...s.backupBtn, display: "block", marginTop: 10, fontSize: s.passToggleBtn.fontSize, color: s.passToggleBtn.color, fontWeight: s.passToggleBtn.fontWeight, padding: "16px" }} onClick={onCancel}>Go Back</button>
      </div>
    </div>
  );
}

// v44: cancelLabel={null} hides the second button (single-button info
// pop-up); backdropClose={false} stops a tap outside the card from acting
// as the cancel button (used by the fail pop-up, where cancel = Stop).
export function YesNoModal({ title, message, confirmLabel = "Yes", cancelLabel = "No", onConfirm, onCancel, backdropClose = true }) {
  return (
    <div style={overlayStyle} onClick={backdropClose ? (onCancel || onConfirm) : undefined}>
      <div style={s.card} onClick={(e) => e.stopPropagation()}>
        <h1 style={s.h1}>{title}</h1>
        {message && (typeof message === "string" ? <p style={{ ...s.subtitle, marginTop: 6 }}>{message}</p> : <div style={{ ...s.subtitle, marginTop: 6 }}>{message}</div>)}
        <button style={{ ...s.primaryBtn, marginTop: 16 }} onClick={onConfirm}>{confirmLabel}</button>
        {cancelLabel != null && <button style={{ ...s.backupBtn, fontSize: s.passToggleBtn.fontSize, color: s.passToggleBtn.color, fontWeight: s.passToggleBtn.fontWeight, padding: "16px", marginTop: 10, width: "100%" }} onClick={onCancel}>{cancelLabel}</button>}
      </div>
    </div>
  );
}

export function Toast({ message, tone = "info", onDismiss }) {
  if (!message) return null;
  const color = tone === "error" ? "#E0785A" : "#8FBF8A";
  return (
    <div style={{ marginBottom: 14, padding: "10px 12px", borderRadius: 10, background: "rgba(255,255,255,0.05)", border: `1px solid ${color}55`, color, fontSize: 13, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
      <span>{message}</span>
      <button onClick={onDismiss} style={{ background: "none", border: "none", color, fontWeight: 700, padding: 0 }}>✕</button>
    </div>
  );
}

export function Section({ label, note, children, style }) {
  return (
    <div style={{ ...s.section, ...style }}>
      <div style={s.sectionLabel}>{label}</div>
      {note && <div style={s.sectionNote}>{note}</div>}
      {children}
    </div>
  );
}

export function SegGroup({ options, value, onChange, disabled, stacked }) {
  return (
    <div style={stacked ? s.segGroupStacked : s.segGroup}>
      {options.map((o) => (
        <button
          key={String(o.v)}
          onClick={() => !disabled && onChange(o.v)}
          disabled={disabled}
          style={{ ...s.segBtn, ...(stacked ? s.segBtnStacked : {}), ...(value === o.v ? s.segBtnActive : {}), ...(disabled ? { opacity: 0.5, cursor: "default" } : {}) }}
        >
          {o.l}
        </button>
      ))}
    </div>
  );
}

// `commitOnBlurOnly`: when true, typing only updates the displayed text —
// onChange fires just once, on blur/Enter, after clamping. Used by fields
// (like Range) whose commit needs to go through a confirmation step rather
// than applying on every keystroke.
export function NumberField({ label, value, onChange, min, max, commitOnBlurOnly }) {
  const [text, setText] = useState(String(value));
  const selectTimer = useState(() => ({ current: null }))[0];
  const ref = useState(() => ({ current: null }))[0];
  const prevValueRef = useState(() => ({ current: value }))[0];
  const liveRef = useState(() => ({ current: value }))[0];
  const holdTimeout = useState(() => ({ current: null }))[0];
  const holdInterval = useState(() => ({ current: null }))[0];
  const holdFiredRef = useState(() => ({ current: false }))[0];
  const lastTouchRef = useState(() => ({ current: 0 }))[0];

  if (prevValueRef.current !== value && document.activeElement !== ref.current) {
    prevValueRef.current = value;
    liveRef.current = value;
    if (text !== String(value)) setText(String(value));
  }

  const commit = (raw) => {
    const n = parseInt(raw, 10);
    if (isNaN(n)) { setText(String(value)); liveRef.current = value; return; }
    const clamped = Math.max(min, Math.min(max, n));
    liveRef.current = clamped;
    setText(String(clamped));
    onChange(clamped);
  };
  // Reads/writes liveRef rather than the `text` state directly, so repeated
  // calls from a held-down interval always see the latest value instead of
  // a stale one captured when the press started.
  const applyDelta = (delta) => {
    const base = parseInt(liveRef.current, 10);
    const current = isNaN(base) ? value : base;
    const clamped = Math.max(min, Math.min(max, current + delta));
    liveRef.current = clamped;
    setText(String(clamped));
    onChange(clamped);
  };
  const clearHold = () => {
    clearTimeout(holdTimeout.current);
    clearInterval(holdInterval.current);
    holdTimeout.current = null;
    holdInterval.current = null;
  };
  const startHold = (delta) => {
    clearHold();
    holdFiredRef.current = true;
    applyDelta(delta);
    holdTimeout.current = setTimeout(() => {
      holdInterval.current = setInterval(() => applyDelta(delta), 125);
    }, 450);
  };
  // Fallback: if mousedown/touchstart didn't fire for some reason (browser
  // quirk), a plain click still increments once rather than the button
  // doing nothing at all.
  const handleClick = (delta) => {
    if (holdFiredRef.current) { holdFiredRef.current = false; return; }
    applyDelta(delta);
  };
  const holdSelect = () => {
    clearTimeout(selectTimer.current);
    selectTimer.current = setTimeout(() => { ref.current && ref.current.select(); }, 450);
  };
  const cancelHold = () => clearTimeout(selectTimer.current);

  return (
    <label style={s.numberField}>
      <span style={s.numberFieldLabel}>{label}</span>
      <div style={s.stepperRow}>
        <button
          type="button"
          style={s.stepperBtn}
          onMouseDown={() => { if (Date.now() - lastTouchRef.current < 800) return; startHold(-1); }}
          onMouseUp={clearHold}
          onMouseLeave={clearHold}
          onTouchStart={(e) => { e.preventDefault(); lastTouchRef.current = Date.now(); startHold(-1); }}
          onTouchEnd={clearHold}
          onTouchCancel={clearHold}
          onClick={() => handleClick(-1)}
          aria-label={`Decrease ${label}`}
        >
          -
        </button>
        <input
          ref={(el) => (ref.current = el)}
          type="number"
          min={min}
          max={max}
          value={text}
          onChange={(e) => {
            const v = e.target.value;
            setText(v);
            liveRef.current = v;
            if (!commitOnBlurOnly) {
              const n = parseInt(v, 10);
              if (!isNaN(n) && n >= min && n <= max) onChange(n);
            }
          }}
          onBlur={(e) => commit(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") commit(e.target.value); }}
          onTouchStart={holdSelect}
          onTouchEnd={cancelHold}
          onTouchMove={cancelHold}
          onMouseDown={holdSelect}
          onMouseUp={cancelHold}
          onMouseLeave={cancelHold}
          style={s.numberInput}
        />
        <button
          type="button"
          style={s.stepperBtn}
          onMouseDown={() => { if (Date.now() - lastTouchRef.current < 800) return; startHold(1); }}
          onMouseUp={clearHold}
          onMouseLeave={clearHold}
          onTouchStart={(e) => { e.preventDefault(); lastTouchRef.current = Date.now(); startHold(1); }}
          onTouchEnd={clearHold}
          onTouchCancel={clearHold}
          onClick={() => handleClick(1)}
          aria-label={`Increase ${label}`}
        >
          +
        </button>
      </div>
    </label>
  );
}

// ---------- v45: Intro screens ----------
// Shown each time the app is opened (and right after a brand-new first user
// enters their name), counted per user. `showing` = which showing this is:
// 1st → Next appears after 10 s on every screen, 2nd → 5 s, 3rd → 3 s,
// 4th+ → Next right away plus "Skip Intro" on every screen but the last
// (there it would do the same as Let's Go!). Next fades in with no
// countdown, so kids read instead of watching numbers. A screen's second
// paragraph gets a larger gap above it.
export const INTRO_SCREENS = [
  ["This app will let you go at your own speed. You can start with multiplying by 1.",
   "Knowing your math facts makes your future math, science, and computer classes much, much easier. It helps you become a Wiz with money too!"],
  ["Do a few quizzes every day, and you will learn because you keep going over the math facts again and again.",
   "Knowing your math facts makes it a lot harder for other people to fool you. It even makes it harder for leaders if they try to fool you."],
  ["This app shows you the right answers every time, right after you answer, so just look at and think about each fact for a couple seconds. If you put a lot of attention on the math facts, you can learn them faster."],
  ["There are two extra sections for students who want more work: Quizzes has longer quizzes, and Challenge Tests is for skipping ahead if you know it all.",
   "Keep Quizzing, and you will become a Math Wiz!"],
];
const INTRO_DELAY_SECONDS = { 1: 10, 2: 5, 3: 3 };

export function IntroScreen({ showing, onDone }) {
  const [screen, setScreen] = useState(0);
  const delay = INTRO_DELAY_SECONDS[showing] ?? 0;
  const [nextVisible, setNextVisible] = useState(delay === 0);
  useEffect(() => {
    if (delay === 0) { setNextVisible(true); return; }
    setNextVisible(false);
    const id = setTimeout(() => setNextVisible(true), delay * 1000);
    return () => clearTimeout(id);
  }, [screen, delay]);
  const last = screen === INTRO_SCREENS.length - 1;
  const canSkip = showing >= 4 && !last;
  return (
    <div style={{ ...s.card, display: "flex", flexDirection: "column", minHeight: 360 }}>
      <div style={s.headerRow}>
        <span style={s.times}>×÷</span>
        <div>
          <h1 style={s.h1}>Times Tables 20</h1>
          <p style={s.subtitle}>from <span style={{ color: "#EDEAE0" }}>Be A Math Wiz</span></p>
        </div>
      </div>
      <div style={{ flex: 1, marginTop: 6 }}>
        {INTRO_SCREENS[screen].map((p, i) => (
          <p key={i} style={{ color: "#EDEAE0", fontSize: 18, lineHeight: 1.55, margin: i > 0 ? "34px 0 14px" : "0 0 14px" }}>{p}</p>
        ))}
      </div>
      <button
        style={{ ...s.primaryBtn, marginTop: 12, opacity: nextVisible ? 1 : 0, transition: "opacity 0.4s ease", pointerEvents: nextVisible ? "auto" : "none" }}
        aria-hidden={!nextVisible}
        tabIndex={nextVisible ? 0 : -1}
        onClick={() => (last ? onDone() : setScreen((n) => n + 1))}
      >
        {last ? "Let's Go!" : "Next"}
      </button>
      {canSkip && (
        <button style={{ ...s.backupBtn, width: "100%", marginTop: 10, padding: "12px" }} onClick={onDone}>Skip Intro</button>
      )}
    </div>
  );
}

export function NameGate({ value, setValue, onSubmit }) {
  return (
    <div style={s.card}>
      <div style={s.headerRow}>
        <span style={s.times}>×÷</span>
        <div>
          <h1 style={s.h1}>Welcome</h1>
          <p style={s.subtitle}>Enter a name to get started</p>
        </div>
      </div>
      <input
        style={s.nameInput}
        placeholder="Your name"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter") onSubmit(); }}
        autoFocus
      />
      <button style={{ ...s.primaryBtn, marginTop: 14 }} onClick={onSubmit}>Get started</button>
    </div>
  );
}

export const MAX_USERS = 3;

// Small gold "tier" icons used next to titles wherever they're displayed,
// and (bigger, unpositioned) as the mastered-badge replacement for
// Royal/Crown/King numbers on the ladder — no shield behind them.
const DIAMOND_IMG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ0AAACACAYAAAARbmuTAAArsElEQVR42u2deXRcxZX/762q915vasmStXnD2BibLQk2SSbLROHMnJkMSX5DsGXMNplsTCaQ5Dckc8iECW0xgB0mMMmPjDOEIUDAm8TqlTUgCASIMdhabGzZWqzNltTqfXmvqu7vj24ZG2xjyS2pZavO6XN8ju3Tr9/7vPut771VtwAmx+SYHJPjdB84nl9eXQ28urp6Qt646urzKfOnCxDqAGAi/IzsddbV1UFTUx3V1IA+o2gnGl/gJwdAAICNx/eK8YpwiKBuuWbOP5WXeD6nCRQB5T+EBMA4B5IpjKfNWEGRWxROKfA6KSlR8Py/fK1BGBwioaje/tZ7v6l5JfLn6mrgdXWgTmt5DQSqRE1Nvbzl2rNvOPeswnvKKoq6KkoLzk47ChjmM28EiAI4pSGSdrV+4iv/XuIkukNC7SqeMr3SB4kU5PkPABAIsVAKkgOtnQ073qObf7jli29Hcf+SxTSm4OF4APev1WddddH84tVTCl2YctS7ldNKShjCNKVJA2D+PTkiAM6J6TQHXrD9ksU/LzA91nwAlgr1NL/rweZppqtgFqRtBxjDzBPOK+AQiAhcFkb6D73rhUPTeKG3ckvtm81Lb3j+0gTDQ7f+jNhYzfHGTBNqq4HfuKpd/eDyaV/52PySR4oKXSLtaGBAxUrrvR6POU0q4tlrYvnyISIGjKMghyv07lx0xQq/y+s+VycihFoaLn9lZTisWlB2ofD4inTKRkTkQMDy50MIpuB20u5zom0pd4E1F+K2nHfh9PIFleKz659re/LVVzF5KwGrH4M3ZkwmktXVwJfWgfrW35R/6sJ5JY8WF3s8aUcBEIAQzErEUmXJlGy1TI6aKK/CBDJOAhxUzPvuJYtXet0+zzk6GSHGDSQiACfOiyovXJjQC7rS8XA387kQFFHeRWtgKh7u6fC52TywNRCRAEfJK6769OceXf6Zh7Um9/LMZY+60oixAK6uDtRVX5g675MXlm4sL/UWptJKM0QGAOBIIsbwrFAott00i5Ic0U2Ztw3zgDgS6KAEz45LFq/wur2ec3QySowJBCBAzKgWUxnwQj2wnWK70eUtrIR4moDnwVRBE4HbxEQ03mFSpJhbbhckHUKGSFILRJRLr/vMVxO2/TtEvIqIGGYumyZkpAsEgNXVgbrurytnfXZh+cbplb4y29aK4fvfSwTAGGPSdmYlkvZe0+CQF8FuCDhy77hk8UqP2+udlwGOHwUSIgJpOAxeQs/vTMejPeC18iHiEXFEpSiVCnX1ud3ibEhLApahChFB20oYhiGvuvqzy375gwt/jYiaqHpUueCjCdxtt6H+m/P9xVWfKn3qnFlFH0+mtQI8+jsRAZUmMgT3pZJOr8dnCc6ZV2sgxPGKdowEc9Ah985LFq/0eAp883Qy8iHgjgKPABg4zPJPr4hG1W6mepjwegqOfMhjH+U0oMfC6GBwtxcHK4VlFoDUmQs+4tq1o5hV4JYLzi3/C28qLL/4tVfrX3qpSjz8cLueMJGOAHD5ciIicn3pi9PXnTOr6NOJtPwQcEdaaE0EpNWcSCTZjgzHMUQcAdySFa6PAu7DES/Biys/tjCu5h1IxyO94xbxiAgMgU7SCal4r2N6XBWQknQkcId/MUPQCVsUlRapb/5T1e23XD3rhksvrZf3Xb/ImCiRDiEAeOmlNfzn3zl39bw5RV+1JUkAFCf4H6g1kGVwK5W0Iy6PK2WZvFApTYhjGSUYCSbR0VYWOP+5JwPcByMegs0s/4zyaNTZzVQPF17v2Ec8IgDLxNjAwaYCMzmXIXNlLg6PG6112sHCiiI9Y1rRl4xIeN8ta3bteClQJR6uz23EyzV0WFsL7MYbQd/2jbn3XnBuydelBkn00YYFEVBlamNF0lF7PV6rlAj42BkKRgaT6Ghz5yVLVmaAS0SIcT6s739faiWz/DPLoxFnN1c9nI8leJQxD6l4qkvHO8ntc80A+9hR7uhpLKJKOVh61lQ2o8L7d5Hu7u0/enj3nkBVlahvzx14OYUuEKgSN97YrpZfd84dF80vuUkDSq1InOxtJgISBue2LbVpGn0ul5gqxyTaZYFTZsMl1SstT4F/vk6EiXExou897Gqz4EUizm6meoTwen1jAh4CaBQqOtC51+/RC0CCONn5MWOIOulQ+ewyc2Z5wd/37W178b439x2orQZe15wbR8tzCVxNTb382TVn33TeOcW3G4IpqYgPxwwgAipFJDgrTKWcNrfX5WcI1uimUBgZXKIkY+eiK1ZaHn/hKQF3TPAKZpZHI84upnoM4fX6tC1H70XSmsDjwkQk2mLYBwtNj6sEHfWRUe6DEU+npZ4xv8JVUeL5cnDPnmfveAUPVlcDb84BeDmB7vrrFxn33PMneXP1rGvPn1fyG69XkCM1G8mNxezbJqV2o+CtHo9RIaWG0XlIQxHOaFi0eKXpKSxckAvgjgle4czyaNjZharHNDyjBh4BZ+goiCeD7V1+Hz8PbA0jiayIiJBWavZF0wsLfa6/emvzvqde343hW28FVl9/auCdMnSBKhD3PNEjb7p81lcuOq94jb/ARNshHPENzZoK0+TuVDLd5/a4gHPmy30K5X3gFl5xh+ktnJJT4I4BHrcKZ5ZHQ/Yupnoz4DlObsHTBOCyMD7Yv9vNIjOEYXhBaYARfgcBMLSVmvexGaWzZ5pfWLu1tfbVV1nqVqJTKpexUwWuph7kDV+e/sULFhQ9Wuh3CdshOFU4sjILoOmcSDjRzhjo3CbIM5JqK9648Io7DW9RyfzRAO7odAoBUwmjaPonFsbl3NZ0MnKIeVyotc7NDyMisAQ6yVQ/JXrJ8lqlkJYEpwA1IgARcUgp9dUrFl2y5o7P12qtPcsz2Xscc+iqq4HX1IO8/q/LLrpg/pTa0hJvoe0oQsxN7k9pImFwdyKWLEmlVZtpcqQclCroKOBWCG9R8QKdDI0acMcCr3D6JxZGnbNb04loDsEjAGAUC/a1ed04D2wCyoFhQUQgpThqkMuu+Yu/uf+nix5AREZEOFLwRgTIUHnra58qnvGxC0s3zaz0lSbTSmO2npqbhwToSA2M4exwKD6gNaROWYkY0yZX6EjeuPDyFcJXVJIBjokxScsMgcdVwpgy7eKFUWd2azoZ7Ttl8LLLlhLx5AGTgn7hsjwgVc5WxSIikK0EIpPXfv3zy+696RO/QURNL1WNKKXFRwLcbbeB/uqny8r/6i/KNs+e4V+QSmuFmPtEMxGAwRmz0w43TaPT4xbljhxhCgWZNphitmKNi762gvumlJw3lsB9aI6HkrsKZ5WFQ8ldnA5ahtvrHfEcjyFIYE68r72lwIMXgCSW6xIiIgJJzQyvS847p/STUyDu/svvb3uOqJrX1DTTqEW6AABbvpzovKngu/SS4tVzZxVenLL1cctbOYh2YEtNwuAVg4MxKaUeNDhDGuYED1kWOIc1Lbz8Tu4dJ+COliwCppJm8fSFF0ft2fvtdLSPuUcQ8bQmcJkYD4f2eURiBjMER9KjUnZDhqDjaTGlrEh9/Rufv/mny2b/ALFO3Xff8Mplw4EFXyZAxBp28z/MX3vunCmXJR114vJWjmQ285C0Gxjb73ZblVINI4UyFOEcbFr4tTuZr7j0PJ0Y/TnccCKeVXhWWXQw2czhkCVcw4h4BAQGQ+lQJB3qOFhQYJwLaQmjmXxGlimXFZT59dmzSy7jg/2tt9z93jv3Xb/I2PR2j84ldEgBQLwU9B3fPPfB+XOLljkaJGkQY1FNzNZlXclEetDttWzDYH6lPjqFQsDI5JqlbWpetHgl+opLz88H4D5kLlBxs3BWWXQw0czgkMs4WfBIA7hcGB042OwVsbM5F27QGkd7xT8yRJ1ysHh6MU2f5r9MRII7f7Z2z66TLZedFHRUCxxvBH3rdXN/ftGC4huIUGlNYqzK19m6LCFAkVJ6r9vjKtdEDE8wiSVgZHGNaZuaL75iBRQUl54/Fi71VMCzCs8qDQfjuwT2uT4y4hERuAxMJ9I9KnbA9vjdsyA1dosKkCGqpAMVc8uN8mLXZdH21j/++rX9bYEqEPXtJ95r8ZHQ3Xf9IuOSn/TIW66Z85OPLygJIGdSqbED7ihTYXCRTNvScpkDbkuUHK8uS8DIEhpTtm6++IoV4C8uP38853AnD54UVuFZpdHBWDOHfpdweU4InuZCR/u69vjczgKmkBOO7a4mxhB1ytbTzqlwlxUXXN6+/b1NDzV8dLmMnzj5WyV+/MSf5L9dPfs758+d8iuXSygph1dPzWm0U0SCsUI7Lfd7vNYUADCPB1za1rsuvvxO8JdUnK+Tg3kL3DEinjALzyqNBmPNnB0HPE0EHgsTkVirYfd6LJ+nFGwJY7sM7PB1o7alnr1gmmdaqfey5jdbNr24DQdOBB4/PnAgaurb5U1XzLj8onOLH/L7LUw7mjEc13X/yDmilMriQrRl67KHHwgBkiU0JlO06+Kv3an9U8svyOcIdyzwQBMNgRcORpsNNvBh8BiC1JBKDLa3+314PqQ1jNvq5Cx44Cg19+Mzi8uniM9veqb1yZ27Wex45bJjQldVBeLhepDf/0pF1cfPn/pkUaHbTNsaGcNxdnwZU2EK5k0m04c8XhfnjHlJAxEiWIIwbdOuiy+/Q/unVkwo4I4iTxMxpoTlP6s0FIw2CxxwC5fbox1JSADgtjAWGnzPBaFpwrAKQCkc7+3CRMRQKrXg4zOnz6vgn6x9rq32ZSIJNTUfAu9DebrqauD19SBv+LuZl1y4oPTxkiKP23Y0MQZ54vgAFAGRprnRSLKVcSAC0JYgTKTk7k9cfofyT628QCfDEw+4I8GTmjikrCkzPvWJaHr6HtuODzCXhcAZyJQTpESv7fJa5TqdKXbnyfSAg6Pl15Z88osPBj6zGhHZseq0R0W6QADYqlWgr/rC1HkXX1SyeWZlQWUqrRUw4HmzaR0BtQIwDG6mEum45fHEClxQHE/YuxZefrsuLK28UMeD2SXmBBP3AwhSEWPSsApmlYUHQk0G9rt5QaEnerCz2Wskz2OMGwiQmWHnwQeRASjNmBD6YxdNO79MJGZ++kvf24B4ND34/gQ88+fvfGn69I8vmPLc3JkF56UdbROAyL8+CUMXjdq0ROOUslLzgstqwD9l+gWgwxJY/l7ycN+wjG8HrsGdjB18exckmj2Q7lS+QvMcSmuV+UeUT1EatNJgeEx5sDdcUPf711a88uyOmtpqkJhtW3G4mlBXDWxpHahbisWPOaOpBw5Gt5MG64OU5g1vmQ5KRjIRH/jMrI91qc76z3XviTagEKddCzJSBFwwoTSjvpY3/zh7tuezkQHcl48vFmWnQI6toLyiMD131pR/fmNq0TNYE3o1EABWUwP6MHTVdaABAG3i/903mLrMZbKLpSSZq6VKo5SgBEfqWX3733n7bG/XTCcpBbLTsO0dIaGBaCednoqSwkWFlrgglbA1MszLZ6M1QVGBIYM9A2LXnt7fvtMfenMIOPjgBG/oL25aPOuzxYXmC6bJXFITMADMU7EizgBdLvONJX/7sTlEVOZIyse+T6f6EMnrNjAUSW6rKPNVuE0xI+VIwjz8pQQEjDElkPj9699+6cZfNX4JEexsE0z6kJGorwcKVIFYuTXcvuhcf4fbYlcggibIz2hHACAYw2gyrebMKD7k95qVjiM1Hp7nnB4fRECttUNK759S5DpPKs0xuyEg3z4AoL0uwWu3Nu25/cF3vhJJYoQIGBwxF/gQTDX1IANVIP5zfdsjkZh9m8GRI4DMB0uOjAFjHBjjQ9NsVJoANFW0HghGCFAB5O90YIRzVzIMDrat+rxe02MZ3CCivOwVrBSR12Pis6+0RB5+/J2rWg/BwcWLiQMcXYs95gOqqQdVWw38zjXtgVDUWWcaTMAYgpcBLAMXZgGT0gE7GYdkPATJWCjbGRNBE5FlCWt/Z9CSSg0IwYDotLCuh7HjDEFr3e3xmJVSDU3V8w44KPCZ+s87OnHd1uZvP9vgbK89TmvZ462Fo+o60ASAP+5NfJsBzPP7jUVphxTmdIM2ZgDL3kMCAtIKpGODkhKIMoHLdLmhcEqZ9pdU6pLK2WrOgkXqwN4d/M0X1lmGywscAULRZEU4muqaWugpk9IhOE1mdojIbEc5DDFuGqzcdhSMX2Oh4xuHAp8hOzqDonZL880PPd9XF6iqEkvr6o8ZqMQJMkQUCAC7u+Zg/P9eMWupYeDLliVmSkkaTsHRImOA2W6kWkuQjgSlbAAiYEyA6fJScVklTSmbrkqnz1UV08/RUypmq+Ly6drl8xOAG0Al8ZWNv7MY5xmJJQIiqNjfGWwvKfQqAuB4WsQ4INPkmEw6fR6v6TENbiSkk9O9KKcMHAFYFpeRSEqs3tD40C8e67hraOP98f7PCVf91tSArq0GvrSuY//NS2dcC4DPmQY3pKYR7kElSMUjoJUEYbrB7SmgqRXlurh8ti6bPkeVz5ynCktn6uLSCm24CwjAAACVUXbbRpWIIvcIenXTA1Z3axP3+otBawVAoC2Tu1o7gtaiBdMGDM7KpCZCmOjHBhBxhqiU7vG6jUql80taM62YUSGReHTjztd++sCe7xEFGGLNCZtmf+RS86V1oAJVIGpqO1/5tytn3WAUsf9FBgpoeDJLRMCFgIv/8u/tWfMWSn9JGRUVT1NFU8uJWT7KqLYE0BJA2qhTsUwnmozGAAMEbrghHurFbS/VmZbHBzo7n9YAaDIGoWiyPBRLd5UUustkyjmlPZ/5I63SYQxjpikusu18k1bSbkvwus2N+39Z23AlMkwi1hzlVI81TipMDznaFes7HojFnBUmRz5cY4GIoJWCUH8v8/iKac5Ff+kUTz9PAxDIeBB1Mog6GUVtpxCIgOH7TpUhywBm+Oj1LY+6wgO9TAgThqAccrFEULmvMxglREUT3MW+71p1v89nuE2Dm/nkWoec6gt/3Bd/6OmdV+/thK4lx3CqxxonHa3q24Fqq4F/f13oD5+e77/I5xYXKEVyuPO74MF2tvP1Teaed14yTIND2Yx5mrv9RNrJwMbYMeYNBMxy0WBPK9/yyEo35+LDyWoCLTgz4km7e8GcMjcCeHXmRBScqNiZBsdkytkzpchdwTkrVIryItIpTVBQYKp3Grv5Q0/u+Ob6V8NbA1UgVm05ubMohiWRdc2Zu1Fehs8WWuaXPG4+TSrQw7kRwrDAtNwQCR5iu7a9YLQ0vG6YpgXl0+dpdPlIyzQSaThyrkykAU0fvLD+bndHy7vCtDzwwZeeAMAQDGPJtDN3Vkl/gdescBxFOEElFhFRa5Ja076iIs8CKTXPB+C0JvB6DNndExYPPv7Orf/v6e5f11ZX8xu3NJ/04Scj2my96sFU6uNnFb5sGLDYMplfa9Bw0jeEsvM7EwzTBeGBHtb05xeMlsbXDcuwoHzGOUfBRwDA3F7q3reDP1/7K48wrGM2wh6KaFJqt8dl7Kso9c/Kdo6akNJqmRzTtjrodotEUYE1y3GUHu8XiIjANLhKpdLid4/vWLP84X0/DASqxI2rtgzrtJ1hQ1dfn5HZHz8Z6rtkbsG7hmBXC8FQZzJjw7gpH4SvlzVve95oafyT4TJdUDZjnkbLR9pJITPcsPWRn3sPHtjDTMt9/O7r70tsz4KzSz2I6JmYEnuEtBa6K4RghUppGE/oMr4ZtSGQ//7JnW/98N7GJUQkL730G8NOxI8o0VvXnKnR3rk1vO/T5xb0u138K4AwwhLU0fCFBrpZ85+fN1qa3jAsw4TyORer1ubXxEtPrHJZHg+Q1ie8MYZgGImn5blnTe3zTVCJxUxffakV7Ssu9syXjhZ5EOW012Owp57b1XHn/267bCCOfbR8+Yhaho24ulDfDjpQBeL2zeG3Pj3f7/d6xOekBoUjdo0Z+IQwQZguCPd3s6a3njMOtLwj9u54xYiHBxjnxgnd+FBEU1K7PG5jf2Wpf5Y9wSR2SFpTaeeQz2vE/T7rrPGWVqU0FXgt/MPrren76965/I/v2Q3V1cBXNY/sLLFTKmnVtwNVVwMfWB963je/cGGBRyxQmiScUrqCAIYin+WCgZ42logOMsN0wclkDIiADJGV2DmlHoSJJrFHulZvueCsUI6jtCpFUFBgqYbdvfzBx9+9fvXLgxuG41RHnKc70R2qqwOqA1BtPal/jMZkoyFQEJ36aXpEGrTWYLo9IAwTTjZFRQDAOYPBcLI8Grc7LYMDEE2YBQDZWqtkjEWFwSrSjho34LQm8HgM2dsbFus2Ndz+260HHwwEqkRN/akt/shFAlUHAsAeebF7YDAGy1Ip2Sc4MqDcHONIWg+LmaFEsc4kiiMa8nc94LGitCk42I7s93gNl9scv4RwtqOCSqVssXpD42N3rm2/tba2mtfU1J/yubA5WTEy5Gh/9NjgwYXz/Q2mYFdxgUNHpuN4PDyDMyOeTHcfIbETQF9pqMC/Z0qhu1xwPm7SyhgqQzC+ekPD2zf+smEJEaUvvHApQA42ZuQsAgzVaH+xrv2ZaMz5MYPMkenjZe+zElsWjae7zIzE6nxHDhGZk5VWyxLZZUw4Di8tabdL8I0vvte9avX2KxExvDxzHTm5hzmVnaEa7cp17b8MR5xfmxwFwdiDd1hiNUxr7RwMQbaSlu/SaggGtq0GPB7DZRnc0uPwomRrqlD/RquzduO71759APYtWUK8BnJ36nXOH0RNPahAANirXW3/EorK51yC8fEAT2siy+TufQcGDE06aIh8n9YRcY4gteryecyKzDKmsZ0RKEVU4DPVrr2HWO3Wpu/Xvh5/6Xirf/MKOgCgmhqA+nqQh2Lx66Jx5z1TICeCMX1rhyQ2GEqUR2LpLtNkQHkssRnXqhUDFjUtozyzjGnspDXrVFVff1Ss3dTwn6s29d73UqBKLK3LfcAYrddfV1cD/58nDx6KJtSydFIFBUeEMQTvCImtbOsMhYmQ8lVih6TVcVS/x2O4TIGusZRWIgDT5NJO2+KRDTs3/sejrT+h2mp+aQ6c6lhCB3V1oKqrgf+irv3dUMz+hnQIGH+/UcdYSaxpcs++zgFBmoIibyU2I62OUt1er1mhx1hakYEyOIr1W5p3/ui/d/0jY6hxad2oPatRfQp1dZldZf9Zd2BDNO78hCNwHMP5HQGA4AwGBuPlkUSqy8pTiUVEZkutOLCIYfKKsZRWTaQ9LoNv/sOeQ79d3XAlIgZ/pokBjJ4qjfqrP5RKWbGu7a5IRP7WNMbO0R4tsYOhfJTYw9JqqwGPz7BcgltKj00FRSkin8eE17a1y3Wbdl73p3Z7d66d6rhAd6Sj3fVO6/cHI87LY+lotSYyDe7Z3xnkWtFg/klsRlqVVl1el1mpaWzaYihNUOAz1Z79fWz9pl03rX418txoONVxgw4ACGoA6prBDoblNfGE02KMkaMlABCCQf9gvDyaTHdaRn5JLCIyR2qFxCLmGCWEtSZwuww5EIyJNRsaf3Xvxs57A6PkVMcTOqjJOtr/3nCgOx7HZXZKRsbC0b4vsVTZ3jUYIsgfiT0qIew1LEswl1KjK61EAEJwpRwpHt2w89maR/b9iHJUU8076IaMRVUViJV1+94OR+W3lCLIHKs5uo5WayLLEN6WjgFBOp8klohzBkrpLq/HrNBj0JcAEZRlIH9sa1Pzv9/bfB1jqEbTqY47dACZpHGgCsRddR2PhWNOgDMUo+1ohxLFA6F4WTRp54/EZqUVCKKmKSpsZ3Tb8msi7fEYfOvLe4P3P7bjyjhi3+KT3DY4oaE7bCyqQKxc2/Yf4Yj9kGngqDboOSyxiirbOoN5IbGZZUwM7LQT9PhMc7SlVSkin9eiN95uV+ue2fX1+t1O461fIFFXN/YlyvG68VRTD4oA8JXOtn8OR9RrlmCCaPRugNZEhsG9+w4McNIwKPh4S2xWWjV1+dxm+Wi6Vq0JCrym2t/Wz2u3Nt38yIv9m2qzh0SPxy8fzztPywGwvh5SffH4NbGEbDcE8tEyFkQAhuAwMJgoiybSXZbJx1diMyuENRBETEtUjJZr1ZrAZQk5GImL1Zsaf/NfT3TfPZZONd+gO+xoVz3R2z6YkMtsW8UZQxyN/nKZbpYESulp7d3BQcgsYh+X308AYGZqrQMej2lagrlHQ1ozTpUprZVY/XTDH2793d4fEAXYWDrVvINuyNHWVgP/r9r2NyIReT1pwtFytCqTKPa2dAS5Ih0aP4klzTkDKVW312tU0Ki5VtIuk/PHn921565HG69DRIlYAzDObdnzInewtA5UIADi53XtayIx+3aD4ajUaLM5KhgYjJfFYhmJ1Xo8Nu0gcxylETBsmmJUNt9oIu31muyZV/eGf/9E47IDA9i9ZMnYO9W8hQ4AoKYm23J2bfvPwlG5ZjRazh6WWK0r23rCg9k3fkwXSh6WVqkGPB7DcBncpVRujz/P1lTpzzs69frNjd98ZmfinUDV+DjVvIYOAGhptuXs/oPx6yMR5y1T5H5xQFZiffsPDDBNFOJjLrEZaXWk6vZ6rJxLq9YEXq+h2juDfP3Ghn9/6IXgE4GqU982eLpCl3G0AcBHnz8YH4g6VyeSskvw3DpaIgDBOfQPxMviCXvsJZYyrhUJw5aL51Rah5xqLJYSazY1PHD3E10rqLaa19TXy3x6yHm3qrGmJuNo733qwL5IxLnKsVWKM8hZx/TDEku6sq1rcDD7tMdEYgkADIOB46igx2saluDuXEkrAQAXTBFpsWZD46s/vX/vDUSEuLQu79YP5uVS2sOLPx8/8Go4Kr9HBIyz3Mms0kSm4L59nUHUeixdLGnBGUilunweszyn0kqk3SbnTz63a/+9a3dci4jp7LZBmoRumI72rtr2B8NR+y6Rw+2MQy62Lxgri6ecTtPkoMei9URGWgkJw4bFK3MlrUpnWrE+/1pLfN2Gncuae7BjLBZjnnbQZaVWZh3tT8IR+zGXMfxexyeUWKkr27sGB7PxYFQldkhaZSYhbLhyJK3ZxZh6e2MXrtvU9O0ntyX/XFtNPF+c6oSDDiBzOiMBwGB/5FvhqHwnV45WZWqxBfsOBFFrColRP3kiI62O0t1ej1GuczCT1JrA6zZkZ3eIr9/ctPx3z/evG+8S12kBHWYd7b3PBCOhUOqqeFIdzIWjHarF9gVjpYdd7GhK7GFphZBpikrbVnAqjfOICCyLy0QiLVZvbHj0rtqOmuxiTJnvz3RCdDMacrS/2tD9XjjmXC1tZTMOdCqOdkhiHamntfeEg4A4qhKbkVY94PEawjJPUVoJgDGmGJBYs7HhjZ/c994/5atTnbDQDTnaQBWIu+s6/hCKqh8gAT9VR5tNFBe0dPSPqsQSkDY4y+xrdZsVp1oHISDtdnH+1Au7D9xfu+MaREzkq1Od0NABZBv0BEDcVdt2Xyhq/0rwU1v8eZTEJkdRYgmZ7WhCgpBlZhLCI5VWpYi8PhNefL019ejmpiu3deD+fHaqEx66rNQOHQt6UzjqbLAMNmJjgZiZjCulKzu6B4OHzybO8TANBo5UQZfbMExTeEYqrUoTFRSYamdTD6vd3Pzdp16P/imfaqqnLXTw/rGg1HXQ+UYkJhvNke+jRaWJDCH8LR1B1JrCnOd2tQcdmRD2mWUwQteadaqqpzcs1m1uWvHbZ3ofzkUr1knohuloH3iuMxhNOFcmU3JgpI42I7EMDgVjpYl0pkcxQQ5XFBMyWyoADSGXZVSkR+BaiQhMi8tU0hZrNjTUrljb9tOJ4lRPG+iGHG1tNfC76zqa41F5rbSVMxJHe6TEtveEg8gQSOfOxWZqrXrA4zGEKZh3JNKKiJojiHVbmrb9+H92fzvrVCfs6d0T+qTAoT4pK+van4nG1Y8YAWfDbzmblVjub2kfQK0hLHIksZqIRHYZk89rlY3EtRKR9rgNtvHF93oeXL/9GkSMLl+eu1ask9CdgqNdsa7t3sGo8xtDoMBhOloCAIMz6OuPTk0kMz2KcyGxCIiOVAAAIcMUlfYwXatSmrxeE155qzW9dkPzsj+2wp4lS4jX1Exc4E4L6IYcbSAA7LWuth9Eos5W0xjedkaETN9/qdS0A73hAZYjiTUMBratgm634C6DeeUwpDVzvKWlmvccZOs3NX+/9k+hVwJVVRPOqZ620AEALa8BeqUeZDCV/HokJt+zhudoUWkiIYR/b1ZiT9XFDkmrUrrL5zbLhtPmUGsCj9uQh/qiYs3GprtXbe65P+NUJ6ZxOF2hAwSgWwPA7q3r7QtHUlcm0zIkOPKTNRZDexcO9UenxpN296m62Iy0agCEQctlnHStlYjAMLhybEc8+nTDU3es3v+vtRPYqR5rcDiNxuFDVB6P9nxyXlGzZeBSJljmzOKPOBYUMy4RbUcaU/zettJi7yzbGfnBIRnXKoOmxYNT/O65afskTmPMnG+pLYPx1Rsbdn7vnp2XE0H6wgubh/4WJiNdvjraAIif17ZujMScmwWctKMdShQXtnT0kyaKjFRiD7tWR3V73SefENZA2us22KaX3utb/XTDMkQMLV8OE9qpnhHQZY2FrK0FvmJd+92hqP3AyTboyZ4XCwf7o6WJlNM1UolFAHSkBmQYdJ2ktCpF5PNZ9Nq2dmf1xl1Xv9Bk71p/GjjVMwY6AIClSzMH5W17U9wQjcoXTsbRDoUUqVTlgZ7wwEgTxYbgYNty0GUJbhncK/WJXavSmUND9rQc4ms2Nd5U+8fgCxNhMeYkdMcOXPBsS0t6MCr/IRaV+0+iRotaZSW2fWQSS0QkBAOlqMvntcpOxqm6LEP3B2NizcaGe1dt7Pn1S4EqcToZhzMJOqipAb2kGvgvn+zoGYzbV6ZtJ8IZshM5Wp2txR4ciE5NJbMSO7zlTuhIBQQ0aFmHVwgf16kKgyutJF+zoWFLze/3/8toHhoyCd0YjaHFn798/MC2SJS+SVIT46CPBx5iRmIdSdPaeyKZRPEwkDMEB8fRg26XYJbgvqy0Hi9aaksgr93cuOuWe5u+TkR6+Ri3Yp2EbrQiXrbl7M9rWx8PR9XPDMQTOVrUmsgQrLDlQB8pTdGTlVidldZMywiz7ESzwexpg7i1fu/A2md2XxlH7F++HLEGTj/jcEZCNwRebTXwFetb7xyMOI+cyNFqnU0U90VLUmmZWe50Eq0nEACczDKmw671WKZVaU0Ffku/sb1DP7ph1z9sfTvecLo61TMaOgCApXUZR3tod+q70Zh8xTTwmI72sMQqmtbRm3WxJyet6Dh60O1+X1rxA9KqNEGBx1T7Wvv4+i1N/7r2lf4tp7NTPeOhG5or/fbtnkRvKHVtLK46jtNyFrUmEpwV7WvvI63hIyX2SGn1+czSY0mrJgK3S8jBcEKsebrxvl8+2fVfdJqVuCahO46jra4G/punuw+Eo85Vjq1inOOHGvQMSWxvX7QkNZQoPoHrRQCQSgNqCFqWMbSM6WinypnSSos1Gxufv/Xhlh9QbTWfKNsGJ6HLkaO95/GO1+Nxeb1WmjF2tKM9UmI7D4b7kSGcKHNiCIZpW4Ust2Cm4AVSfsi1apfJ+OPPNO29+/6G6xiifSY41UnojuFo71jXvjYUVbcZjH3Q0aLSBIKzor3tA1privLjJNwy0sozm2+8ZukH/9VQg5tnX2kJrdnUtKw1gQcXT7Btg5PQ5Q48VVsNfOW61sBgxF5vGiiA3ne0pDMHjPT2haem0k63aR5bYhEApNSAlHWtjgJk+L5T9Vn6rR2dsHZT0zc2vZ3YXrtkCa87g4zDJHQfMBbVWUcb7HR/OxKTfzqyRpuRWARb0rTOg5E+fhyJFYKhI1XI5TLQNDLSihkzAl63qdsODPD1m5p++vAfBp7KONU6dSbf9DMdusPbq1fVN8cGQ+rqWEL2HOFoUSkCIVjR3rZ+UopiH5RYTUSZKoTq9nnNUszSqonANIWKxpJ8zdMND97zxIGVZ6JTnYTuIxztr55ubwvF01c5tk4wnmk5S0BkCQa9/dHipC0/JLFDrpUABiyLT3McBQiEgjPFQPO1Gxvrb/nd3u8RBdiZ6FSPNfjkLciM5magQBWIlVsirZ+c7+9yW/xr2YCFjDFM28ooLfa0lU7xzjrySCUhGCqpQ6Yh+or8rnmZFcJAHpfgtVua2u+8b/uXQykcJHoZ6+vPPKc6GelO0tGuXNf28GDYWWlwxhFBKU3ABZvS0j6glYYYy0rsYWmVqtvrNUuRIWgi8npNePH1fZE1W3Yt2xvErsVnUIlrErpTcrRtPw1F7CcsA4UmcizBoPtQtCRty2x3J6DD0ko04HKJylRKgr/A0u80dLHVmxu/s/Gt6BuBqi+IM9mpTkI3PEeLHQf0t2IxZ5slmKE0aNuR0zp7w/1DLlYIho4tw5bLRMHQb5pcdnaFxLrNTcsffLa/9nTaNjgJ3Rg52ofr20ORsFwWT8iDjCHjjE1p6ehXSlGcIaDBOUilu7xuMdUwuU7E02LNhqNasU5GuEnohudoa6uB/+KpA/siCedax1Ept0tQ96FocdqRXZbBwVEKtIKg12OVK6XZ+s2Nr998/3vfJQowyDjVSeMw6V6HN+qyjnbFlnDLp871H/K6+f9J2ZKVTvG1V5QWzIonnZBl8Z7iMu+CxzY2dt774Nt/1xvDfqKX8dJJpzoJ3UhHfTvoQBWI2zeHti2aV+j3e8VfpWy1d95ZU2dGYukDlRV+/5/f6fCsWr3971/eYzcuqQa+atWkU50cOZjm1VYDBwC+/Otznl35nXNaOzdV7+nduuzN1x/42/T3Liv/RwCAQFWVmLxVk3O6nDnapvOBiEAPJNi10ajd09IR7GnpGCj4w6st96zacvChSac6OUZlVGeiHXz3yzMuvP2b87b97No5vwUAMxsFcfIOTY5RGYGsOvzw8orzbq6eU/h+lmVyTI7RBC9w1LRkErjJMabgTQI3OSbHRBj/H0mpj2GwY78SAAAAAElFTkSuQmCC";
export function DiamondIcon({ size = "1em", style }) {
  return (
    <img src={DIAMOND_IMG} alt="" style={{ width: size, height: size, objectFit: "contain", display: "inline-block", verticalAlign: "middle", ...style }} />
  );
}

const CROWN_IMG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAACMCAYAAABCtSQoAACThElEQVR42uz9ebwl11nei3/ftapqj2fqPmq1WmpZkiV5kAc8G2PABsfBThhtQcJkJsO9wE3u5ZeQhCSghNwMNyEEcjNcuAlcAgnggCFhMJjY8iBb1mRNraHneTzz2WNVrfX+/lhVe9fe5/SkwZKJSp/96dbpc/apvWq96x2e531e4aXry/5S7b4dNIXWGSALr97X4Ptf7YbmYdtYuId1NplbvyWDr4f4z2KaTwNDYAaGiyL1/S+t5JffFb20BF/+VwYZuFoMG0AK+Vfhl/76YHPp6yJbWyMd/g3mdv8a2EGM+QQ0zxY/mgM9qK28tIovGfBL1wt0xTTP9+kTAzD4KvyZnyY7926XndN6XFsY9tZ+vmbj3diZP4TkUThhYK/A5k6Y2QRWX1rFL8/LvLQEfy6utQaNZWAR1r+PfPXd/Y2TWou65MOzXvXE7LB35KchvSaEzO0EBrugtqc4xF86yF8y4JeuF+5aliLvfUO2efab0vXzWjNCpCoWbxI7dJalWvfc4buA2c3NKAapQ14DIpapvbSGLxnwS9cLdg1zYFdv5dD/GsvmgmWgRlXwFiGBXK2mG75Z635Vd+nJfzYzU381mZsHzgDKTjovreFLOfBL1wtzCexpDzeO/m2fnv0LjhVnbWbxEahFFVBLZNQ4f8YL3Q+m/TpJ4+a7CEWvHJgF1l5aypc88HN+qapVVXuRfzOqKn/eH1LxOY2qRqoaq6oJX38gVlXjsqVv63eO/3gUrSGyadQMAQeiKIKIBecQ3RBrV3xv4+RfzoertxbGGwNJ8b5xsd4y/h3h9/5PsMZSfPYvqz0lL/6F3bw2/K19HqhXDh4FWkAmImt/njcW0AivdDf47mBQj1TJGkPWmefNayf+5P9tJisvSxKr3g3FGAsqgIQ/VBDxqA4RG/tBWjMDv+v0/O63/fjGBo9bW9tstchhMAP1lWD9JECv2CMLwFkR8X+O17lZfGYf6gm44uUBKyL5Sx74GV3ZADpljhYXi5wXG+t/phzeg++DG9briHPpHPPMrp579KdaSfayxDiP92IkAezobBYtNigET+xzU4/Vx6a7Z335wA/OztYaxftvwHCdQO5Iiz998aPD4s8/z9cA6BR/5oAXEVf8m3sphH6mIYLsWIfd/cILlZCHAfpFDjf4c53gimjxGdegfprVVg84024nq/21w39b+6ffbWzuMZFRBVWPen/pYMvnphbju6sn3jvYOPIzrdZwFu7KYW6z4nWKOJwUWC/u4897PcgWn9kUa4CI6Iv5s3855MBxETr7ysKaYrGzYoP9eb/i4gCTo+tHh8EaV7+5t3rwwzONnloZSmmjqrqt7WrVgMUR6UDm2xr31w59G2x+s8g/8EWovAAsDtl4ObCz+N3/MxQ7m8Bc8ZkBzMVqLy8Z8NXf43yf/rU5g9cOBoMFEdMtXEodmPmfYHPtHA6HNw2H7N21a9cipO9bPv74T9ajjSiOhyiZlD7WGIPIZGlDtPS/JgTC6vGuK81G7upmlZXjj363qr5pZWWlNhjQBGYdOgedXcVBGf9PUCzsDQaDdr/frwOLJ06ciEsv/JIBP7vLAnkDfZ3xna+L6N6q6mvFfo2Kk/PP9bUOg1qttpSvdzeazeY16xee+HAsS3tbTe+9S0UuU4ucMD0RwCPWo9mGrTXVq7vwuu76E/98x44di8Ph+gawHmH7YOrFOv+5Nd7yYOr3+7utZnsjTa8FFvfu3bsI1Mqq/4vVG7/oDXjfvn050O5snPomYwZfF9UbjfX1480ipPxznZeVmyuiW4MOrV2toU9Pf/dg8/jXJUnPKUMj1MBfem+JKlIJrTWKwICXHGFoWjOZSzsH3k165jvieK7Z7XZNQnsVomGxR9yf31Uuzqasf33ciG6Im813b6yc+vrCcewgFE1ftKG0ebFvYGPmZ4CX3XvPJ9/3e7/5H95Buvy+ubkbF+6+++iAEydS2MxL7K7EjKs45pex8Y42TYusT9/WgDeePbn/zlYjN0nixKkHjcDEV3CWhThaRUAVFYqXUk+8iK7o+RNP3dlsstjKsj6cXQXfKzbv8Mvx8Cv2QjT19RJPtyEaCevWmJ17Jenyt//WL/3Ln/nCPZ/6AeCG1dXVuPj8UWHIL8rK24v3bBTRz372sylc/6RfX3nsgd//19cPj9zzI3/xg3/tXe9611f/UZo2fjXrJlHUYkcNzhcHUpNQoe6rqgfSChzwYt1sUSUl8MVm2QGsqmpvc3MzmplpzJ0/e99PxOb83mbNeVFvImMgSiuZ2mWMWAUp82AUi8U7h8uMadcjv+4O3bJ0xvyzxeu+9oc6nbPDdrvu0zS9OUn6x2Bu9cvEcGtFbaQsvomqpsWesMW/NSFdGPSXr8+Hq6hqfWX/7//kvX/wi6/c//AB3vEtP/EUsJIk2Tx0BtAuIcv+SwZ8ldfL210PsHOuNbfYGnLk8Y+7/7qx9or3fvePveLGO77+dSQ3/M3e2tqwNj8fFwvcreRttniQL/YQ0FXCNE/AITvF55GZmRnf6515Z2/j5Pv27FQnpFZUQATFgxiuHOgoC9YSKtYqGCx4Z1oN/PnlU+9l59p7jx3b/Z+uvXap315sC8wZEVFVlS8DOCkvXlqJHARYhGENaqtDhg02hr3abGsBd+7Hn7znv93+6Y/+3wsbpx7Idi3ujubaCcCaarwI7Qio8SJFO8yL+CQVgNY1r2kAe2YXmk0xjnbDyoVTj/vf/KW/7x79xH/8ell54q/Pz8/z1FNLfVhiALuBdlj09GYY3vJlUEEtK54lpp0SenSlYAC9/cKJR//ebN2RGDV4BTWV6O5ZfDwR0AGCkphZaSZOTxy/5x/fcQfvTtNFV6d+rjSEF7PxqmpdVa2IOBHpisgG0BGRzfD3voDmnU7HPHSidqw2O+uz1YN/5f4//KW3/OlH/uHC2srTvjljjQdptWYTwDi32aWHFgv9ovzsL3oPnNZq9fBHox9FMb7fZ7aWm83Nk3zmD/4fp5t86PpXft3rXvnKt/48JJ/1WbarF8fewIU6bg3ky6FVrl68+pXnkj34S780VNX2+pkv/J352sb1raZz6oc2mKsN+a/y7AIMBbUK3qG5kfmZyGn/9K61pc/9zJ497/iWbveCldY1Amy+yA/7hAB3dSrRjBRRQ9alkVoGrXa7nX5lu/ONm0cf+4dPP/SHr7jnz35FB5untdWITO6da8WWmXYrB3pJ0hYaeF7EVfgXrQcuT/tWy8ZANzaN83GtDYqKy2lZJVs9Y++/+zfckcc/+oZTT/23fwun/2kcE/uUfvhsjXWon/oyMOBh2HSDXdBtAcna2mDxTT/8wwtZtvy/rS8dfFuzNvCRSS0+AxXUC4F59ewdg6CAx3iIyE0z7urK2affjOu8dzBoGen3o2pU9GLcLtWct/iaLeohqnqh3Tp/frNO3fv87E+cP3D3rz/x4G+84nN3/weXbp6WhbqI8R5ViCJLUosHwKDh0kAh7b14DTh6MZ+qIqLOxX0gim29a+M2uQIaoT6jHlkGG8fsI/f9pleW24kZfPvOl711V7t2yz+A6KHCNZkvg7xNYbUHrZ3gesBqknsLg28/f/zBH59pZnEci/q0j7GBSapqisKyKyAieRa/3GJEwGTgU2nVajpbH8QnDn/+Z/fe9he+X0TufpGH0KUBDyrVPFPUEXakaf3aZFd7Ie0ce9/SsS/8reNP/4m5/9Mf9YP1VTtbF3wK3lrAaxTViG2toJG2y3fTl0LoZ+qB+ye6tF5p6jPtukQxmRgwEWIyHJ4kFoZrp81TD31cE2s0Vv+u2evT60z7tp+E2qeLh/hiv2JYSKFXYxjN7Du4b/mOO+7Ys3Huix+IhyeuW1hMvLqhQQSnBiNxMDocQgZi4BnyDARFifBGMToAb9BBLHMtfH/j+E3rK4/+/1T1iIgcexEXsXQqj5DCmBfyfP0rkiS+Pe8/9r0bxx9+67lDX+ChT/+BDtZWzUxNcLmiUYxKhM8y6rUGzXozGHDbhMaZ1qjt8qUQ+mqvZbEC7K63kp1ePF4QZyAXyK2iKM3IMlg5K08/8Blz9sD9rnf28Vek60//AvS+A3rXqv5M2dsqZRgYcOIXPjKq5G8KUUZNanfccUcL8hs2Th/56tmW88jQqBi8WDAxLrQWoVLuW/8sd7/FY1CTBq+uDWKj0m52/YXT+94F+VvKQ7WCucuLYe2K+5CphXBwIIF0TxTZV69tHv/rnfMPvPXCiT/z9939UR0sr8iMTSA3iDHkJscbxXuI4oS43gwhTb+grQU7qb/kgZ/B1WwuLgBDtLkvaS58jffeJ+RGVcArThTnHLU4YmPlMI/e/we23rT+2sjf5KLhz9nWy3bAXb+oGz/cIPS3+mC86StU/WEKadUX0LMY+rRpdG/MkZtSeKBJUj/7xKd+qlk/Z5MZ8XnmEY2xxoAoXjJCe4JHiZFnEz6LIJojONQH0pWaFDIvC40Zz2C1ff7pP/gRVf2jzeXllxFkeFyxjlmxfjUR6T/Ph9zOwlBXmYAI+zvAzkCyRFAV2QHLKdy2Ay58KFt7+gfs+vEdS4c+7+79+O/b/to69VpE7t04WVaIyMk8ZMkOqM92AWikXWgMYXkemi9RKZ9hKC3AmrHN1aTWRBUsSuQDSd97xSHkPqdRg421E9x3zx+ZjfNPe9s90co7R34CVj/EzB7LiRMK3VfD8GUwPEmAa8wLXmVsYKF1XokveJrZYOnot+jwzOt37Ih8lqWiSMhzFfA54BDJi7u2BaT0bC4HGhxNYGdlEEVkg9zM1FW766e+pre59KGZnTsVSHu93kyxdiOI5Xn2yGWUYiuOp/jQjSEkmxUv2e12d7acW/0u1zn+A3F6dkfn1KP+nj/7Q9tZWaeeGJzmePGo9RSaJRjnQZDcNDBRcx3Q9VFo3hCQl0LoZ3LV6zUP5KZRHxpr2d7Ywpe8euqxsLl6mk/+6e+YtXNP+8ifXEw7T/4CLH2IvXtfBe514OZEZi+cOAEEkP6FNGAPLK+u0htsxvvb8Kbz5x/8l832IMGLWBeLmTDQ5/lWVRExiIA1iJGI+TmbLJ2896fBvW11lbjZbGabofVurqj0Nr4EOe5KeC2XbX+twvtfKDzvIBh5enurde6n8s2n/qZ1Z3esnj3gP/mx3zPrK0vEieBcqDYLk2WpogxoFIUkXgbc3JdB8eTFzxfu+gyApL6ZO4fI5D3riHQVAknRnGbi6K0e5rN/8mume2afmuFxy+Cpf4Y//rdh9vPgDqn2X753L5aAb76QbWMWkIWFTm1mhuG543f/eKN1ut6a6+U+z8X4CNGpjqLn00xE8OrxPsf5HFCZaTnX1KO7u+ce+tDCAgaIa3AjpDcALfq0n8+TpUhvCrZaYwY2dxQHR1FtXi/52nP58OxP+t7hH6+Zk3Prpx/ST/z3XzGb549Qj6AMEkTAmG0/uogYsEkPMKy/ZMDP+uq1Csa5tVqv10FR1VC8KnFQrx6viisiQZ8OaMYp6+f3c8/HflvSjRPK4Ii6tRN/md7ma2FmBvI3DYfDG6jqz7xAWcJgsL4L2jkZX9FZOfrOerym3ndtOJBkC4AhYaeV+SHPBRI8cSSKot5hxKPkGAamFq3rhVNPvB3S954713HBYJJ1xgoWz/caFhhv08HMIE2780Ve7GCuB8z4/Mz/oYMT36mDo76/9KR+4r/9R1k+dYB2TVGf4zUUqgCmRUuKHg/iOAKSL5v2yRe9ATeBE+BBXBTH22xWDZtYwwNQD0bAeEczhpUzT/HgJ37X5Os9JF2vM3j8N8iO/1NoH19fXz9ZhGIvJDSSdzrrPWDXqaf/7P/cWe/PNqxV9aHaLnIlRvdcpZlSCaMVJOi6+TyTZgKRrDQuHP/8v7r22vY7zp04cRg4DazTeH4laYv82hSvTeB8krTWYZBA+irgdrLjPye9Y3+d9Iz67im5548/IitnjtKqC86FIM7IpMFut5o24Oz6kY+8ZMDP1ePze0EgHlpjUZ3eueELY6RdRvIx6pV64jl98EEe/9THxPizeH0qITt4px8e/e5du3ZdC2vPa/h3+esuWVy8cSXtH/xhcfu/ul3rOrLEKE2cKP6FEoKUsKKKR2wMEsnsTOaHm0/s9unh79m7d289zFgigsHi87yGFgbXFPWKfpHvHg9pau9O3KFfpnf4O/PeEbVumfv+5KNy8uCTtGITTvUI/BWADEpgYoHU7ryThLm5L09FjhcLzlfsJLO5SQtIrC2Eyi/iPxSDF4MPdWoUg/ERLQtHDnycfff/jhjp66B/zLv8wI+57MgvwHz9Ix/5iFzi5H+eP94/UKB+/NCDf2mufV4jMxTJ26hv4Q144wq890u55H58HIqiWIaZoV7LqNklPXXoobcAuztnF2aAhSH+Djj6nEOSlfVXMDOFAbfCa18ESYts+YMMz7w16x7xsazII5/6Qzm2/wnacYzmiqrgRS5vucX5Y6MIoLa+TmN1dRVOINXvetEZsOrqt3Q6nevW1vQWVW2orsxB742wuVNVZwtRuRcyiO53u/SgtiQyR+IQEa+pDZ5WtNAAVVPKPYWGdR/Caucd3uQkyZCDX7yHY/d+VuqSie+d8pIf+kt59uRP3Xnnnc2NjVOLqoPbOh3dXXzuUgvq2mcrpxIay7s3qHauU9VYu3r9MD//Q6oX3oVqsnninn/QzM7dHpuGOjUGM8RqD+szxAc1jeLTFfpWAQMO0YcWXOarvqeJfLrUzRJAvITc2xfr6XOSCDRX02x6zYcHr+tcePQH2rvb/SzrXW8Y3Ao3PVtjLcXla6o6o6o7gGtUdXcw2ORECJlLDbQ7ZuHIPyJ96o7hxmEXJ5k5dP/dPPXFz1G3OYYcK4UaSa4jIfHxL5TRsY94vKqKBWPqQ4gfGUbnk4Varc1eHDTXCV1Zz2eaYIL9jcT166raLNYjKtZnr6ruKNYnUtWGAem3Wiaam2MTejtgwYC0IW6PP+ELeuXLy/sysOtGmhoVzei5hLRIFLwKHmH0mDSQ84PyRCB7iAqJeJ544FNc2PdFqaGSbp72ee/Ed/nuyX86M7PnFhgsG0NMGDUyR8Aenws1CgGTQDQLsOkYWhv1yWUB2NM5+8QHFpu5WmnhsHi6GAZY74s+X90mX9OJxOHZZb7TVJBK4UxBxGFMjpAQiWGuPbDLpx/7HuB164O1NXVyjnCOPtto0EwVxPLi/9vBiOubbG5mgMmzIz9PeuZdafesr9W8PffUgzz8hU8TSQo6RMuWYN0OY9gq86UoGDA2yYAjTd30mJHUyZAvTTN/KSafQG8xNLfQYNwjfoGAv5eCjhiW5j5HGE2Zr65K9OCDD3agcR/Uu8Vp94LnyYPBQAFjrajI1e8LqxbNc2qxw5geD937cdbPHpQkNsLwgprGsR8lO/IjMJc3GmubOatvhNW/AoNrn7sHVz8BtbNl1bu3Gf0p0c5D547f+2/Fdq9X69Rr31jrn6ci1TO/vFFSkyFYtG9MHXGRP3/t2skv/uTizJ48tfGf8dxAcSVctCkiKwQe+yowyNl8M3QimZ27kA4O3hXZU989XD3lknjWrBw9yAOf+VNwPWoJGPEBDhPwBnJbMM4udZAVGyuucg3qo4TtSyXsVxxWvZ1gIqinjKmccPas5SxKkFM24QcWaawunfr6jbWDv7mwIO990+1vmjt9+rQQwHHPC0zifuqpp9jc3FTAGmOv3oAVxAnWCD7vkdge+fAcj9zzMbKVk1KPBtJfeczl/dPfy2D5e2F+MUJ2OtRB/Vk3QhRyOTPFCToEdszMkMxEMw3S9Tuy/lPfkNRXPTI0TvsoDhFBXyQplxBw4Ywc5yHyMXGe24Zd0s3VR74B0je2aV+Aj8izWKPSo5TC6lUtqxTouNwJtJt5euJv4k79+HD1aVczzgzOHeeLn/0j0u45GonH5x1UPLkq3oATQa8QKRSBKI4lpJbNL/UDKCO/NjS7UN8oKu49wOzbty9ibvciu7m+t3Hu729unvl7kN5iVg8zbLV5t5Gl9x55+pN/jxnes2fPnmZvefnafnjTF3QmzCtfOeve/e53OyBOksSohoUe5W5FPle+vFZhJY+IBPxPffG9Kc0kY3P1GE9+/uP4waokeOMHp6xLj/4LPzj9v0DrUUvye8UtNJ6lpla5OUvGV6PXW4YGyYWjj397rCeo1zL1GsbxOOdQ1XFQKyXmvfWFXgpmurpTbuK9pw6PAOJIWE8vGOdo1vs+kRPJueP3fD/Quuuub9fKELarPfTLiRtxsdZSCaVn4Gxci+bv8fmRv2fj/f+XpEck9rFx/a488tn/zsbSflo1j9EhRhRXiPa50d4A58f74mJnoyrYKDLBmPRLbcAZYdLIBYIsVAzs2IT5o0ePmjvuuOM6Gtm3HXjkk7/S753/O0niboD01aaxp/OWpG5mrR+q65658ZG7/9O/ZND7QHPnzsHm+fWYQtXghatKR+bOO3/bABLH8aXrseUDqjyQKunDl/VMPHVJOXfiUQ4/+CmsMxL5NXSwv0Z25icYbLwD2iVJofscfXYXHtL6ylpz5yqpe2O6efz9sa570dzoqKe3unfHCdz4c116Ez6r4BXdZtsqxkdIbhFJUclRsQi5MSxp78LBd0P6gbvu0pJOufAM7q7s560K/IWGhX5/FnbPuY3Vb9Dh8e8frt/vTL6K8UYOPvBpls4+Srs2RHyKOjcqKIfzrSjvaWD4eL2Cm4hiXuC00Zw9Swz0hkOa2cpK46abbnoDbvUv7/vMf/7ZmebgHY2mOVerRR1wC8Za03E0nrY0T916w27dMdO57u4/+vmf628euGvXrrnb933kIx7uekETsjvvDAUNY+1VexzF443iBBwmVKsdxNZRj3ucOPAA5w7tw8ROjN/wOjyGd8f+Cf7s3ym8ZuM5MA2F9TZgkfm1PXDbyrnP/xP8kaRlY8FZCbvOFK9qg4LnhWR6KiAakeQJRoY4OyQVS+qM1Ovq25yrrR2458eA1tG7707g7vVnmC8aJhsWcli/joa7Bdb+qvcH/oUOTonNamJNQ0498TkOPv1panE/GCghzy3r8l4EUYNRg1GuSPRPBKw1xWEr8gIstQfc7t04IB92V+Z37Jh5n988/rOf/f1fuWvHnG/uvn6Hj0WG0Pz8cCifMoOBO2iZ/0hiFvaDkb03JvnNN/Rbj33+t39s/fyjP3nHnXfOivwD/8K12+0afUBrTJA1vsqz3RslADExaB3U4l1KbIegqzzx8CfZPHsKE0WG/AJZ+lgLc/yn4cKHRGTj2Xz2QpSuC3O7gPlw+6tf47IDt8TJkjO5FfG1Yv9GoHHFAbwIClmiGG9I8hghxdmU3EaobWDUm7pZ9cOVI68Drr/pXe9qwLueyYFXjvS0wQ4lDYsRzYG8pdc7+5M2fnQXWddH7jazdnSZJx//GGLOoi7FFEQtHUUvUch7NcBjVq9wJQVMZP04bfySGnFUOIsYyDudzszsjuR9m+cf+1sP3v1fvv622xcWr7vpOtXh0Ni49TDM3lOrzR4yMzMzCbBObeE/p2K13920L7vhJr9nvu4fvefXv3b5+Md/T3X5H6fp+tvOnNGW6oUZVW0FXGr4WtXe3gKXWlTVa1S1XWBYzzoMKUJX95a3vCUGBmptjhiMB+uDdy3b8r33eB+yN6fjl/eBl6AaupUcOb4AnTT3JJJB/yiH7rsb1xlibUNs1nfp2mH1/eM/qrr8/rU13aGqO1X1Zap6s6rOFWnFQoHNxZf5DMWM302vqs3Vww99O52ndH5mSOp9GECrilGPFK19Iez3+OLvo371kiFVyfW3257qdXTSqS/C85JXXXBO1XvU58Ui6diW1Icph+qLFMThTI5qjKhgNQ3td5lIHGVq7cnk1MFP/SzQXl8/HmX031Lsix3nVNtDHb5G9Uyrsh7bGbAC+QD2DlRfISJDkL1+cOD/iIeP78r6PR/Fick3jnHgkT/B90/TsEFOKPOGTEPByqui3iO+rIlQPO3KyS9akFV8NVFARYhsLEC9Kz2B+nDKOz5bnLdWrkEpOl/8WQOiQUg/bJb139ZuD//R6qn7f+TBT/3XW67fO6PX7pn3eb9nHDVv4tangbNAqzj2GVCffWRoImdqc+L6Nbnh2uvNrXtbeurJu79qeO6xvxPb3k/u3s3M+npcqNWfL8Kdhi/eo/yQz3V7XtZut2NgqCbKRSKML36BjHmVo3y37BHW4HW9r7rsHKR44VEVjCpt26e7eoRjD38GvMP4xJrMqcnOX+8HJ355bo6XhwphH+h0i89aVAxHGsSXumq9Xm+px0wN1/1gunb07U3dVMkyK7HFCAQk22EI/b5F5o4vl1W0Ek6Xhqvbllq880gthtjgBaRRw+e6tWKjDlUXtKWp4s3h8CgSSbw4nHV4YkQtRlOsOsRHOM2t+rNeekffB+vvM3M3WsG1wLSB2i6oC24H7LaXST8hiAO1atBR1Rt95+TfMPmp62x+wsXMGnUDDj7531lbeoSW8UTOBH3rImTWsuCHQ0aHT1HM2rIlddtbMDY2QKNNq6xblJHUs41ATSU9KAUJLIxJ1+mQeDDgmjje/Jsbpx/+8P4HP77rtXe8TPe8bI9kaSrENbxEQ2zrTAm5GdjohhuN01q9vSLSQAUdDnvsWFiUnfMz7tEvfNyvH3/s28hP/dzc3Nyr6PXasKsPyQFKQnvo11wVkWUR6YuILwdDPbvPvc8cO3bMARhjRcwz4R2VBSGp9OUVjtGDzzzWrnHixGc5d/izmJrD+Mxkg1Wv6ck9Pj3wc5DfCo0LRXErAhZhvVtUDf0lQmg9f/58v9ncWG1C/fyxe/8meiYyNiIfRojLEPLnpCalqvjcY1o1zl1Y45d/6jf51z/2Kxw6cAoz08C7EKU8F+BS9Rxo1Iwm6UmzfOiRvzoDqRvqiQGaAcvARkzj4aKyejFDKNcvSnq9FVh/B+7pPzR65J1p97wX27TGppx++kFOHH6KemQKNRJ9Dn2FIiIYYxVIvXcOuuY5LhcmhT1U3vPOqHACyWwt21lPzv/dtSOPf/O++z6jL3/5TX7nznlxWR+M1ShuEdVbh0GWWQvjdQ3MlifDUpTMPyF2Fo8ixpG5jJ2zdXvDrpYc2X+Prpx66Dtxh/8xTfuGwgPlFe9rqMxULW608WwqeuFh3xFdx3UA3lq7ZXTm1W06KWx5skHeimDpEZtzHHj8k3TPHcNEFjFDMxyc9Mac/mqykz+8GvKTG4ewK6U7C3NRr8duLjH86rd/+7ftrl27GrB7SHbu69Le/tcoJ5zxmJqZQ1yQs5FnuRGd84gRTCvh7j94gH/7wX/N/H95gq950vA7P/jr/O7/+ycQGUwS4fLnZlCFFI9ddGhqesJJ9/Q7IH9jXptZU/S6IcObx6HPJUPQJIVrAU+zeS3p2X8Kx14zyA87Y1MDdfpnDnN83z3UtIvVAVpI4ijPVa902B+hGwm3vr6mgXb9nF2NCpxoi/09BHIOEAGvIj/1r5YPP/iDR56+X2+/dQ8L8y2T5QOcy1FVcb6Oqc/dB3Kc+SDWaBhLowxNfM0fOWZUjTFqwnq7fMBsG9kx4+XcsQd878ITX5P3j/w0cAfL1CoYXjnhPCryHC1u+tmS3NXtcgrE1lqzrQ6yljluAbdMGHkVmglPu8pOVG9BE4wKiWT4/gUOPXI/vt9FNCeWofjVA47BuW9bSNffB5wx9K+B2LGJb0bMXeoz3nnnnabXW64BNyyffvqvmOwIrVofVSXLQuis6nDeF3m83xbz3f4VvG6eOWy7zspmn3/3d/4z9/7ob/Gec8JN87PsWVzgh3e9it7//TA//7/9CseOn8POtcCP8d4r/33b3wOaSyPe1Cg7mSwfeOivtqBLliu42zfDQd/k0hP+4pys3YcG2dJf0MHyLenqcWe0Z8WAG3j2P/gpXO8sNfpIPhzJKV2sH3r6PsvII3AItvfA1hhMyGEGz1dJsPjTAr7f799KuvZabuPrff/Q30rPPPa288ce8nuurcvcbCQuD7dhjVVjY8m0dg5mHoJaKbKvpmB6RL1erw7zH8XMftEmNdQ4rxiIDF5TFmZj6rZvTh1+0KWrh9463HjsF9i58rdg43UwvK0w1qxyg6PT9VkWsfKNjQ0HJMYYuQwMPBY6rz7VMg8uPG/4PimKXgbvE1QFyaFhPOtnD3HyyQewcUSkVsj6Ju8dN1n/0M/DynfHaC8hOcUMOQlrlc+97W11OjvXoPuudO3AV0fDCyp5avOieCVFvrmFSFEdBzrOTCe+J8+DF4rqEZ/7ky/yix/81zR/9RH+4uwiNokYpDmDNCM18IHbX807nzT8xvf+Kn/8G59EYou1Fu98ZcNv/X1bc+MxCK0F51xVyfKhTQdHdbC+/9uBt4uLTxJYGBGXHR1xwhnicw3yV+Wrx/+ads+rqIjRBCvKqUc/R2/5GDU7RDTFSKi7qa8mSArb8MZ1al9cLIBT1TAcPbxrPjc3L0XU/5yjcoDrdruLUTR4PUn2w1n38X81XN7/LScPP+R3zBlZmE/I0m5RaBNUxUdJC4nb+6D2MGz0CXrnacE6Yc5aNysiB6Oo+cmo2VavuUcsuY3wUUyWpcw3a9i0Y5dPPe5t7+Ab6R3829D9Tsiug86NRXjwnNEMQgh9wLRaLVOGYHIFx5svOpHUa/BqhRJDqFAWXy/u0uPJrUc1wngh0pRELnDy0D1snj6EmAbG1MTYjs+6T+werO3/pxDdsrS0VA676hZQ0UWr6Lt2YTfPPfK9dnAwmo3VR74OGLxNcXL1vAFF8bmj1kxYHwz55f/zd/nkh/8z7zqe87pdi3Scw3tFTMFUy3JWhwNetWc3H77m1Zz/5/fz83/jP3Hy/CpxkRvrM8qNi0DLxDhJJEk2fD0/Mr954oEfqtfrK+AO9unHgL+bu7ddH1WVo0ed1uHWbPWRXzTZ4euM7SoaG2vabJ44yIUDnyAxHVRTVNOisFfdDKHy7NVT1t4uWqu6VIkEkKC1Y7vdnnmODbhL4HUrMNdqZa+Kov63pxuHv8+s77/twskv+lrNm7n5ljiXItbgPHgsLjeC1LG2eR/E+zY2Qr1AVaOi+2NQN7X6jKo2o9rCIe+deM2siCHDkmEwNsGnGQuthGzjjFk5s8/ReVr63XPfk8PXgV2A3k4RSYsBU1oJ0Z/FdVu0sHBTszhxVKzl8l6YAj6Y9ByqMhVWgcfh7RDFIhoRaU4cbSKc5MDDnyXv5Sh1jN80LjvisvWDc/3VU1+5uLgY0+nU+vRfXUIk2x1AxTpES2eefm2k54mdGuPaoYRoB6jRbSqklwBMvceIUJttcu9nn+IXv+vfY3/pQd4/u5Nas8ZmmhU8LgHnsK0m8eIOTJbRzYP+8bff/hre9rDwa9//n/jj3/08cTMhiiO8f2ZIidOIlCYqG4b8KBtnDr8LaNfOHz+hAaXovFvenV9sfW666Sab9g//74PN/bcNh4c80aZRYxgOhUOPfh4zPIwxPZzmODTAgyPhBhm1WpZsu1LA82pSY19affG85uZ2JNDUqzgGLueMfGELRd0oeV1n+eT7pXumsXTqMR/lS2Z2pk7uMtQI2AixMSKRRiYyZKpRfe4TwNrs7GzERkhPCwOrbww78VFOA/XFR1OdPZ4kOyVS5xMxCBG5k3DSupx2M2J96ZhdPbufON2/4DuP/gTZ0v86pNlUPdXsa//Wop/zfKi8bV5b4MNlX6MtcLH65Xttl0zXbBpg0xjJhMoJW1YvZKq04sfyOr54MdLPEryW0EOZF+coYXN4BCNQl4zh8j5WDnwaiRKccZhabHqbZ31+7oEfpXP8Q/12uw72ZbB71/jz9G8tPm9zaWlpVlWv71744r+id2Knp69D7YtniMFjnAntMuqRUZ1Hy6bmQqSv8M8avG5cr9EbZvzKP/k9/vQHfoN3PNXnDYs72cxznPPYqfxfs4z5r38n8XW7kOEQjGGl3+O1N1zH9zVu5cQ/updf/Jv/hdNLqyStBJfl4X6kaDOUUsHRjU/HUZBV8MvJcaRo2hCrm2ryxxf7y0/+ELvu0CYbA6C5ErDzOe33b9I1XVDV+Q3duKav/Vth6cfWT973Detr+7w0nHgXk/iYc498hs2lfdRmpDiMZYTXBmKOKdAwLdIkGSNtPqRJV9oxHezWIiYRIO/32YT2MECFG7NXkO4tqg5eUXAiTNHL2yyijFnVCzOAHcBe/OkfzVYf+bGGnm2vnD+ovX7HzC4sgtiiJTbCYDBFjqC1JlncOgPtYyKiLC/36TEoqtAkQK/dZl2ulx7woG3uvT+p7cb6XBPvSdRgxIKJQouW5rTrCUsnjkr/3JM+SY/WGR79jpo/+Q9hzx310IqYQveaMKxLfaWSVOBf5aBlLmPAi26QX8iADVV1IjKaC6TeTj2YMDMoiL5XiAvFUOtRoat8qGLCbF0PXnKcUTK1+NwQOWHGrLJ0+JN0zx/G1GbIfFMQJ72lx2r9s4//XAP31f00eWzIsD7G9txtINcD8zuTnTVI3yPd/d8dDU+JRIYsznCmg/WKzWPECaoOtMR/HaV/wRdyQbnDqCdp1nj4/kP8/Pf9Cu7fPcA3tnYw226ymWXYLXVsRSKL73TxuWP+G9+LbbfQYUocRWwOBkT1iO955ev4ivsdv/Lh/8L/+MMHiJuWSAosudBeLe+lyD9Ck7zqyAcak2OjIdbPkIiq+CfN+vnHfwK4ZWnpdJqm6Y0LATOfp253MocZDAaLDJPFOvzFpeMP/9TgwmMmSZwMNRZjZxicPMLagU8zW+/RyZXcCWaUalhUggF7Dd5TNGDCUpSlVaU8B8NqKhOvinxBYGwJoBFCYgDzrxcXO6G20Z8DnbsECaW4OqaSCyUVVlUMvZlOp94AdtX90vdlKwf/bmzO3LZ06iHdWD0hM/M7GPpAr1AiPKE2Yb1HnffU2vhk5rECskUWFzfkOumKiCsNSoqY2gCtuNE63hvm6iUxvnJ6adH+YozFq1Kr1zm2/7TZuHBG8+F+hxz7Du9PfBjoHThABu5m8BnMLMFdXcbi263iw/UuUwAKZinmeezHlO0QwdC9ZGKGw3VOPPk/oAc1W8NGSCp1f/7ko9K58Pl/uCOhc/zA8cPF54pzNKQM3a5nBskHJ7+it3LIG+k68U4iEpQ4+FrjUak0no/juVFnVZ7nxI2IoXf8fz/3J/z3H/xN3v5EjzctLtLxjizPsRdbGgnPLjt3Abswx8K3fAO23cIPh1gb4Z1nZdDnjTfewPfXbuPAP76Pf/P3f4+ljS5Ju4bL81FV/JJ1GbUYF2NMF8C4PPfp4HAbf/Y7ji2+cpBl2UqR/61AfAToDIfDlZla7dbN84/+4OqJR+YkxlvmJZEFfHqeQ0/9MV420FwQJ19qZQl518/8jBl/wNoV/Or2hbuoPU1g+7QIrKqZYF/NC7Zta3Dy/+4tPf63IrNsl0484deWTsrcTA3RAVKoJ48pLQImQr0RISGOGxfKYmD1IDGFAWkRm1tO04f4KFGLPJynY+pDpSnaSMCj68mQ408/LMPNdZutHPOue+jDuKd+57bbVr8dZo/DzCBgxne1Cux4Fwx2VgD8F15YTyunMYoRQb0DgVYDeucfZfnAPupaDASIMP3snF86fO/NdE/89dtuu01g2QKtDJtlmaltep8DN2+ePfKN/fWDJol6Is7hcotqjDeCNzlqMqYzNgXy3KHe02glPPbYCX7uh/4zvX/9IO+PF5hr1YtcVy6Oi+u4uurWN2GQEu1YYOFb34edaaNZhrGWWAwb/QFx3fI9L38dr/6c499/+L/ymU/sI2nEmAJjvtTxaTTG+hikh6IkkUXTw3bl7GN/6U0QmTRNgKGIbAKds2cfiebm5to+O37n2UP3vSHbOOajGCN+hrpvcvrgF1jffAgbr2MxREUE9SVkJj+js+Ku4HkL59TPUrrXQOflwM2N3pn/i/Twt9ajC/Hahaf1/On9Zq4dquya54j6Yi7V+Lc7RcXEJvfxpjEzjxD69LfQu/yEO9oDMHPUNubPqG0GctvIeIse3OJtjBGSqE8jzjn62D7S9WUj2RGPHvp6Nzz5swRwPoPzrqhQL0KaDMs3HYfTl1xMPyLzXp6JpNvAL5fgEY2XoTRiDRxrYwSvjjwd0JQNzh/+DNnaKtbFYDvEtVzWTh/1xx69+/uBd37kI5/oDgYkgjSJVWdmZtr41TvdxrGXW13S2AyMAN5ZVC0ej2qOVgTkyj/zPKeWWFLv+fV/9xl+9/t/lzd/scM7rt1FTz1ZPp3rXryiZ4whX9sIO2MwJNoxz/xffi9iLT7NUBGsMfjcsz7s87abb+R77a088tP38e/+8cdY3uzRaMS4zI16kHWq5xoPxlswGaqKVTVucEI7Fx5/LfB1S52F88DixoZe04fdcXzbPLj3HXn8nm9eO/2EztSdOJ9RMwnp8gXOHL6POO6ADPGqmDzsvfGzvURD7yUgpIt+69aljGb27LnK46K7O6X7KuCa8I6N1aTXugDua93wwG/hTvwVv37U9ddOcu7EQZlptMKaOYMlITLxWCpJtCzG+bg5SxS1H4X2A+zZ47cz4BKnLdtgDETH4sbswai1EE6BooHemGDA3of2DhEDeYxVj3HnOf70p9HeBePXVnK/eeZlvvfE/wfdr4VdTei3IJUhmtWoXSCoU7grOO38rJv1oQqNTphetfwvRZGqGNQ8bvCfelpSAQOr+VCRVyPjwdkiQUs4MRk6PMS5Q1+kaQyRHaDqJZKYtVMPzK0f/+zP3XnnnW9yrtu32I3B0K0BN6Wrh76tt/Ko1uOBGvUhTxOL4vA+DRxkV/T+io6Kbe2ZOk8dOs8v/rXfpfMLX+QvmXkWZlusp2lojbuqYNDgu100zSCy0BsQX7PAjm/9BmyrgXo/YjdYMWwMBrTaNX7g9tdx+6dyfvl/+wM+d+9Bmu0aVkwxmkRHIgkl+QQULxYngvFKQ/saDw/b4fKDP753Lwt0u9fFM7TS9UG0c2fzjeePfOYnzx66f7ZuU0W8GCIS3eTskXthcI4kzK4LEZE1Wwkk2x7e1Tx3SvzgEod9iGLKaEYVSOoLC1e0zONwNt9r8W8D3OnTp0NLZZNrfOfEX7fp/te7/KjLNpbtiaf3SU0ssYlBY0ST4jXJBRIFxYqYOjZq3b9O9EiZblbpqNNcz2hzkwb0V0wy+2hK3XsVc6lAQ2iDCrWkh+ud5sgjX0QGPvKDNTXp/te43lO/Dkt/G9K3gutUjDevUMue33ioVOrw2zGJ/ASrSZmsslLoP0ZRjwunH6S/epi6xIhvYKwxnd4pf/ypu1/H8PgP57ncmPUyF/mZPmR3bJx/6mafHhZjnHhv8WrCfZCFZ+EV4yLUC3nmiCPBGfjNX72P3/z+3+O193V5285rGOBJc3dlXncC21SwFtft4Xt9sLao6nii+TmkVtsyosCKIc8da4MhX3nTy/gufwv3/tT9/NK//CSdQUqzEePctPtyeHJyTUIfnvM0sTJcP0Bn+fGvAfZurK2dUPramKu33eDo9xx7/LO3+M45H8eYlJhI6mysPMXa+XtoaBeTC0qEM4rf5pyfJr+88CF0csZiH4aB7tkzvwMGb01XHvt1GZ66zaXnnO+cs8effBSrOZEp9poIXhQVN9GwHAT2jGKtyXJJSebunQvObtsQmokEEBQaCrVjSWOmm8RJmGWyTayhKNgh1lp02CLxMwzWVzjwyP8giVYl619w2drRa3z35F+D9G3QyIJqSBm6b9auwID1ooHOFZWnCsP1hdeoGnHZgljiw1630EW8uLByHmJzinOn7odhG9wsagbU6yLnjj2oT9z7iW+cm2s2ljvLy40GZ+kv3+Y7J4niJa8+F/Ux6oMBe1KEIdYpkseog0Yz4uCxFX7hJ/6YpX/+CN+s8+yZb7GZpWMo6aoPLhAj+MEQt9krZvwluN6A5Y/8d7KlZSTeqh4jEvjh6/0Bc7NNfvi2N7D3zxz/9n//GPd98Tj1ZlzZ4oJKTi5DMq0XrG4hdolE7oIjO9ZgsPLa2euvX0vXN+ME9j52/2e+av30fp2rKc57clvHu4QzJ79IpCep45C8jdcmzni88RfB+/0Iz3+ubXiwurpF0G67Rozx1xqnoflUEKLr/rW09+hv4/e/2uWnVXJnTzxxCO/6JLGgmpO5FG8yvEnxto/KYALscipENiaqNx3Ulwo7MdsZ8KBwzRkwnJlhsws5ND5tkoVf1ajhwGDUEQqsAhJSVyOCmECljmwbS53IOJbP7+fgo/cQ4636Vd9Zfsjkmwd/AHpvCnUs6sA8zETBQerOAieOKzixFH220blz5xTItjCcK0O/dCQra0ZrrgVEMF38L3uHS6KHjv4bi8kF/+sLYfAa6qFmOwzWDtC7cJJ2bPCSopFI7J1eOPqFXSsn7v3+vbv2rgG71peefH3eO0jdedXcFhX8DCFFfMAtw28KrYO//zv7+C//y5/x6s91eefiNQwNDLNLVJiv9DKB0JGvrEG9hut0Wfm9j5GvrmPr9a1Dgqre2BiyLGcjG/K1t9zMd2Qv53N3PcKv//J9pFmOwY/xYW8wThFNURmS+Qxr69K5cEg6yw99L3DH3Nwuu37sc39j5dDn9kRRV13iTC5KXdpkS0/iOsfC7WqpgZ0HznMBG43gIS3TH6Fsty4zJa9jqiyMceBtCvRTLmIUSSjQ3/stX1U0HTQ2ob5R7Mt6sS/rJYeh+HoYuNZnBs5907D71P/RW903r8NVF7lUjj18L4POOWqJRTTHGENkI6TYq4oJA8YlyBdZbxDNgmhCPPcRiA6tra1l2zWEGBHJRGQoIgMRyUVk2ILzIsl9SePl/zKl0TM2EqNOjc/CfBkTI1isGiz1sPmlB7aPMUozaXHu2FFOPPkQjdgbI+vaX3t4IV166JdI06+jTxO6tZR0ETZtpRmCKZy4xdpaMju74YCBTh21wqTxaqHKUJI0PCb0iY44H+HhuzKklkmAv9rv7ilIIBqR5zFKjlVoapds9VGS/DyJNaReaCdzsrG2Tx998Pe+F3gNcOvG+Qff7AcHiYexsRqDpBgZYCQv8MwaTiFqOX71F+/l4D96jG/K5rhhvs16mhVV1+ei7FoMQu918d0eKx/9GPnKKlKrh/z38gwiLLDa63PNXJsfvfXNtP9rn3/7058mTgjVei9Ibol8n0j7eOmSRQ5k3mRrF9DuY1+dMfga4M2Hv/A/3jU4u09NLTMdm2GiiFqvj7vweequgyHBRQakg/H9guwSgxbP14P35eEcDmwp8eCCtOP8mLATXls99PSAOFRAMpRMgcza2TnoNAghY9lCWnYS5eN6EfT7/YVNZqDR/+ru6tP/YnP5MWvSTZ84a489/hSdtdMkcTd0nYkNUj9EGBIMNYQ6KrYw4IQ4F42syECTPvVbfh44Pz9fn79UCL2lIF7OIKo1F5wjBokRExWKieO9MZ5HNOodAjekEcPx/Y9z6qnDtO0uo8PU93sP7R52P/kfaHTe0em0fM7mSkHyuFAsVClu1qAUVZ+fz5qDxRiIvfd6uXxnVHXc0rVTmeSnU2yl0Wk+3SAvIXaWNGwgZzDG0EvPsrF5mEg91jcZ6lCimnL6yBfl8AN/9I9Jj/+9fPNwO/ebqpETj7toviYCN9y6QCOJ6PiMjWFKzRjMc4WZqEIUkZ44y9rv/BH56iqmXgPvruBHw/0aa6nFMRudLqfPnKSR9bn25plR8QdRvGSFdFEEJIgacCn1Wsby8X1pTP/bjj32O//s0FMPkDQXJfM5lhp1Teh3nqTXX8VYOzImfWZZ07O6fFCDKGRlu9MhdFwYcGnICRCtr6+3baOxc4alv7Z+5p7/Z3Pl6ZZmmzpT9+bY4fu4cO4gia0jrnWZzxNIRSo+RBvUiWvtdWDI+nqtEEjQKzXg0jn1k9aOMyaeJddIjYnCnJ6S4jXyemZEGjCixCYncn3qMuDIU/dw4cgBZqOdJu+s+5Wlz8ysnv3TX26317+5yc41SNMCO6sH4HuwqyjFGyBnedmuFFXyMvS9XO/sKNf1Y85zmQOP2w2L8SGEqvoEEX4CFy4MGAu+URj0efqDg5i8Q12bqIEkFpHBMkcf+aOv5MIXvi7vHCKJvTgjQR2kUrWtFIhJB46vff+trL66zvHVDsuDARf6fYZ5Hir/Is+OjKuKiSOyc+dJL6xgGnVw/rKGCxBFEdZa+t0up08c5+Sxw5w7eZpHZrv8hb/6SnxW7gOPmgwVxWtozxS1ROTE0sH3TiXdY1/4qsc/91vXi1nDi0E1JvYJNuuR954mslmhJulxzk2kQl8S5oZIQDCcRkCtVpvLKoG2QrcBgyZgh3BjCjcOGFw/Nxe9JfFn/8bayQf+7ubyw+0o2/A7kticObyP8ycfoxb3MLlifOMSD7HSBiY5TkXjZJ64seMoAHNZDvnaVRjw6NqIGju/6KM5VUnwagJ0VMBKpScrxcTEBB6xFSW2jsRkSH6cA4//KZtnzjAfX2dM6v3a0j3t5TMf/zfQ+WY2F2vr6+tRyImHO1JMe8hwHE7vtGZx0Qqg3ntR9Zd5plW+boVeXMF5qzmy6hSkpDIhz6MKGAWNQGuAJ4575Nkp8v4SjaKbyGWGmTjh/P57/b5P/LpvRQPUK7lGBZauE3BvaSSZc7Riy5s/eDsnbE6MsJFlnOv3Od/r0csCQyeSZ8dGksgikeVi2qqltxURojDgi/W1VU4cPczxo4dZXV2hLoZD6ZAb3n8De3a2GAxzAknO4yXH44qpTYGjLJJjtE8r3mT/3b+WbJ58WmuNIRoNsDpD7BVNj6DDs4jJ8XmGGAJtV00lOvIjDHr6fi9Zhb7KylY45EOJfXNzuqdJDEgNsA6avTQ1FrsTNj60duKR71w5/ig1N9RZG5u1k+c5cWA/ifaI6WJNhpgrm47ojUONNf2s6SRZ+OxgMBjAYg7NtYv47e27aIq/Zphdf0A0N8A0jPOqtiByiBTGXDg0MTaE2GIKB+YRMupGSbsHeHrf75GuLdPOrzfRMPYXTt5vzx/6039Dc+Ob4rh5K4NBfQiRooMateWiuOZhvryXgff6zBSHK5xXtNJuOMKIq4Wv8O/ela2H5V6QQu5VimkPXfzgDNavhs3qm9g8Yqaem5pdN0b7gWruky1exBe/3Bdc53ToeOs7X4a+fo6NfkoSGQTo5znn+33O9nqspWkYWVDkbvpMQulL4KHGGGwUkbuc5aULHDt8kFPHj9HZ3ESMEMUxw9Rx7Dp45/tvIR3kAXsvqZYjCa0A+6jm4eVyrNukLsepW0TEITIg9hE138ENDiC+Cy6QWkbihArqzbaYbvkqRfBLZGF6jas/eyUeGCDLMhd4/JtAS8c0uWYfamtALv3++VYitZjV7zv19Bc+eOHEw75hc5rUZbi6wZEnnsAMhwRRdYdnADK85B5VLVU1czWRxUYL54y59rfqddcP0emDw22LWJc/FJLH48bcIzZuYkyk0wGd6Jgw7sSQi8VJ6BjxCFabtBJhbfUB9j/xJ8ggo+l2m6ZPdOX05+ZP7f/jX2w2u9+dR903SprXapu1pYJPmhZ5hjl9uu+AOM+yy27crWA+2+TCBS9/QtXRVJZk3KoWTubye10w3hxqxiD5BTQ/SmyHWE1Qb2jNWlqznjzvFJP+POr8RSYrFBJs3jPbjHnjB27jiB+SqAlKlUUInTnH6mDA2W6X1cGAzPvRvz3T8Lrc1NZabBSRpSnnz5zm+KGDnDt9inQY4MEoinCqNK3w1OYGe//SDVy/e5YsL8gbGirq1od+6nKBnOTFZ4xwecbcfEqrYXF5jPGWOpvE/izi1ohEQh+YVOZC6dWFz9PP+JlAv1r0FQM6MzNDoYklI2cGG/SW5hsN9sasfejEE/f88IUTj8aJ6UgtysUPNjn09OdJ+yeoRznigoyxGo836SWtLKRLFkfuk8aMRvXZPwYegVYSKMhv8lfsgcfXgwY4WWvO3d9ozeIm5C6Kg6kC4zgsTiy5RDgJfxdyxFlqpsmpUw9z4OCf0jA50aBuEp/5M8cebJ146rM/FkX6fogzZvZtFJU+hfUEqO3cmStg0izTq3E2ZWWybCsc5cG+asRMCd1NMCGCMXvB43AyLLBigzgwbOLdMWLTC9I4orR2NMhtF28GWJMTSYqqK/LsyREwJbkEgX4/5W1f+zLM2xdZ6w+JrYyO2xKXdd6znqac7XZZGgwY5HlogboKQx4ZbhRhjKHb7XL65AmOHTrI8oXz5HlOFEUTFVprhP4g49SNEV/9/tvIh3koXI2IMGBdjFFBJEclxTMMMr4+xvkYjQa0dxjw88S6gyS6APmJ0I1lJJAZ2G6WmLniAKPSMHXVDcFa8sadA/AzM40MWsPKZtfV1dWkq4sK/e869+QXfuTswQdoJ0M19MWaIUePPcD55QepNc+irCO+Bm4GT1SQNS71+wU1BpVcTBRJVJt/WMRkkM4OGTYu9ngvszpvCk0ztfn7e946h7WoaFTQ+ZyAiiJS0A6R0Yuyb9N6vI+ImKEZw8ljn+fk8c/TqCnqElOn608+8WfmxKOf+o4kyd4Cd9TX19dN0c0BkHzxi6dzYFb8MMEXm6eYXq9lSFuG10UbmR+rok5E0OikfAzbecbpRgcfdPtUChkcjdHcYMkxuoaVZSx9IiM0m5bUdQJcQDypP1xoMYeWPB84XlL8qZ7ZesTXfugOjiQpSdGmXt1gZVFLgU6acq7X41y/T7eSJ7NNeF2OlhEJoTAoG2urnDhymJNHDrO+soyiI8OtrkHwvpbHeh1e+Z23sve6GbLMhbvTMR4fXlJMQZBCbF1G1brMDWnPGGpGScQRyRq5W0NMIMtMtPcxDdIWKUcpG1yhwI5plcUDrpQ6qmN1LvYabRAJg9SdUwHSTjrcm7P2+qLqHK+zniT5QrPV6n7X6cc/9aEjj91jZiIldrkkkXLi+GOcPfEwzVqKd33EaBBrMGMF2UnERkbRqyAY77BuoJFpm84wukBz1wOq3oAf1NDBxXoGost64ANv6nPb7IFodsf6YKOxQwYD4jw0WKeRCyeACzcTjSpG42bqTGMkdpi0S+IznAr7n7wX22ohzWtJhpmZkzV/9PE/bXrVf/+y13/jovf+IwOIhLm4Rhq95jWvuQAsGAYN7zwqQm4Ui8WmCcJYf7ucMTSChlAwOi6+mbJ5uxj+rKH6GDSmZYQXy4Q/GNe9S6xYRMIgbJMTmXPUbIyNa9RNhvUO9U2cNMEqagqjLcJEqXad4xHJsBIz7A/4ijft5t537GL57jVmmwmZ81sObqkQwwd5ziDPSaylHcc045jYmJBLlh5ULGKFPM9ZWV5mc3WFwaAf+M/GYCS6aK4YWUO3n3Hh1hrf+PU3k/YyrC3qeoXn8MaRm7QAYQXri44rUpz1qAxBHXVjaCerRLKK6iDkyjJAvCmKhGW+IhO5raqSe8X58KcvZkJrMcjMaTgkArbrEakorlQEHczUoSYjhTtBTJidFFIDhmL0RoFXwfAs1M7as3NxazffdOKJj/3s4Sf+pL6QxD7WlqmJYXXpNCcOPsScDIh9E3F1vG0icYZEPYzUgWQkFiGVIqpo6HOOfEakQy+tl9m0sfd+4BTd7rW0WkNg6WJMsMt74NsAaNbqs8dr9VlyrJbkCLmopmc1JDVjpoxXEmvwww6PPvh5/GAda1oYO2uMXfH7Hvn92tHH/uSnFhYWrt84zzlDbybDzbTb7QToZ2mWjVQqNExnuJIAK4TKfpv8SC4SjslW/HgbD11GaZFPadg+jdoAo4Mw7YAcX0yBKEXqts2DfTWs9tQjw1s/cDvH6xn2EjU7HTNxsCKkzrEyGHCm22Wl3yf1nliEOIoYDAecO3Oao4cOcP7MKYbDAbaAiBQuWuTxKA1jeGLQ5fZvuYVr5hqkWX7Rz7L9KxxA4hyWIY3akNhuYuhgNBvh65SaZRdR3rzc/prskrp66KncU1nWDQqouTyZD+0fQu38+vr5ne3dfMPhBz/6s4/e/7G68+te7cDYaEA+vMCRJ+9F8s0CmXlmjGoVgycxmbfanFs4C+S0WnK58dTmMpU5d/r0aZum6bmoPn8oauwk80Z8Mb9WtoQ9VRWM8dd01O0BmqU0IsV1ljn82BcwHnIv1OLU1Dnnnrr/DxeOPPhn/3DXLm7trnXzGD8cDAYJkA6GmZcCtjEKUTGO5HLJTanaMDZAmSqUFBVmkYkQe1y8mjZgndhCiR/QijrM1LsY38U4F3QMGI7a7UZFq7JqWzXeQnxPROj3Ml7/pj3Uv3IXF7oDYmsuX7irGLJXZXU4ZLnf51S/y6ETxzh5OOS3rsxvC8LE5aqz1gibvZQLt9V4x3tuod/Lxl1fFzNYP/mn9+FlFCx92s0e9WQDq+uIzxEn4OyIm36xZpMpEu2WUNuXz8pXmFVXwzglRhSyrBMBO/v93kpWk9UzB86Yubn2D55++r/9/L57f+eamHWtJ9547WOjPk/v+wK+c5aGFH3dWkZrxeGybX1lmwKaGvW2KRo1UxPNfKFge+WFy/FXnQOXbVJ79uyJ0zRZgtl7vLQ31TbEGaMUOa+Ub6NjHrIwDk3CE7dFK51gjRLhaEWe9bNHOHr4YeLEYx3UVax2j7l9933k648/9j/+/fz8NcnKqTMXkmQuAWpplptSEidMGtHQCH0JRtZYwqkMq03FC09uAlUZR3FlvX1LFbvUZirY0wLGDamZNZrJRjF2xBRhcqCvqmrBfy4OvTI5r1Siyw4bUBpxxNs/+CqOJwEXvtKDvOy5bNqI83nKZzdXePLcGdYGA5IkxhozPjwuczmUprE83u9w+7feyjXzDfJifOeoL/gieOw499TRCWq8ItojiTdJ7AbG90NSpyFHHKU7yNb3qjaIbfN8R6VVrUjnlP/vr4y1hxo0hzxPI6D9C7/wa5vdc12uu+26Nx878Gff+4WP/9qOaHjBN00uMUo9Mhx46jF660vMxRHWOcbiNmYySlCz/YFS+WAeQy5NouaOZZjZX2yePjSjsmtwO0kfcwnvWy5Xf2Pj9Ca0f6fWuubBuDmHk7BzBTvSBByXww1izAgnNhLUmsTYUNgRweCx5DRj5dSJh1hdOkJdZrF5k3qU2+7mw/l9d//q25b23/s3dlx/62vSzfOzQGKtxgVEKK7Ec/1kqDs+kXWEJ5aGKsVUi4l+4aqX9aB+O1H4SQJ8VXzdB+1PoAt2MxD8fVz07RaCI0V3dqloIjoJVEnlQBEjDAc5b3zrXtrvvJalTp/kCr1wVHjgJ4ddnhh0cEBiI9bSlDPdLkN35S2JkTFs9lKWb6/zVe+5leEgL0dvbpMwVWoEF01jPGiK+B5GB1gh6HipCQ0XxZwr3aK8IRVDHjczeO/xjlGn2QSDblTI1Ileja1FrDEiEJwBpINMgPwDH3jP3LXXXvumC09+5kfu/cNf3+M6591MvWYirzSIWD17lgsnj1KPgFyITX1i729fkJv2uuO96FU0qu8gri88DOwv6lMCA7lUrcpcBnIQoL1nT2JFzPHa3K5PajzrXNm1MxKMk615icqo0iajiqHBF4OoyhJcbLoceuJe0u6ASJqICu060fq5J/wnfufffzC78Pi/ue6muTdAfwEy8RUOdilCeDl8YfKBySQW7Ke+VulmmZahnQ4VQ0gseI3wkqMyKH42KgKfUNQpB5FVWmVGGw+//fvHIrzrQ1/B0RlPpJeBP4BYhHWX88XBBqeyQSB8FJvTijDMHWd7PTbSNHSRXYIMUnrfh7MOb/juO9g5V3rfZz69QcuHpR5xBlyM9zEexZMFKmuVdbXtVjVT8NLUxI0tOLBsexBvfwo51IMbeoDZ1772ju/MO0//m0/+t1/+5vzCEZ2NI+vUE4vBdbqcOfwUzSgDN0BtHBh3TNNwmbpX2fb5CZB7kNoOb5vzj4bmicFM5UNHBRf7amEkosBPXoxU/Szs3GdqDSUUyFUmWrGmJ8uHk9CMRD2lYGkF6UxfvGoIpJs8/dSDxHVL7huoa7Oj1TArJz7jP/67v3hzmg7eBtnXbmwuY2xo83OmhLGuDN/baoDjCEYnMFo/EoUfe3etqH340UYuYQ2nCbkoOTlODd7V8N6E7y3xZ1+891SOuG2OLdDvZbz6tdex4z17Odvd3gsXQqhYEY6kfR4ebND1jqTswJrKkQVYHgw43+/jCsPe7kqsZbU3oPP6Wd76tbfQ76QjquHkGvoxx3uLQMLUaJOyM8hHeF9DXR3vgwBALsPApy7f73Ii8xN5ZWDSTRcbuVrlEjw2gn4v90DNuTMf/MPf/qc3XTh2r7smUSHLySUIMR8/+Dg1v04im4jpkZHhjLlsnn6pDDgy1njbUJjbvw61wUhTXWzFiOVqDRiCeka8sbERQ3Sw3t71iCQt1Hi1Oll10+0oYkURSykxynCoKIT2KbU0kxrd7hmOHHmEdquGcRZxys6FxDz24Mf1D/7jv/wwnHtv3l8rPG/AGy9Z6NsO96uGUcVQTV9UWye7kSq6HKUM7SjPMmN8ucAgQ+uhDdS/8iu+4FkXMqyVH6qeHKO8V3F4LXWnPIrDeM87vu1VnJwDybXS+1wYmgh973ikv8mRtEdQ8JZto5LyZ6wI3SzjTKdDN8uCp57yvjUVHvc9XveBVzBbi3HOjfWaKuFLeUxINZ+vsMzKVR5raRFyTa3mq1oRYzeXOYovx6OaetaXxRvG/+aNiCqkvdUc1n7oo7/0r9750Gf/WBd3NK1zGUaUVt1w8th+epsXsCYd1TgwpbbZpQtVATs3Yfg4hHGyEp65JG1sbeETYA8C5NQ3wy+o9WDNFXZ41c0MLrzJcGF21sbGRI80mjf+Wm3nTeQ4HzsfoA5TLepIGE9hQnODt4IaCya0/UqhMGhQjDoUi3pLux6xeuZpeqsHaNeHqM8YuDo7Gi156hO/0njio//8xmTYwYuIqiHJgxEHtQaZCCjL3NblgjrDNHo2Ml6jOMNkI3+1iF5SMMSE+xeDMXYURRRZG6J9cAnimhgdABuIuiBaxpjCWpIdglt2YT4vOeqLOb3F11UdGM9wMORVd+xi53tu4HSvR81aPIopvO6JdMCDg03WXEZS8NKvJFe2Eoz8Qr/P0mAw8tABPzEs9fr0XjfL29/xMtL+kMgWw8e1jLMUozrO5bVixAWxRwsAVnx5SFERbXOo9FEGRYEvxkiEGdVJTDG7ilHh0RdQYFnb2EKjLFMqEbwpD9XiQJ6qhUy+gkPJJCL3wo5kpX3kj3/225/85EejvXO7Jc0NnbhG0rSkK8dZPXeYpG5IHaiE+44wIb69hIrieL9HqCYonsgMiWSoGCsDZjca83f8Q5HkM3PI6ozIeRHJgNMwv1707esz8cAR1ATEeJ/H1Bb3e62n3sXWa7ksU7mGcsVcNtUww8c5TxRZThw7gvcpURRgJytQq0X6B7/9W7q+vBw6Za4YX5OL8KNlAnLYtm94KhzkorkdW3W1toSRVzZxUCo5cjm8yXjlnR+4g1Nzgsk9kVhyPPsGHZ4e9sJGELnq8fElBXOzKHANnEMEGlgecz1e/4FXMFOLcWXacMnP4rf5N3/Jzz3pI6c7wAJ9VSc6w2Ty2fit6IDqeP7VVfcCe48Yw4Wzp/nd3/j/fLNRR10G5MSxwfsBJ08cpl6Pi8kVZXOLBT/untr2VSG9jHbleLie5sTUm7MD4GSZI5RztUXEX2q4+BXxIIBVaHYffPBBIFpttndtGDsvedGEvH3cX8VaL76JVATn3YiOqSgnjh+l1UwwZOT5kDiOpN6sS5oOscaEHleFK5mZvtUopx72Ns0PflThZkuBa1T59lvF8iZzQSaYRGMqoC/6gsd5NxP4qR+9pwgM+hmvevVudv2FGznXG7BJxv29Dc67lJoJtNVn2mJYeuPMe851u3TznOXugP7r53nrV93EsJ8WHUfbcLin8uDJmVN+S54/uTbbqUqO+erTtYqyfjD2yJXqrd+a+24ZvXMFmLCIEkWG4WCAja0x4lGfImS06pYzp48FEX7xBMnvor6kUTDi7Uypqh2p4wKcSkFuMRG5t0jUpj53zQqwqqqF/DL1K8OvL3+5UBWj/6Y3vckB3aS5a79JFnHGqB8JU8nVVf2mezbVAw4hp9fdYHnpDDOtGCsO1QzE4fIM5/IRzHBV/SqVE31EMNmSI4/HcUzcWgFLqC/xTxn3GGtVlqXKrfYVqEBHLYQTfa1V71tJ3qo5pREB53nPX30tj87kPNLdJMMTF7nus9VyK41YEXppymfSVb7yO18bvG8ZmjLNQhvjvGNcWCtU1kkseNwDUx2fWq1VVNelQsX1MoaHRnpHY0+mlXxnhBow2Q5+Nb3AwZCL9ManGFJm2zXWls/Q761iI0eeD8dKJCPuwxRhQ2UbIkeVi6sFTcKS+UhrrWuoNxf3AR1YSriikaxXbsB5hbjbAtZsbc/vmPiaQS7WeC3x5UDrGI93lAILvhIPUeagoY80iZSVpTNkw03iGFyeYVDUO2IjRSMAI5GzMi+qYr/Bk47zL50o8YeHLxMQmIyYZd6P86exV6gC/xSyJxXR+4Kd5suHM40fF/fj3VhL2U8XfSoerbwbI5AOMm5++U5e8U23sjFMaViL57m7PFCPDGe7fcw7ruXNb38Zg36GsaYa9E1GNX66Ej3mLvsR5j310xU9bl8ZaO69rxyEZkSiGRkKVCR2ivfVwoBGPekV7oGREQda/ThE37pPKgcoihHFe0dkQcSRxEI+2GR1+TTWeJzLxzyCSnRWKrpUI0/BjO5/0kmENXNeyXOvuY9Npm1HsvPTYarnNZsiclrkUg3EV9UPTM5ocBc7oJNC+/cbc3sOa2SRCXSjegpx5XS2UaqgGAkTC4SMleUz1BKLtQYjivPploa/S50OIyP3U/RIz/a4b/Xrxek/abyyNRe7FFa8pR/50nzoQCaYpFhKASvlqeObv/eNtF65g94gw5rnTmpGRHCZ58CC8o0//HZsRQbo+XpNwgUyVZm+2N91Sr+sXKepn/fTUNOV1WIgGLDgiY3SqBlWls9iJMOUDlGYKH6VRbkgkWqmTGpSBaaM3Er9eEXUxE2J6wvHYPaPnwmJ21zhAV20Mg2bQ+KdwFprZud99WYL551u7aO9wkWTaimjEGMRxRrF4MjSPoN+h3azjs/zQq1eryp8HreTyba56bgg4itfn8qZ/fhn/AR/eSoXnP6ebcgfvhpaVvPHysSD8pdWfzbLHYu72rz/h9/CqniMPDfDvjzQsJZ9vU1e/Z2v41Wv2s2gnxasqFJbzF8k5/Xbc6JHg9X9ZJ2g8rPbGdA4b2Yyl54obhXeu3xGTsZFs4oOmnL5ppXpfRL+kmNQms0aab+LaBbmFVbH8Iwok+XudRXuAxepdAvTOqrOeZ2Z2UFzdsengOP6DPS/LmfAdjKM1mENzYAsmlu8kLSvwznEIhi1hdZxaPNStHJKVX/VOKwSnfSUlLKheViQWhLR6azh/BAxGvJfxjnRFTWwA06rhjwGCb2v5qEySU+thj4jrvL4+8fV04LbWf6710ruW8JClTEe+DG1cpR7VbjQypaKd5kz9btDvuq9t3P7e25mozu8okaHy61NbIXV7oDua+Z53wdfz7A/xBqpMKJGomLF/Y3x6zL0nFBH8JV5ljpClkZQ2gQXu1JDqOqEMZ1vV1EAdJJhN8q3ZRyiKhMNJ1d01GnJr/ehtdClDAfdAhIrQ3FTjK2dWsWy51sq8sWhllzogesIuhQ8xntEDJmPhKSlUXvHqfV1mvAzz7kHFsZSmkD9JNTPpOnqzdBczu1tF7xpGUumNjNhTIgqzoabN16KucLhZUzgThsxWCNERgMy7JVIBasReIuRCCth/GUU5XjdQMwQMa6gT4YpumEgt24z+7WclRSMNJegdD8qyui4RxRf5OrVQlwlhx3ns5U3nj4pi7qHuEmWFd4j6hDvEHVBytX5oA8MiHpshRImha5JID/4EEp7Xwich01iNedbf+RtuGvq6GiG7zM34ATDPunzng+/hcW5Gj5ziPcFpDVuqBVfzgX2FbjLQx7+zagvsE5GjRt4ME7AFVxoH95bvY6HcvtgFBcLHlVlywD3kmZV/exls8wol/bVirkLYbY3xUvG9Y3C08tIXzoHk+J8D88wkI/EBt5/ySyU8e7zIkXvczSuy4kGhU7v8Jqj4sjEkYkiLiP2HpeL5tGMcbUdHVj82NwcG3DXc27A4RkHHmb55nmitg/x0dbsrk80ZxZIXaZe8/DBZEo7UeWqW7uoUDRHtMVLhF8Xh46q9GOdcBTb56hMYYxbFSqnC1pjMvoV5H6VwtUV99QyJtsbEQb9jNtfvYuv+Z43sjRIicwz88KhcGU52ulxzV++hXe+61a6nSHGcMlcvlS13B4X9lfJj+Yi9YKpf/PTGDtTGPxFdM+m9sDFQulykPlkx9k0s0quwNddHImRig2EKZWiUdKmObd4Bsi5665nUDu/Mg9c6FON5ghDPrsByadaC7vvjRs7NPWCTQxeAvAtBV1ML/XhtSKBchlDnsYXL/dDWx6gHz9EX0wsnMZ2faV4NdaVZpu8uJIb6sWE5Kd5wJMGeTku9EQu58ekCHzwuINuyns/8DoW37Cb/iDDPIOCljFCluYc32153/e8BZe6iTRDq3mrHxtnqW293WfwlzJWv51hVWoGI+2yYpKCnzxQ/XSB0TOFOEx9T0UP7fLEjqp8rd9G4P/qiEOTDmucOoqGQQHeGDI1tOaupd7eeTBN0w53fVf8fBgwlSp0ebVp0XvwQZax83drvLDpTdOkPlexvjKwyI640OPkwEyRO67EO5cl+iuHlbfVParqH000OVSxwEozeAUz1tF4jnGH0liqaSoX28aYqbCPRpsdP9HrOu11xzirjrSTSrzYO8/sfJ33/9BbWDP+qgefeaBhDPu6m7z+O1/LLTfvZJiWzfp+4j4m19VPeN8qdXWcx+vkQVAtU06s6RgGHLUAjhej8uwqs42m2HTVOkUVu78qZUqtthSU+8BXSqtXacDK1mJWca+muE+HqLcNI8nOHsx/0TnXgdvmn8mRYa7AeB3gqv3BQH748Ec8cKy1eNOxeus6ArM3x3sXsDw3ZtBoIdwlYoqBTuNSvE51DU13vYz4rMpoPnFZcayesBd9VafoVeAtqWDCviLnMnFWVXIqqcwqUj8WJjMF7iiVaqq/iAf2lUjCOYdzDl/86ZwbYaLO+fH/Oz9ax/IgMEDazXj7197K67/pVaz1BkRXWNAq+c7nO32yt1zDe7/1dfT7KcZsV53X0T1tYVlNY7+++m+VVZwIX8dGJ1Nbb+xNg1GHfNZMHPq6TaueTBeiily2JHmEPbN9t1IViyznX5drNIkwXEHqNupgk8reC4eSCxMfRmF0rl6j+hyNuesfh9mPbm5uLgPd58OAywM7V9Vq7Ty/8847Fdhozd74aald5zMfq7W2IEdYJkX0LlZW/xJcerFG7imNaL9Nz7Cf8gQT1Eq55EDpy+KgV/P9kznA2FM5z7d++G3Y62fwub+iYWgqECk8mWS873/9StqNOIjYX9FneBaf01cUT6ZDay8Xobxu87yq3+ur7Kup/m2UL/21XQ4cDiKDCUVOrwzTXJPWTm3N7/rkUdi3a9euHcDcMzGKK6VSlqoAZUErBmahs5Pkht+w8c4LNmpa79ULJlQEkTCoCd0mwVeeu7k3VVB9+4NhgjlUbeSvGq6Xqa/pBAHEM4VLet1SxPI6xj5HXkn9tjml3yZvnPSAjPjSoxDbV+iWwHCQccPeBb7mu9/ISp6FwdGXWCUPNK3lUKfLnm+8lTe8cS+97hAxVXUKtslpp5o0LiNGUGWZeZ2kXE7mtkXzZcVzj/Ldcmqp99sUHsfv51XD91aYc+MIeFr77EthwFNxQRnBEbrQnHeqRmzUaGeY6+656TzRkGEbesIzGAN9OVG7snhVTpsqJwfOAjO93iACzjYXrnscUyfLq4qNU3pTVDsyxpVquUjj9RZJV6kwP64yO6nmSWX05Kv5WgXK37b7xWtlxIpWcrnt8+xgpGOJXXQrl5iJv/txsDOhTh5eE4dCaUiFHtewl/L13/Iarn3rHrq9NDR7XIzzbITeIOX0jQnv+543k6d52N9ly98UxkupqEnla6oleFfJ43WiH3hrMqpjWKzAaMsuaCoig5Ui9+j5THClq509nnFaUd5pgaNPcq0n99vV5cVsRVQuUX0ez5ie8sZlfu89Kl7jepvW/HXHgScHs4Nra9Q60Ow+L0WsYm5wKiL9oqlhGVg+cODA+Wbz3FIPFms7dz8Z1xcgBVtIy3jj8SRhioH3OC84L+SE/mBVj2iGUcW4oLEccMFqfixYtUQaYdRgAvyGdxJmxHpTnLh+IlfbvuBdzA0uzaLYO24EWQpOS3Sv/FpQklA1FQzRVDDFssBli78X41d8Bi4H5/B5KDqpq2pmTze/BywVHxr7A3ZczFzXDK85TnOcOpz3OM3JfU6uOanLaNUjvunDb6fbisL7bBNKe5S6GB5Nu7z9+9/AjXtmSNO0wJ1DBSN8+qyYJJEV8rgBdVdy0HzUx0yBFetomHJohzReERf+TSphv2QO8TnlWPWiWZKgMGqLRv/AbfYIvvJcyjnPI4qIBqTAIaOq9ehYLnSXfcmR14DFjvfIWC+66rG9A5+Fg9oUbsM7F1xXaB5HvKXSbIwU3h8fWgrd6PyVUUQXiB+mYFrm5JLqzI5bac3c/ovAGVM3c4wE7J6fKnTVmH0xBDy9/fbbh5CIG9Jtze5aSmZ2+txboxpVEFzZMot32zCj6qKv6FTkikMizxSEMfH/YxreJAQx2VVDFZaYCBXHOZmvYs4lw8uPGUzTXmqafonfDltltNPGFMGKPE/RS93vp7zuTXt54ze9mpXBkMgWIkYydoY1aznT6WG/8lq+9hteRb+bjkLncjLZtl54pCjii3Xy48ilEpUwIelazX0nud0TOHpZEKxICZXPxV+izuB1m6hqItTfLmx+HsNo3eb9t+xnwZhIMx9bF7X7NHc/uLq6GkGSVQpGz68Bb702fFBkaR2Z2XldV22b3MehEqgVnYtLhh7P/VVV5NepHtJqPagkwocQx1f6fasGy/bc5pE3LXK0ixBIfEWbp/QUI6Md0cKm+oLLMTHeTxn81Bv7cd9wnuX85e99I8nL5siGeWhDrFRajVf2txzv+/DbqJkwWYPpKquvVuSZ/D3l72cSn6bsRqpAX8Ehb1N9H7VhVo3PT3LUR3WIaQJJBaWgWmOYxpjHnPOJyQxcxMi+RJeqkjpVNXO0du7ZANb7/X6W0FstvG96qcb958mA35RL1l0BDrcXb9qw7d3kmuhY3JqLVJ6fa8MdF7G2nNpcHBOukjLwVdwRtk3lplrDql5iGhcepbZ+lNCFze6nmAd+stKsOsUtrvKvtRKyFl8XHyiM+TBj93UzvPcH38y6+GLi37hw9VS3y80ffAWvfc11DPopYayvIm6sWa0jNsX4FBxpVhWyqyVFUqZOqmqzAttFG1pJ8Sea8SdVQv2Ie17p364ckN6XAYOMD5np6vSEMbONUuX0IIKi+ifPo0WL4r2hMXMDzYUbTwDu+uuv70HzHLDxTI8T82zvq9Vq5cONjfO2fd09rWtuYpAKPg9N6M75Irowo8KWYIrZu1Lkl5OA+bi6WOkXHeGlfjSEeprRpR68C3N9pfIfU6dzkQpsJX0UyyGmopwwQRaYCv+mmUWViYfj/lMmWUvO4/J8sie4NJTic+JcyJm9R/PwNc09uAITdh7nXeDZVt9DlH6nzzvecxt7v2ov670hxpogmzNIWbmtxV+88ytI+2m4tyIvd76CNxcv9S7cjy/vw4XvdW70u7dQRKv349w2rKxp+E4u0tY5XsNRAaiCA6sXnB+NByvEEsdY8ggvHnEPihJWuT+839I3Xu1e0gKj98Xe1SkcvJrieD9VyyinVng3LjyOquNenbcSzezNbf36P+x2uzVVjRn1JNLW56md8HJV6s5AdQkWP1qb29vJpW4iE6nmbtQUIBMUs6vhl16sorydrtKlaXJVqh066WEnQePxBmMb6p+fOv0n6JqeCfbWOCwcezPVSc87nlg4ziOZCGt1S5V4nF8XLisonOM9NGLDN/7AWxjMRqgPs40ey7u840Nv4JodLbLMF0J0vijXMTpAtlSTKxGBjPIKnWhWoFojqEBIVHnfI/khKgeqThThJ9dcK0ytSlTENLWychAz2Ts8CS8yyfybiKae2SylK+MfVAQDRNUmDWnPXH8U2r9lbbZRYL9NIBkw2Mllhw0+Dx4Y0CiKEmD/7OINn5+d24V6pzIhared4Zpn2Ogwxla908sqU4yKVr5Qo6ye+q4SZvmphv8t/NuLYMoTBa+Knta054Gtsqu+Oqt4Mkzeoh9VkfTBb6NP5R1GlGE/41Wv2c3bv/019LKMk90ezXddzzvfdRv9bmBcoVra/AQVdHxPZWhMJdeu/N5yrfBbOd2jPHjqa76iHlkU/3yVa17VGJsSWhjNdPaTKYuWGPAEGcdfZBiaTLHBdIs22nNuwyOlDiVPU223F3Rm5+6PAQO1td3QbxK6/eqCNL7kIXTh8qXVauUDWGvuuPZ0c24Xw6EnslGhulf1vspzkv/6iu/VaSLH9KuS+xa54ygNRadqQpUNVPJ8/aT3pdJzOjmWpfRUTDTkT+TGhffSKR1ltrCWqtOqK/rRlVMlqFiOS+qlQSGB4PH+73wD9Vvm2VfP+KYPvz2UOaXiqqiyJvxEQWpC1+siipLT3zeKEHy1zlA5jArXuzV03UauSJmoeFMeCH4bQcIRJKhTVe1Ls6WqNYzxmsh2Yeb2Bddq3/hFJi5oRd9skDlp7bheajtuOLYJHRs3hiCWzuidrhKsDlf0LE3JANH6+rrXWs3X67s/Upvf+41OWjuyfKCxOMnVkXk/0i3wqgWmV/FaI0rcZHikOlX4Eh3PUincknpwPt9S8auufyFkOcJ286JTrByY7YtQ3/ux4ZqiQ9+Y8H3emMpA6yJtKXIyMUEl2noZQS5EPsw/FT8OR41uMdxy/ImUelplk7zXYo5xgV5L2SZuw8SLgk9czqYSDVrVYjx55plt17jzJ97JxvqQG/bOkfYHRXN6aEAXLXuNixnFFQKJlF+fmkQxET5P9GqCUTtqWFe1+DzHuwC0q2MCmhrRHv1kQ4lU5WeqbLhQAiiq22Pq5GhOcMHoUlNkE0Wl2o3E5cFo8WxKOpFQqaUEPFkQxBbmaIo3rITe3iu2yLnFhF5m78PgAustsbNoJOQGjEQkNIiIQTPN7JwZNF61Ca1sZrixg9rsMah3aOOAWo3aMly91NmzNWAB7NzcXN4PK3N8xw03nV96cmGH31hTdUGT4ApA3csTeCd+VkYGdMX5SCWH9hV82JtiWHWZC/mC9OHHA2TGTiscPEbHjBtP+PmygCFFp5F4hzFFriu+ZOGETS8h/xQpG+Q9xnhUDcaHAeYipvj9hTCAqeZxftQEL4XyneIL0XgFMQz7KXe8+QaMNQy66ch4tYg5pRJ3ls0hVPWcC8/sK/gvE+H/pIRQFcemgHeqemRSIdlUdawCxDNmt/lKbWHMfKtAfownZYzx4sCXmIiOuLRjvXi+JcVaSShOj55ttaA8rfVhRhMz3egXBgqKIuQ+17ldu2Vmx41/CtFp2BTGqpP6zA3j2Rtw6VhRyAcDuvUd155u7NjzyqWVY9SsBTcNH20ngP1c4m1TA6ELgpcpkBEjoSgeBsFraQujLieRadzYo8aM8+DyZ014yCK+CON01LykvhjgJTpiMhljgpEZF6bJE2R0jUrhtVyoqppyPKsLhqyMQghjKL4WDLocMF+d6CejMZ2GXmcYmhesFKSRolVOggEHNpwvFCsYGaz4MOZl5IG1qMqqQ11QFhEN1WrvXFG1dsX3BQWS0cHA2HB9tYNsi5GOU4sytPV+GzEFr1MD2HWKnFPJiSt10yu346qUzzjQsKLIpd5BxyyssrDozABPxCBXadTm0tlrb/4zBtkXqS+eKWxPRcQV61OKbeVfyiKWL37hsLm5ORwOWYXFLzQWb/aZ1g0SVxWwKtCAeZ7w4K3Y7SRbZxoXHutAT3a6TM+d1a0/6yc9iU6IAuioQDN++S0vnfj/yveMvN72P3e5V/m+Zcz/TH62ei+j1xW9x3ZidDrSXZ5kwV1EdXKb5zCeUSXjMHyq8LiVuKMVZtzVeqatMNil4tAQsgdZ3HBuZxjjcZp5jZsys3jjCtQ/2cnzzaKXINsGjrnqEPq5gJHC/KSZmc25n2cdmh+fve62o6axQJp59W5KHeFSEJKWGstmZDjjTVTpdJlSRhx/73aT7cbN+d6NWTlVneBq66D3UMCxuFLGymnRo6vjV7FZy/8PfFqPK9r6Sj3s7catTMvxTTQq+ItP+vMVuGfbTiY/JSLP9OYrMPQtKidcUk3TT02g2K610Be4f4nXl+tTet88V1xe/g4ZETnKzxDWN6z16L08o/UtVUD9BCVTRoabl89rxLyabO7Zvo1xGtf1W/uFS/HBbWSdSjaeIHgpEBE1WALX3/mcoYOocS3ze25bAc6urq5uMO79rdIfhiLypTXgqZvw3HW3OXuW+2YX9352x55bSJ2qTAhHy8QQ5ueVn3rxyGjKu056g+1T9otRQaczlzJHM+N8+iJEhnFevo1W8jZtc1XCy9YpEKP5CVNjXKqVYrZpah+rYU7QJNnm+ypQWVWbarpoWF3k8f1st24VdRaVy0COsLU18Er3j3net9bIfZpCiVVtKPYBuY9oLtxK85rb777rLjZvvPHGPjAYgSgByfFXGzo/lzDSqBoN74rtTHeW6Pp767O7elZiIyK6/aJ/CY13erLAFNd5C6arW43y4htpetOZikZxpWHC+wnIZRQmbyN6N9GHe1E1jMmf9VMYMlvmGE2+9/RkiImQsdqwMDFxwU8Ncrt4B5ifmh88YbTVbTfR9mcuwpWXbbbtRaCdLd/zpSI+j9Eg8QZDEFuOoqZJ2tefh92/c9dPbCyo6mwl342LKNZzkQHez7cHLlcxKu++bUwMPH3N3ps7Sb01or2xXS78JbvGTB7PxRQ6xpXNrVrWbBM5TDLLSlFYrWpoMS6ylP2vvhh2PcYvmRCNG+OyF58EuBUfLiBezxbu9Bi2msaeqTTkV5oKvB/16U4MZuMSUwpDNWaEiSpb1SUvNzer1JcWLeAcndotOm308iUyTbksijIa3zT6pzDiRb1qUpvj2j23PQI80o9dq2BfLQAzQKMYZqaEObRXfUXPwScsQNHhXqitNNby/tBwZmbxli80rrntG88ePa2NSMTkNZQIZx1OB6CCdREqHi9puJGiHdhqibYEbEDFY7ziKpIsJaF9NKCbKqd5qkxuQrgXlZVaUxT6R9XpGESKIkTgCEcYTGSDBn85G7esQpdtfeJD72jRqxruP1R8jQnlASOC1wg1BisRxibkhGHgQtAbTmyOCd2tGGI8ZaXYI0R4LXSJRTD4QpdYg/KJCmIaQBxy74pgoPiynlCqX5QGV87gdQXWHjQbQrDki+p0qXZR9tk61IQZxoLDu7To7c2Kw6+G92ZEQjEoXtzYE1NAZ9aOq9Hls/MBiCkPFu9LaK84+RxAqJSHrmWPEyFooCqZhLF4KoorUIfRTOaAs+GK/FlMQCJGJaPibBGjYGR0gIwORhO6g42RUeXfSGjmMBoCT1XBuhaxjSHqA3VULGmWMT93E+1rX/75Dun17cbCweI3muK3D4t79ED6QhlwybJoAptcN+wOTsycq+3dc9/Mda94//FDnzVN60fKinkYI1WIml2MwyKFQFmhZq8mED/KHL+cUCcUjeBTahBT72f8CB4dvYXY8Hcxghg/GiRmivEu5VhNJ4EuIX6qacUUA91EMMXECFsYMwQDsN5jcoc3AVaxEgZoOU1RiRCbIGrJTI2hWCwRRgyqFlWLIULU4gkwVuCWFffDGEZCPUg+IneUG1cqPPQJ9QwpQ+Ti6POuggMHL1hGEU7BeCH2UYBIHKMmd/GOYDEO9R2supDKaY5mA6xPgzCBOtA8RGPqim6mMdfcAR1TCwqK3pOb8MFyr4XIgsfk+bgjymlhQOFZGF8IM0wc4jrhrfUKcA+tcOdFLuWFx6nAGFqyhYxUVjDiEjU2Me0du8+Y+uIXSDuOJBlKOH2fs+u5woEt+A2gA4v53MyahfmDrR17L7TaO3dr74wavIikGO8KdRyDFz+lMFvABCIjFQ3xxfBq0bCxS56NmGrMcvHwoCTQe7AGTFThrNnCIMWNpguOaisll1WUXALLyTkJxQkp5lnlYUZRZMIJbTSoVCoGayIiY8O0CamBRHgsaISNYrBRMbHC4Osz+KgOJuhpmygOUyxMmFpvIosYwRqLsWEWrSk6pwQTDiM7npIoxUEiZmzA5ecZax/7cVjsQJ0ZYb6MlEU0zG7OHSbLMEUXlboczfLiZx24DPWreJfh8kKJIqrjc4PzBudz1BmcC1wtV3j1Ut1TVcnJRlxm8YBEBespRDNqiizNe6Kiqm28YotnmxdTNkr2llA13GK8iZSpzlYsRAsarCsoqsboGEkY8cR0MmQe4cuCSo43BZvMeHIVjRrXyOwNt6wCF5x3w2cCEz2vBiwiqiWOQ71ThAHXbpj5xiwcmL/u9k/NLtz4HRsbZ4jEY0gDgaE6V3eUP05zS4twavzXLZmHxxTG7bcdhjh6iG6cvrrRABPIi77WtCB4hPY7jzFhZlAUW6LIEpkaGlmiKMLGhlotJooikiTCxgm+NoOJEpJaQmwjojgishFxEhNFMU4ijImIkvBzYgO/01qLWFMMdTMYazAShRGZEozVGINaQWwwYDGltRajNUXCKWV17JKNCYeDFDlCUREv1N/K3rrK34u4s4r3FZibdw6HIxcJ8qg+pBhlS6TmoZHCF2QO53LUOfI8w2cOl6XkeY5zOVmWk+eONE3x3pPnOWmW4bMh7e4ZNE1Jc0fuPFnmyb0nz3LyDIZeyL0UH8GPISQ3CU8aJvu5KwDaiNaslCQbnZBYc16xEoSF0HAolxpuWqZHbI9IaJF+iAYxx15u2LV4G3PXvfxoD87M1c3w+cjQn5UBF1XoqKiolSeM1mdJVldXDy4svOz/SWZveA92307vN1RMSFoNcTFwLA1qEabMUfzYCxdE5sCD9QW5pSRUBC+nvixw29EpKyIFFqxFyBbmIuV5OJatVWwkxPWEWq1GHMfU4phGo0Gr3aBZq1Fv1KjFEbVaTJIkxIklii1JHGOjYtypMUTWIDYilXpBfxwHVNVKsmDxCoPco1nQtipF2FQ9UdbB+LTIRwl9z348ME2NG9kXE4X/yuaZOLVkYi5z6Ik1E4ifelfUAsxoW47yu4r0oIjircHFUcgRyzDeRCF8FYuKRU1t5PWNGCSuEcVCLE1MySXW8H4j9ZOyiu0Uca/HO0+eBQPuD1JypwyHGYNBD7I+WTqk1+0xHAwZ9IYMh0MG/SHDwZAsd6TDMc5f9gFHUXE/RkZyROW5Nho8UOgPScEWM1Eoknj1mJJ668dYr0eK6SOmKN5ZPD7ocOUQJ6jXhonmbulSv/FjvtPJaD8/JbbnIgduF8C0A8wadJowF8fDGnDvrhtffWT16Bd3Zv2+ilcJVem4EFHzFU/qK9z4AuhXGX3dhacfqP0l51UKkL+gL2bZ+NiNIoiiGBvXSBpNGs067Zk2rVaNRjOhVotpNWokSQ1ra1hjiAvjDE49LwowDpWM3GUMhn2cz3GFR0kzh7qMRFN8ngdP4x15lhcC7XkgI4ykZEPY6vJ8rC6phfBBicX6sJkMUtAXy6LMZHsjupV5NgXDTjR0yBQiU35t5MhtMTSz+JotNnlZ9ImNLUJ0iMRgo5CLGDGhsFcbh+xihDgK+XwUhXTCmLC2UWyxJsJGBiMF79jEuHgRMTGIwRhLvQbGRNBu4KmH+bw+kD1yDz6HPPcM+inDYUaeDul1enS7ffr9Hr1en34/JR0OGQzTUYSnHuIYIgtWTEj+isW0FXF35xU1oVXEFH+foFZqse/KA9UEccPExqh3GrcXZHbx5s+DfUwk39PrzV9oNl98BizjKnSQnZ0PX+v3240cGO7c+6qH4/nr37zaOU7DWlSKjpri5NeR8qOOVSALWmLZBwqCGEOWF+wnHx6eiMFGliiKqdUS6o0GrVaLRqNJo16j3miQ1BKiJCo8L0RWscbh8yHObeLTNVLvcbnD5TnqQ4XX5TkuywtjKxvmtdIDG3BU8Z6a74eTuozlCmXEqBD2i3RyXIgUBOZSnyuPY5Q4TMnzpaKIorbofRUtOma08vMVD1ySKsp0Y4r6N+68Gc9zDRMLCpp1aCcKaUThek3RsWNEgiB4MS1BJEznC80aRViKh8yPDwoTxOMBtKitxlFhrCI4CQYhRoiikC6Il5BC2BgxMRaDNZYoqRHFNQbxAl4SoshS0xipJeTe0KzX8b6B05gsC1zsPA+vLHdkaUa/3yftDxgM+vQ6HYb9Pmk6ZDhMyQYOa8HYogFDLFZsuNfSeQBmhKuHDiiHYMtOsKKabkyMkRrDbCCN1hw7b7zjE8C5pGUX8z7Lz0Tz6kthwFHxKnZUvw22Pcfc5kc+8hG5885veXBm183fd+b4vbYW26IteAx3hM1nJvnGxX9BQhVy53C5YqKIer1OrdGg2WzTarZCXllLiOMEYwxxHJHEoQgUJzGGHHVdjHhc2mM47OJdH3yK9ym+kG0d46e+QNk1pJWmwnWWgqo5an4oVUYbYx3jChwywldLMahicNpIMUJKnnA40Mrm+fEM5JCjj5rgSgh4arRmKWcrOm5Wqho0MslLMWU4LpUDosDUdOR5pTDoEDr2jRYptyLGY2yo5AVoCxJjC++tiA3F6RKeMQbUmmKWXfBcEgUj8UbAOBLJscW5ZIwdS86SYKRGQww2ahHXmti4jrU1JG5gbB2RiKG2yLzF5Y5ev0+apgz6Q7q9Pq1hik8zcBl5IWmUDgak6YA0HdLv9kI4PugzGPRIswwj5YEWhbEzFSw7uBozkbIEGqUFjTT3TnZe97K0NrfnsQvdtcZ8q6aNBhsvuhC66KRYYTwATaCxTBDp6u/bt0/vvPPO/zZ7zfU/2mgkr5Ue3mjDDOnhTA9NI3B1hGHIhQiFkjT3ODVIHDNba1GPG9g4plZvEtXqqDGhaFSvY+pN4vYs7UaDdqtJqx4TG4+6AaoZebpJ1k0ZDjbIepukrKOuH/p3kUrLYIEtYyfIDaE3tcAzi43NiH5Zahy7Cd6zjAgdIaJATQEtSFFMMeNeV1MarQvnuQjVwSBlkS/0qhrEEDSXRgMzdARuj9PjsVqllmGwkUprXVk7CDmdKfHSslOrJJ0UBbJwYPhxYll8Pil+IPRTlfBZMSfZjr9dVPAuhJm28NpSnEJl3Sw1BltwAEJLX1F0DDeHlQwxGapDvMaoxIhGiIawPI6hFidYm3BNtIiJmyAW72CYOfI0pdsfsL6+Tne9S2+zy6C7SdbtMjdM8eTkLoTc6aBPNgh/poMB5BL0szXHafGZjSFXT2wAG6AzT5NUnUpzl8xd95rHgRMRSowegc5eVe2ISP6iyoFFZLq6Nuqy+OQnfyYCLuy+5dYHTj127WtXV85pLAanjgyPMXVyn5HnHqch/6k1YppJAxMlqBisSYijJnGjTrM9Q2t+gfaORXZes4v2/Dy1Zp04iZHck6c9sn6PtL9K1s9Jh4NANJBiuITkCCnGuIIIYirTE8upADIeM1okn178qAd15DmL1j80lNTQ6oA0MwIrpFLr1KI/9GLE63ICRTm9QKfY7mNFASZ/fmro+EhgjQokVsl/lSmhCbk4/VsredKIHSVFgzymIIvAqEYrAVMwZUFPGR9BGlamFEEuxQukbDgpIBlTKqKUB4CMK8FaAPa+SAMQKfpZc7wO8bmSq2LVIDbB2Br1dg2RNjNxjd02Du7GQzoc0ltZonP+PGurF1hbX6Hb2SAfDtHUkWdpgMtyTzbskqWbIRp0ofCa5WH/1IgwVjFi6aWeHTfcxDU3vOphYKUZNdtQy2Gj/XxQECOex+td73oXfAQf3fmyIwt7Xs2Fg/uJoojI1XF4Mh/wvajWChCJjcHGYBLieoO5hQXmF3cxt3MXC4vXMDO3QNRsQhIwUzy4rEuedvBZRjbo49PhFD/32QvpvXQ996zh5/opjGgrImOlDe/xuKIuGIaLic3BBzguSSKSXTuZn5/husG19LubdDc36XY26axvsLm6Sm9jg8FgQJQYGq5F7kKxctw7rnhXwzohTQ29YSy37H6lmuaNj55cRhdmarUaDGD27IsOB74CE3br72Vhjrn9s7tflfX8H8d+MNQ0TSXzSu4MkU2wcY16vUlzZpbW7Dw7Fnczv3ORerOBqbcw9QaIJbcx3gk6yLBRglPB5x6LYqwhshGZMS9ZyEtXEWEUxiwBSqKookscFcofDu9zBtmALB2Q5xnEllqrgYkM9WaNdGGWXrdL2uuR9vp0NrshtSg1zowlzZXM5URJrCaZlfndr1yF+IGW6Zs4aZQBzPLzQduOnu+FtLYTQ/u+hd23Pq1x+zVLZ05ou5ZIFDWozTWZmZlhrj1Loz1Dc2aGuN7GxDWccfTzISYVYlGipI4tqixWIqyGrEutRVWClq/ql+lmK+cUj3ubXzJAGRmgiGxpLKp627HXlZHOWcjPZeJ9ytzA48N8LiT0EQt4I6gxYTqUd6R5SupSHA4TgU0gVqEpEaafM+in5HmKZopgiIyw0e1r+8abZdcNr3waONNoSJSMe387z6Tf94U2YGm38+Em+Jnm4udmF3e9Zri0j/mZJiaZx8w2qDcDUQLjSPMB6izWKBpBYg3WeqzkRKTY/397Z9MsyXWU4TczT1V/3HtnRtLoG2wTYIRlcAThhTErLfCOCNiINT+ALfvx3+EfsGABwQLC4R0yBA7b4bCELWmkmfvV3VV1TiaLzHOq+s4MjI3H0hC6EVeanunb3beqsk6ezDefF+xmaAv1qVlB/n904X4RvHNK/DSTa7U3XYUrRyn0jSW5iVta72cG89FyimrxuhZ2d0YTiu2gGMA8IqUBZTrgMO1QpoJNWqNkou3JCeTkpX8GYGW9PkSB9yyETrtf93HiZ3wXVVxKOgMuUPiqmIKxQ08ZayGoDZh0hFY+XVMXzHfUo1EtPA7m/sUF/8XXL9f4pKh2s80qVNab08cKaoU5Z4fNDtQKtgKhgo4KOslIOGDcPcRhvAK4ux4wdCc/+9lD4DoBuzeeVfHl2W8Yz0gA9JB038h8aqaMQCkg8nE7smglm/if6zcSFIwMRiZBodS+o1PrQw1ffH3x9ZTFM6DJoEERvFKD12IOOSad2pS3aYxuJpAmsIlPshUFFR91RcnoGDAbADCvUF74/kcfZSCfAPkVzBTK5yeFdq30+SmAcxi/v8KEla0wdgnW77GyU/SFYH0o0kMnWwUrrjrillAFNAvMPKuOqvqgnSKXaC7tOaUoRKfmsUSliuF9GkorAxoLZ8D6GPC5Q1s4kdtSV0xtNG6eXSmRNlQ1R3f8GDh6XOrUy0Kud5Rv3EgJ69hcqzMEgrq1h6K32gibCZj4WIZPjKP9JS8eU2jK63MErqyqLR1aaK2ZnO7JlENHHXppnVNbYgWkRF84Bh7N1V7CVVnWuWY6ZiuY/SZO2kN0hUwxdcXkk0KcYT4SBlf26dzmupGgUQUeLDgMtc+sbX54NuGjOrhpS4IIz1Ny7el+jJAVo0tw7YSZAPkhsP3JN7/59uvA5hK4+hFmC9Hnq4i13+u02WCE4Vosg5UwEsFkwtoYXJFAdMM+YeFzzu0k2LGu95H06Di9dhwMQYmhxk0UgcC1LgNjDpYjY4HF8ITOn4gWIHpQex01Wrymze93I/lv7QetkHF9NMDrT5mhL35ZtQDW46cdsbera2H9cQBSQiBxo0pLZEfyR2pSSjsabDJykZH3cuuq5BM9VahBTAva0BLbx7EV0hmmDzhNhJwdRjCwZP9ZrnJwhbGCmaGU48bgpIv2gRfBRcvG9XHG3AL6cdYHbRCLHpNr33DW9OtjqRXUFsyFHIO7IgZQPrl3D/f/9m+Hb5ycbH4BnP4C88zA8xXAeIxcgBb/ffbvzijUIVOHzAmZE8xyY0LPjEiXOS6FDxq3dJ9b1SOv4+VpjDGARp2ov2VzzY2555tEQ1eBAVJiVqhiahY3oDZkvpgmsiOtFjAxobA9NsANbr7DN2glUbOdQ6AGJt88aXP2QzaXliSyDA5tdgEdaa6NF0osckaUGoHrCGiI90L1DaWhDVZ4YEVGRuT6ZDV0JQAKwoAmkHYAd4D1wNG01WeepvM774C7LsXFcCXAqT2XK/Dnom4RiJZmx1JBPLSQBNYUeLFUEpapdEHjb4fPUxW3zzPOOgfWgtxoREdm30RLb+9IVw1PpEYMHaGQk0mIA1+7VDYaHUPHaWbFEICRgUmWF5gdtV8EBqG6PVms0CHBTKZYxShg86Uz1znXDGPWtM2j9J5qVxVWBH9kUYCP6nHkFlR6ALH3JFc1EQRSVhDuXemEHNihmvvgCUfs8/Z1as/qQ6bf9P2pMZMXPbqnqGYv2gNOVGR+coth+XyGobMphhZ8cIEsL/aLnkNZmSeGOLTKFNA3bjx6T3NzKdHGcv9dszqLvFCAxTypz6CmKIKEQ0GQKShaYgonQVjDuRxjcCQ7PatyrRiANC8pQ28EuWG7uqRtZgFKQpsuOu6fCoRcDLPc91I8ZgFAgkmsDTgQk+NNqscQFOJTsjFna40VVtNyEQWTtpnpxFV2GSk49WAVEMeAhBFYnWMmZijIyFbQocTe1/E9RApwhrWZGsQ5oyM+98zEXmYxwJOJ7bTwkX4MLxt21Pajz+ge8ptfgRdD7097T2oHEou9IPl+iPRxB3lhwKw+bczhV0RqEBL3sDFucHYyXqSdsYowt3ahg7o1zMl59v6FOeVDrRErmGV+fp1jPgqwhTUIoogVI4LEi15wFG6gUSuI6g/H5+I4LpkIAy3WPquD637DYyJ0Cz+ppbGXmae7vvf34+akH15A8xVFzUE+4kFKbcyTIJYxTINjhYSCLuKrNzOD2SBTBok4foiASZ18IhVHxFOMNPoNsxNfa4vUaaYzZHK9PBRIRuFZXMBlglkHIoWyerXIbko2qQ2THFcmFsWu/7kge+Tt9HlpYz53KbSauQEYSqxu1TF+Xv2IY6/EhCIC5Q4ZK0xYY4LTFBWEbL63LPVuSvPsnTO3ohAlAsjsGEFgCPvgOYhgnEDMcbEyUqBwWMQlfDL/OxGj67pG9SBmpK5ffGZGSin+LVaQPgHCQZYARBJYpK0wuROURPH6lUDhfwYzRA08LbC0eoP/HOicmVdd2hy0mYGLgkdtx1oDnaNaUIJpw1Hhd8pGgZYMNYcaNHYW+fw0UNlbJYANCksjiDw7IlKMAQvouEfmNQi3QLQF0QZMa5CcQtIaKa0gqQd3KyBmiYkTEL8/MTuGqKVRvvVhvuE0AXsuFQXPPIA37TYlT3V8HvWksUWaQs6USr2fLBKwJaRDRiGnF05lQJkqkLxgKoZBO0y8Ru7OoCqBF01I3AHUIZH4KkAeeCLOsGLyVNFSD2JxhlXQKIQTRJxbpYFprQHkf88zrSLltvkl+Oq2zCyEBEsLPGrbA1+lO6npflAjI3jrBdmpoJu4VbA4MUgkjpsGNC5uQM0aNRCriAF78zaPhM8P904PQ7SNWDnA8yUM0qi9tleHO+dk2YJ42UzSCJYl7FFyAPNK0yKrKqZs4YA4+TcUmgvGAkzGKMMBGCo0oEB4hyQFIqOfrzWB+4SUNkjdGtL76GlKBO5WkLDs4ZTAaeXl9eL+RVYyUCaUGZq18C22X2WhtXfegY7jUfH7OS1ibVYTgBch13+qJkGiZJCuIeopUCGXZYAMXZd8KL/vkFYJvSRs6hzsdEDOAzQX7Hd77A47HHbXmA7X2F9fYNjvMI17lHHwKqcWFDVk8juu8BbcbSCxurEkvwm0ACYwGURkrsQygZPCNEOzkxptMExqGKoLH0bXYkf511E41UnBK2iKMP4qswmYs68s2swLbyM9douQ7Kl/c2ZoNEd/nSjYLryR4iqqfkKMWMGXvVm0x2DvcdYVn3ke6K+rmAlHW2kmXraUGQKwxM/430taPp/jhihtlrZmB34TSVBsAMjcg6YOpCmYe3Ptw32XpgDo7ZuZWiafkdZA7oASiJOvztKhF8YqdejXG3T9Gv1mi77v0aeEPqVAWyo6JQiJXxvMTk81p5miTDAaUXhEwQSlCYUKkOblKQsAdKcfAdtXev4UwBXw4AVguzGzXzuV45kGsFMr718BWwLKS6zJ907FYLkHkkAkAZzQi6+EOmXshitcPLjAOE4YhwnDbofr3TWGccA0TshljBPoYLYuOeGxE0HXJ6z7Hil16Dcn4OSmyykldEl8bxa91+raRFbbLMHpanaZvlqU/c5XiuI3Bc0ZVibkPEJLBuHaKYwlRsyKtlSN1AISUD2N2N9fyX2GA2C/9CSqpt3VgIuMw3N3LlU3JwnoDJs8cmO0xnZ26iW1wIXH7EznYGoDv1yFHVFtdkxumIK3G0DbUraqtVY4ehA8SlSgmbkRG5kcAkicPOUNTK6nvRuAExInkHRIqQfY8TYggXSrhtGtzBQ0kQ8jm6fzuVgzSctFMU5OyByuBuzGAVOeHJxXzewChZRSj5R6CAOrvkOX/Lil5AVENYJghUSGQooCxzKZCogKUkU9oQAl32EBXV6Ww9kZroH1HYD653QPPGQAA7T7WWeCXglrWWFKa0yFUHYTDpefYBhGHIYR42HCYfITkUSQVj2o67Bar3B6eoLTF25js1ljs15htVpjvenQJUHfd14QIYIIN5MPLzKV2PupB6UWlDJB84SibrBtRZFzbfsYFIFGLdnB70b1emlWmbCArFMXDOPKvLbGwCE1EKVQTwU+SNVhAdX1nmnheI85na7iiNoysoVSjKhpXupge/1YGlTLwCq3CjpVHGMIF7hhbzj6ttZG7sAUj3nxf1rI1WmG4lF1LjAvLAbml8ggoZpTaNQFEox8HpfE96ocfOyK+iIocpkgBJA4DM+xR87MSkJtqyHSQ+qeV6Rtf0ACavhd7yPDPHDVDFNWjOOI/WHA4TDgcDhgOAzY73e42u8wnu8xDmPb40sh9JSQmCG0gXCPnlcgvkLJQ6j6dr49QNk+AMavntEGQA9sPsWv6LzwmQfw+fnJ6vZtJL9J+91s2A/46OI+8uGAnEeg67HZbHF2+w5efO0FnJ3dwp07L2Bzdob1ZoPVyQarKPwQhzO91oJJhtqEkkswi31f5VVhC1JDXnCLJ7cFaQHtRRkvWOXWoiBS3x+FqbUhe73ZSlibZBCV6A8vELKEm9aHKDc8jkBLSLi1CujSUaDagN5UxBz1igmLivax8TUteNpL3C0W8omnaQYQjvvHx59k8akbjLkcVzRsITzGXDDiG32XCuVx65hKuAxflVpUhAQ2VuEWXARVp60wrWCF3AGC1Fd5co4aMwNBx+wkRdYXzK3OiZmOOQKsFExTxlQKhsOI/fUelxcXuHq4w/7ygOvLc1w/vI/L63OwdjA7gXRbl5vqGAB64HXgDg5pgzWu4JNI5fMItfvf3yCl9QVweovtVmHRj893YOvAL38Fv/fW7+Ll11/D6Uuv4cUXXsR2uwFSVzdwoXxQoChKKcilwHIUPqzahQVFUnOsWhEs7BhXaheQNp11IzTWvi2pOwBI7E8xweArLy8qELVtxCFrIvX3qXvYWnRqvacn9yRasC3jgVpAzk0ONQvTjoULAI6tPhEqqNZDpplKuYyTZfto7nXOPdH5XelI+203nn+zhWKPtPxuSDuJjuxI8Zjne48Yzdam9pfZXLfuVXnvHYMdrEeks/eT+QoPBoSrbDaKalpgkdpzKZgMvjqH5w5R9iAGgVjQbU+wloQzc3cMJN/moQAYB+x2V3h4/imu7n+ID3/+AX7xwfu4fvAA12UD624plCGCHutpC6wRUr3nTwttZjQMl7cTQMrr8ukh8Zt/+O3yR9/5jr78xpeJ+xzXTPK2gxZojrQlTgpFkWZ5F68mVL6n9AuWhGP1dXsUN+VydnRTKwXHl2iJLm+hciSEWEqjKqSOiGCPW6GWwgg8OtNLNyJJ1Z7m2D3GV/dY5/3I8xeLPxH9crPFlUO1vJuYRWvtCZ8vAr19skbctEdmcuvjeizq7zcnLNTqERQ2J+2jLFVqNW+fhQEhDCpQ9VReVdv+ndrgQng+xXaDxIOVIKHjJljstycFssZQjXobrdAAEND1HdabO3jjlbvAW3+A35dk09UlPvngE/uXf/x7O5+2gu7WBxu/lZzAGXE9fkX70M98BV6tzob9tH9z3539w9f/5M//4q2vvfpVbNfYX18iHT7STopqIpixm8KJ+YShZT9xsZeszjbaUl4NgkUooIq2fjBV/mp15Wt+wLSwvKwgtaVtaP3ixySsC0/apnyICVEr+OLr/3q3J1ReeJsIsvrnOE/GzvGt7TAmQNmnuCINN1O3OKkDFPNECkqMpZC5oNbrExqETPH7ArckxGplHolBVmAGKwRjiOVJQNwR55WYbPDa196mv3z7W/jBf/zw3/Z7/Ktsxpf6eTxuAyCZGT1XVWi/2vdqSGNB9+O3vv3u3+TLn/711YOHb+4M3zqz/SrJnjFOkDoEoAotGalK9gCABaZmzFYAhqoQyFDUiEh9LkHr3ldhWsgp/hOZJiKrLZsc1eQJqhng8PIhD1o/kXG+G36x+FaMAGNv+zB7IYsD/u2FGDpa5W1h30GLQcPZHYWO9qSP3XnScqCgYmKecJgf8bIm3GC5H9EqloWoNrpEx4SLlnK3qjPdSMmXzzlWeHGTUYbt6hEeZ8mq8iqyw9RTSDs9dSUSt3BhBrgzYm/vIFpSRNUILnylwupGuIuMyQtlzAlEnRGJCbsIBrHvjbZWiC/FWwPMwsJkIBQryGUCiiEhUZc20EkArJHzGud70351chhH+f7pm2/cefuPv/JPFwNWG1CK4E3A8LL3NVcf/br7wc9UwRneSXcAjDvg9u7+/bO7d+/ufWN79dVx9/M/K8OD1/YPP7Xzi4frYRiNOX2DWb50fX2Ow+EAsWmduKyZFafbNcwmlDyg5AlTHtHLhG0MfTBbpFt+0KdpgpUChi5c+UoEcgk1kIIoR2W4+t9aUxtZMZDCtGQU85lilCiI+WuYjhOpTjBvxFJLw6MvS5R8mMfshvH17IqHRd8XtjTJdvA7HUHho8drNqewai01b9B5Lb5l4OOAqxXceo+qFVwsxjX94rbmtkccQwmtDTXfCECzd24EvM2vxQGD97RcJBnYQQwenEKgBJE1cQSoS1G9ol0fM1P0711sUyWqHsiEHPtU/724rebVhpa7M5Cs4rTM1rAiCcSCQVcYbY2u77E/jCgFGSmpcKeSkm02Z9rL+qM87r+X+tPdrVt3y/rkzofdrbvfW21Pd8DJj3O+/9s26dhtXnnPV90dA9uPgd1dYDsR0cfPYIX8PHwJmoe9O3ydPdjj9qefXKw6fvjqCsOXGdOXy3D5O/vry5TzdGscrk8O03RruPz04cXH7//XNI7YHXZapgGUuu16vXl1sz77EpG9pPkqhRueFJ3YZYDKU8kMnZBsciFGLqRmyHlShZFmA0hlJSSGmrK7OATNhNuAKdpUhGbNYrVCrgaGW2Nq7NHrxV+VS8IS24Ua8LWYFSs+Je9/mjWhvpq/HoiQFkMWRICECquU0la6Wu1+VF8ekz+SnlhwA0WxblHV5igUUbTdED3faohtZiEM4egVl5CaeotHUt8M2s0Yk/oWhcMcTURcfhpCklwwmtFUZarExCJCSZJKYrO0YeOkKUkRFk2pN+EO/ao3kc6ux/yT/UE/7pIYczLhNK1Wfd6sN9Oq7w6nL7/5+ubWiy/1q81D7tb/Xiz9KKXtw563H9J2e77tugsA7xPRBXEHLeOGiPafdeT8xgLYzB7zXvcI+Dq99x7k6z9AuffeX9l3vwsz+zsG3t0CuAXgPKL7FDOacxWPXwFwWDwnNIkYAGzjW+fNK7rYj3SL5/bIeQMUzqUwCqTkQUHEBSDSYVNod5cUvWoWEFYKmBB6g94iwxkbfgtmK4KewNDDlM20h1n9XgOUAEum1gHYm/vJdGZIQu7gbYuB/iPT8sgUlrJSVR+WcO2z3zhqQBM5pbNoCXd5jumhWp+aTbw8gN2z2BZSThFeFMTYdQgLqTgzFz+nbqREQplAxYBMTBlmTCxTzFpkZUwwOoB5APGFmb6vkHMzujDCnkx2IMrMrACHQ2pQq4yn0m1/ytIfiKhLaS3puEDRw4flH2J2yeRIYcf4zvHYANyOn9sv+rMn3v3BLv7tMq6rKX4mv/fee/lVkdV467q88Z+XIz7+2PDuu4p79wj37tnjhEzPOq7+G2Hl1D+EFfZAAAAAAElFTkSuQmCC";
export function CrownIcon({ size = "1em", style }) {
  return (
    <img src={CROWN_IMG} alt="" style={{ width: size, height: size, objectFit: "contain", display: "inline-block", verticalAlign: "middle", ...style }} />
  );
}

function StarIcon({ size = "1em", style }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={style}>
      <path d="M12,3.5 L14.2,9.7 L20.8,9.9 L15.6,13.9 L17.4,20.3 L12,16.6 L6.6,20.3 L8.4,13.9 L3.2,9.9 L9.8,9.7 Z" fill="#E8B94A" />
    </svg>
  );
}

// Which small icon accompanies a given title string. King gets the same
// crown as Crown Math Wiz, just rendered bigger by the caller — a
// standalone "huge fancy crown" for King is still to come later.
export function tierIconForTitle(title) {
  if (!title) return null;
  if (title.includes("Math Wiz King")) return "king";
  if (title.includes("Royal")) return "diamond";
  if (title.includes("Crown")) return "crown";
  return "star";
}

// Title text with its tier icon and a gold glow, for every place a title
// is actually displayed as an achievement (current title, milestone
// buttons) — not used in the static Levels reference list.
export function TitleWithIcon({ title, style, starIconSize, flankStar, textNode }) {
  if (!title) return null;
  const tier = tierIconForTitle(title);
  const iconSize = tier === "king" ? "1.7em" : tier === "diamond" ? "0.99em" : (starIconSize || "1.36em");
  const icon =
    tier === "diamond" ? (
      <DiamondIcon size={iconSize} />
    ) : tier === "crown" || tier === "king" ? (
      <CrownIcon size={iconSize} />
    ) : (
      <StarIcon size={iconSize} />
    );
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, textShadow: "0 0 6px rgba(232,185,74,0.85)", ...style }}>
      {icon}
      {textNode || title.toUpperCase()}
      {flankStar && (tier === "star" || tier === "crown" || tier === "king") && icon}
    </span>
  );
}

// The milestone button — same look wherever it appears (real ladder,
// Levels page) so the two never drift apart. Bare title, no number, for
// every tier except Senior Math Wiz 12, which is passed in pre-numbered
// by the caller (this component doesn't know about that exception).
export function MilestoneButton({ title, minWidth = 92, maxWidth, allowShrink = false, style }) {
  // Junior/Crown Math Wiz specifically wrap after the first word (not
  // wherever the browser would naturally break) — a literal newline +
  // pre-line respects that exact split; other titles are untouched.
  const wrapped = title === "Junior Math Wiz" ? "Junior\nMath Wiz" : title === "Crown Math Wiz" ? "Crown\nMath Wiz" : title;
  // Senior Math Wiz 12: on phone, let it wrap fully below the badge
  // (unchanged). On wider screens, force the break after "Senior"
  // instead, via two CSS-media-toggled variants — no JS width check.
  const seniorTextNode = title === "Senior Math Wiz 12" ? (
    <>
      <span className="tt-senior-narrow">SENIOR MATH WIZ 12</span>
      <span className="tt-senior-wide">SENIOR{"\n"}MATH WIZ 12</span>
    </>
  ) : null;
  return (
    <button disabled style={{ ...s.segBtn, minWidth, maxWidth, flexGrow: 0, flexShrink: allowShrink ? undefined : 0, color: "#46AB68", borderColor: "rgba(70,171,104,0.6)", borderWidth: 2, cursor: "default", ...style }}>
      <TitleWithIcon title={wrapped} textNode={seniorTextNode} starIconSize="1.36em" flankStar style={{ justifyContent: "center", whiteSpace: "pre-line", textAlign: "center" }} />
    </button>
  );
}

export function UserBar({ activeUser, users, open, setOpen, newUserName, setNewUserName, onSwitch, onCreate, onDelete, currentTitle }) {
  const atLimit = users.length >= MAX_USERS;
  // Name and title used to share one wrapping row with the Switch user
  // button always on it — name+title together often didn't fit one
  // line on narrow screens. Now: name gets its own line, title (if any)
  // gets its own line below it, and the button attaches to whichever
  // line is shorter — a character-count approximation of true rendered
  // width. Title's bonus went from +3 to +6 once the title started
  // flanking with an icon on BOTH sides (below) instead of just one.
  const nameLen = activeUser.length;
  const titleLen = currentTitle ? currentTitle.length + 6 : Infinity;
  const buttonOnNameLine = !currentTitle || nameLen <= titleLen;
  const toggleBtn = (
    <button style={s.userBarToggle} onClick={() => setOpen(!open)}>
      {open ? "CLOSE" : (
        <>
          <span>Switch</span>
          <span>User</span>
        </>
      )}
    </button>
  );
  return (
    <div style={s.userBarWrap}>
      <div style={s.userBarContainer}>
        <div style={s.userBarTopRow}>
          <span style={s.userBarName}>{activeUser}</span>
          {buttonOnNameLine && toggleBtn}
        </div>
        {currentTitle && (
          <div style={{ ...s.userBarTopRow, paddingTop: 0 }}>
            <TitleWithIcon title={currentTitle} flankStar style={{ color: "#EDEAE0", fontSize: 13, fontWeight: 700, letterSpacing: 0.5, whiteSpace: "nowrap" }} />
            {!buttonOnNameLine && toggleBtn}
          </div>
        )}
        {open && (
          <div style={s.userPanelInner}>
            {users.map((u) => (
              <div key={u} style={s.userRow}>
                <button style={{ ...s.userRowName, ...(u === activeUser ? s.userRowNameActive : {}) }} onClick={() => onSwitch(u)}>{u}</button>
                <button style={s.userDeleteBtn} onClick={() => onDelete(u)} aria-label={`Delete ${u}`}>Delete</button>
              </div>
            ))}
            <div style={s.userAddRow}>
              <input
                style={s.userAddInput}
                placeholder={atLimit ? "User limit reached" : "New user name"}
                value={newUserName}
                disabled={atLimit}
                onChange={(e) => setNewUserName(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !atLimit) onCreate(); }}
              />
              <button
                style={{ ...s.userAddBtn, ...(atLimit ? s.userAddBtnDisabled : {}) }}
                onClick={() => !atLimit && onCreate()}
                disabled={atLimit}
              >
                Add
              </button>
            </div>
            {atLimit && <div style={s.userLimitNote}>Up to {MAX_USERS} users are supported. Delete one to add another.</div>}
          </div>
        )}
      </div>
    </div>
  );
}
