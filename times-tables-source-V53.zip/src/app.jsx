import { useState, useEffect, useRef, useCallback } from "react";
import { s, globalCss } from "./styles.js";
import { PasscodeGate, ConfirmModal, YesNoModal, Toast, NameGate, UserBar, MAX_USERS, IntroScreen } from "./components.jsx";
import { QuizzesPanel, LadderPanel, ChallengesPanel, GuideScreen } from "./setup.jsx";
import { QuizScreen, ResultsScreen, HistoryScreen } from "./quiz.jsx";
import {
  DEFAULT_QUIZ_SETTINGS, DEFAULT_LADDER_SETTINGS, DEFAULT_CHALLENGE_SETTINGS, DEFAULT_GLOBAL_SETTINGS,
  DEFAULT_LADDER, normalizeLadder, TEACHER_PASSCODE, isDevUser,
  loadUsers, saveUsers, loadState, saveState, loadLog, saveLog, loadMastery, saveMastery, deleteUserData,
  buildQuizQueue, buildLadderQueue, makeChoices, poolSignature, isCustomLength,
  ladderStepNumbers, ladderModeOrder, ladderDisplayNumbers, isDefaultRange, autoExcludeEasy,
  isCanonicalEnd, passEndFor, titleForNumber, rangeNumbers,
  challengeRunPool, challengeMasteredEnd, chainHighestReached, shuffle,
  isUpgradeTest, allowedMisses, factNumbers,
  readIntroCount, writeIntroCount, currentTitleFor,
  extraTimeMs, yellowAboveTwelve, isYellowAboveAttempt,
} from "./logic.js";
// Challenge questions always run shuffled, one pass, no repeats — matching
// how a "test" (as opposed to practice) should feel.
function buildChallengeQueue(pool) {
  return shuffle(pool).map((f, i) => ({ ...f, id: `${i}-${f.key}`, isRepeat: false }));
}

// Bumped manually with each build shipped — shown only in the BD#
// dev-preview toggle, next to "Default Settings", so it's possible to
// confirm at a glance whether a given loaded copy of the app is
// actually the latest build rather than a stale cached one.
const APP_VERSION = "v53";

// Make sure a user's ladder has a valid current (track) number for their
// Ladder Range/SKIP settings: inside the step range and not already passed
// (green or yellow). A user with no saved ladder progress starts with
// currentNumber: null. v40 fix: this used to run ONLY when Range/SKIP
// changed or on first load, so switching to (or creating) a user whose
// ladder had never been saved left currentNumber null — which hid the
// TYPE OF QUESTIONS and SPEED sections and the ▲ marker, and showed
// Quiz Length "ALL: 0". Now it's applied every time a user's ladder is
// loaded, and the settings-change effect below uses the same rule.
// v42: used when the same user changes Ladder Range/SKIP — always go to
// the first unpassed number inside the new range (falls back to the
// validity rule if every number in range is already passed).
function withFirstUnpassed(ladder, ladderSettings) {
  const stepNumbers = ladderStepNumbers(ladderSettings);
  const passedEither = [...(ladder.mastered || []), ...(ladder.tempMastered || [])];
  const first = stepNumbers.find((n) => !passedEither.includes(n));
  if (first == null) return withValidTrack(ladder, ladderSettings);
  if (first === ladder.currentNumber) return ladder;
  return { ...ladder, currentNumber: first };
}

function withValidTrack(ladder, ladderSettings) {
  const stepNumbers = ladderStepNumbers(ladderSettings);
  if (stepNumbers.length === 0) return ladder;
  const passedEither = [...(ladder.mastered || []), ...(ladder.tempMastered || [])];
  const inRange = ladder.currentNumber != null && stepNumbers.includes(ladder.currentNumber);
  const alreadyPassed = ladder.currentNumber != null && passedEither.includes(ladder.currentNumber);
  if (inRange && !alreadyPassed) return ladder;
  const nextCurrent = stepNumbers.find((n) => !passedEither.includes(n)) ?? stepNumbers[0];
  if (nextCurrent === ladder.currentNumber) return ladder;
  return { ...ladder, currentNumber: nextCurrent };
}

// A settings object loaded from a user's existing save predates the
// Exclude Easy Auto/Off/On control — treat it as "manual" so their prior
// explicit value is respected rather than silently auto-following the
// range from now on. Brand-new users get the module default, which is
// already "auto".
function normalizeSettings(loadedSettings, defaults) {
  if (!loadedSettings) return defaults;
  const merged = { excludeEasyMode: "manual", ...loadedSettings };
  // Pre-SPEED-section saves used a boolean testMode (ladder only). Fold it
  // into the new speedMode so old saved settings still behave correctly.
  if (merged.speedMode === undefined) merged.speedMode = merged.testMode ? "test" : "normal";
  delete merged.testMode;
  return merged;
}

// v44: the "Work on" hint for a failed pass attempt. Ladder Test ALL is one
// number, so it lists the missed facts themselves; Challenge Tests list the
// numbers the misses came from (both numbers of each missed fact, except
// the trivial 1s), smallest first.
function workOnList(kind, missedFacts) {
  if (kind === "challenge") {
    const nums = new Set();
    missedFacts.forEach((f) => factNumbers(f).forEach((n) => { if (n !== 1) nums.add(n); }));
    if (nums.size === 0) missedFacts.forEach((f) => factNumbers(f).forEach((n) => nums.add(n)));
    return [...nums].sort((a, b) => a - b).map((n) => `${n}s`);
  }
  return [...new Set(missedFacts.map((f) => `${f.a} ${f.op} ${f.b}`))];
}

export default function App() {
  const [ready, setReady] = useState(false);
  const [screen, setScreen] = useState("setup");
  const [activeTab, setActiveTab] = useState("gradient");

  const [quizSettings, setQuizSettings] = useState(DEFAULT_QUIZ_SETTINGS);
  const [ladderSettings, setLadderSettingsRaw] = useState(DEFAULT_LADDER_SETTINGS);
  const [challengeSettings, setChallengeSettingsRaw] = useState(DEFAULT_CHALLENGE_SETTINGS);
  const [globalSettings, setGlobalSettings] = useState(DEFAULT_GLOBAL_SETTINGS);
  const [quizCustomStart, setQuizCustomStart] = useState(() => !isDefaultRange(DEFAULT_QUIZ_SETTINGS.start, DEFAULT_QUIZ_SETTINGS.end));
  const [quizCustomLength, setQuizCustomLength] = useState(() => isCustomLength(DEFAULT_QUIZ_SETTINGS.length));
  const [ladderCustomStart, setLadderCustomStart] = useState(() => !isDefaultRange(DEFAULT_LADDER_SETTINGS.start, DEFAULT_LADDER_SETTINGS.end, false));
  const [ladderCustomLength, setLadderCustomLength] = useState(() => isCustomLength(DEFAULT_LADDER_SETTINGS.length));

  const [devPreview, setDevPreview] = useState(false);

  const [queue, setQueue] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [answeredCount, setAnsweredCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [current, setCurrent] = useState(null);
  const [choices, setChoices] = useState([]);
  const [inputVal, setInputVal] = useState("");
  const [feedback, setFeedback] = useState(null);
  const [correctAnswerShown, setCorrectAnswerShown] = useState(null);
  const [willRepeat, setWillRepeat] = useState(false);
  const [missedFacts, setMissedFacts] = useState([]);
  const [seqProgress, setSeqProgress] = useState({ signature: null, cursor: 0 });

  const [users, setUsers] = useState([]);
  const [activeUser, setActiveUser] = useState(null);
  const [log, setLog] = useState([]);
  const [ladder, setLadderRaw] = useState(DEFAULT_LADDER);
  const [runMode, setRunMode] = useState({ kind: "normal" });
  const [ladderResult, setLadderResult] = useState(null);
  // v51: the number the Ladder shows when returning from a Ladder quiz that
  // didn't pass (null = the ▲). Cleared when leaving the Ladder tab.
  const [ladderReturnNumber, setLadderReturnNumber] = useState(null);
  useEffect(() => { if (activeTab !== "gradient") setLadderReturnNumber(null); }, [activeTab]);
  useEffect(() => { setLadderReturnNumber(null); }, [activeUser]);
  const [ladderMode, setLadderMode] = useState("mc-seq");

  const [userPanelOpen, setUserPanelOpen] = useState(false);
  const [newUserName, setNewUserName] = useState("");
  const [nameGateValue, setNameGateValue] = useState("");
  const [deleteTarget, setDeleteTarget] = useState(null);
  // v44: the old "Make the range bigger?" pop-up at Start is gone — the
  // yellow-badge warning now happens in the Range section (RangeSection).
  const [failInfo, setFailInfo] = useState(null); // fail pop-up: { workOn: string[] }
  // v45: intro screens — { showing: 1, 2, 3, 4+ } while shown, else null.
  const [intro, setIntro] = useState(null);
  const startIntroFor = (user) => {
    if (!user) return;
    const showing = readIntroCount(user) + 1;
    writeIntroCount(user, showing);
    setIntro({ showing });
  };
  const [upgradeInfo, setUpgradeInfo] = useState(null); // instant-upgrade message
  const firstTryMissesRef = useRef(0);
  const missedFactObjsRef = useRef([]);
  const failShownRef = useRef(false);
  const [toast, setToast] = useState(null);
  const [pauseRequested, setPauseRequested] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  const inputRef = useRef(null);
  const startTimeRef = useRef(Date.now());
  const activeUserRef = useRef(null);
  const usersRef = useRef([]);
  const correctFirstTryRef = useRef(0);
  const totalAtStartRef = useRef(0);
  const answerTimesRef = useRef([]); // excludes repeats — feeds the avg-time stat
  // v51: extra time (ms) each first-try answer was allowed (Fast/Fastest
  // Type In, 2/3-digit answers), same order as answerTimesRef.
  const answerExtrasRef = useRef([]);
  const totalTimesRef = useRef([]); // includes repeats — feeds the total-time stat
  const pauseFlagRef = useRef(false);
  const pausedQueueRef = useRef(null);
  // v48: the In Order place a quiz will move to, applied only when the quiz
  // FINISHES (not at start). A quiz quit with ✕ or lost when the app closes
  // leaves the place unchanged, so its unanswered questions aren't skipped.
  // { kind: "quiz", signature, cursor } | { kind: "ladder", cursorKey, cursor } | null
  const pendingSeqRef = useRef(null);

  useEffect(() => { activeUserRef.current = activeUser; }, [activeUser]);
  useEffect(() => { usersRef.current = users; }, [users]);
  useEffect(() => { startTimeRef.current = Date.now(); }, [current]);
  useEffect(() => { pauseFlagRef.current = pauseRequested; }, [pauseRequested]);
  // The dev preview toggle is session-only and user-specific — never let it
  // silently persist across a user switch.
  useEffect(() => { setDevPreview(false); }, [activeUser]);

  const effectiveAnswerMode = (runMode.kind === "ladder" || runMode.kind === "challenge") ? runMode.answerMode : quizSettings.answerMode;

  useEffect(() => {
    if (screen === "quiz" && effectiveAnswerMode === "type" && inputRef.current) inputRef.current.focus();
  }, [current, screen, effectiveAnswerMode]);

  const setLadder = useCallback((updater) => {
    setLadderRaw((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      if (next === prev) return prev;
      const user = activeUserRef.current;
      if (user) saveMastery(user, next);
      return next;
    });
  }, []);

  const applyLoadedRunState = useCallback((loaded) => {
    setRunMode({ kind: "normal" });
    setLadderResult(null);
    const qs = normalizeSettings(loaded && loaded.quizSettings, DEFAULT_QUIZ_SETTINGS);
    const ls = normalizeSettings(loaded && loaded.ladderSettings, DEFAULT_LADDER_SETTINGS);
    const cs = normalizeSettings(loaded && loaded.challengeSettings, DEFAULT_CHALLENGE_SETTINGS);
    const gs = (loaded && loaded.globalSettings) || DEFAULT_GLOBAL_SETTINGS;
    setQuizSettings(qs);
    setLadderSettingsRaw(ls);
    setChallengeSettingsRaw(cs);
    setGlobalSettings(gs);
    setQuizCustomStart(!isDefaultRange(qs.start, qs.end));
    setQuizCustomLength(isCustomLength(qs.length));
    setLadderCustomStart(!isDefaultRange(ls.start, ls.end, false));
    setLadderCustomLength(isCustomLength(ls.length));
    if (loaded && loaded.seqProgress) setSeqProgress(loaded.seqProgress);
    else setSeqProgress({ signature: null, cursor: 0 });

    if (loaded && loaded.screen === "quiz" && loaded.queue && loaded.queue.length > 0) {
      setQueue(loaded.queue);
      setTotalCount(loaded.totalCount);
      setAnsweredCount(loaded.answeredCount);
      setWrongCount(loaded.wrongCount);
      setMissedFacts(loaded.missedFacts || []);
      // v48: restore the run stats (see persist). A quiz saved before v48
      // has none; it starts these from zero.
      const rs = loaded.runStats || {};
      correctFirstTryRef.current = rs.correctFirstTry || 0;
      totalAtStartRef.current = rs.totalAtStart || loaded.totalCount || 0;
      answerTimesRef.current = rs.answerTimes || [];
      answerExtrasRef.current = rs.answerExtras || [];
      totalTimesRef.current = rs.totalTimes || [];
      pendingSeqRef.current = rs.pendingSeq || null;
      firstTryMissesRef.current = 0;
      missedFactObjsRef.current = [];
      failShownRef.current = false;
      setCurrent(loaded.queue[0]);
      if (qs.answerMode === "mc") setChoices(makeChoices(loaded.queue[0]));
      // v50: only Quizzes-tab quizzes are saved for resume (see persist),
      // so open that tab — "Back to Quizzes" then returns there, not to
      // the Ladder (the app's default tab on open).
      setActiveTab("quizzes");
      setScreen("quiz");
    } else {
      setQueue([]);
      setCurrent(null);
      setScreen("setup");
    }
  }, []);

  // ---------- initial load ----------
  useEffect(() => {
    (async () => {
      const { names, lastUser } = await loadUsers();
      if (!names || names.length === 0) {
        setScreen("namegate");
        setReady(true);
        return;
      }
      const user = lastUser && names.includes(lastUser) ? lastUser : names[0];
      usersRef.current = names;
      setUsers(names);
      setActiveUser(user);
      const [runState, userLog, mastery] = await Promise.all([loadState(user), loadLog(user), loadMastery(user)]);
      applyLoadedRunState(runState);
      setLog(userLog || []);
      setLadderRaw(withValidTrack(normalizeLadder(mastery), normalizeSettings(runState && runState.ladderSettings, DEFAULT_LADDER_SETTINGS)));
      setReady(true);
      startIntroFor(user); // v45: once each time the app is opened
    })();
  }, [applyLoadedRunState]);

  // ---------- persist run state ----------
  useEffect(() => {
    if (!ready || !activeUser) return;
    const base = { quizSettings, ladderSettings, challengeSettings, globalSettings, seqProgress };
    if (screen === "quiz" && runMode.kind !== "ladder" && runMode.kind !== "challenge") {
      // v48: also save the first-try counts, timing, missed facts and the
      // pending In Order place, so a resumed quiz finishes with correct
      // results, History row and place.
      // v49 (audit item 10): read the stats live. The queue drops the
      // answered question the moment it is answered, and the refs are
      // updated in the same step, so the saved queue and stats always agree
      // (v48 used a snapshot from before the answer, which lost it).
      const runStats = {
        correctFirstTry: correctFirstTryRef.current,
        totalAtStart: totalAtStartRef.current,
        answerTimes: [...answerTimesRef.current],
        answerExtras: [...answerExtrasRef.current],
        totalTimes: [...totalTimesRef.current],
        pendingSeq: pendingSeqRef.current,
      };
      saveState(activeUser, { ...base, screen, queue, totalCount, answeredCount, wrongCount, missedFacts, runStats });
    } else {
      saveState(activeUser, { ...base, screen: "setup" });
    }
  }, [ready, activeUser, screen, quizSettings, ladderSettings, challengeSettings, globalSettings, queue, totalCount, answeredCount, wrongCount, missedFacts, seqProgress, runMode]);

  // ---------- keep the ladder track valid as its range/exclusion settings change ----------
  // Mastery itself is never pruned — a mastered number stays mastered (and
  // visible) forever, even if it later falls outside the range. The active
  // track number needs to stay inside the current step range, AND it needs
  // to not already be passed (green OR yellow/temp) — a leftover current-
  // number value from before the pass-advance fix (or any other stale
  // state) gets corrected here too, on load and whenever the range
  // changes, using the same "first not-yet-passed number" walk as the
  // pass-advance code itself.
  //
  // v42: a real Range/SKIP change made by the SAME user now always moves
  // the current step to the first unpassed number in the new range (e.g.
  // SKIP On→Off with nothing passed: 2 → 1, since the 1s are now a step
  // and block the title chain). First load and user switches keep the old
  // rule (only fix an invalid step) so a chosen step isn't reset just by
  // opening the app. The ref tells the two apart: it remembers which user
  // the last run was for.
  const trackRangeRef = useRef(null);
  useEffect(() => {
    if (!ready) return;
    const prevRun = trackRangeRef.current;
    trackRangeRef.current = { user: activeUser };
    const sameUserChange = prevRun != null && prevRun.user === activeUser;
    setLadder((prev) => sameUserChange ? withFirstUnpassed(prev, ladderSettings) : withValidTrack(prev, ladderSettings));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, ladderSettings.start, ladderSettings.end, ladderSettings.excludeEasy]);

  // ---------- one-time backfill for numbers mastered before masteredEnd existed ----------
  // Numbers mastered before this build has no recorded End, so their title
  // (11-19 only; 1-10 titles don't depend on End) can't be resolved. There's
  // no way to know the *true* historical End, so this is a best-effort
  // guess: use the current End if it's canonical, otherwise assume 20 (the
  // most permissive case) for anything 11+.
  useEffect(() => {
    if (!ready) return;
    setLadder((prev) => {
      const missing = (prev.mastered || []).some((n) => n >= 11 && n <= 19 && (prev.masteredEnd || {})[n] == null);
      if (!missing) return prev;
      const fallbackEnd = isCanonicalEnd(ladderSettings.end) ? ladderSettings.end : 20;
      const masteredEnd = { ...(prev.masteredEnd || {}) };
      for (const n of prev.mastered) {
        if (n >= 11 && n <= 19 && masteredEnd[n] == null) masteredEnd[n] = fallbackEnd;
      }
      return { ...prev, masteredEnd };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready]);

  const patchQuizSettings = (patch) => setQuizSettings((t) => {
    const merged = { ...t, ...patch };
    if (merged.excludeEasyMode === "auto" && (patch.start !== undefined || patch.end !== undefined || patch.excludeEasyMode !== undefined)) {
      merged.excludeEasy = autoExcludeEasy(merged.start, merged.end);
    }
    return merged;
  });
  const patchLadderSettings = (patch) => setLadderSettingsRaw((t) => {
    const merged = { ...t, ...patch };
    if (merged.excludeEasyMode === "auto" && (patch.start !== undefined || patch.end !== undefined || patch.excludeEasyMode !== undefined)) {
      merged.excludeEasy = autoExcludeEasy(merged.start, merged.end);
    }
    // v51: Practice Start can't be more than the End — it drops to the End.
    const hi = Math.max(merged.start, merged.end);
    if ((merged.practiceStart ?? 1) > hi) merged.practiceStart = hi;
    return merged;
  });
  const patchChallengeSettings = (patch) => setChallengeSettingsRaw((t) => ({ ...t, ...patch }));
  const patchGlobalSettings = (patch) => setGlobalSettings((t) => ({ ...t, ...patch }));

  const resetTabDefaults = () => {
    setQuizSettings(DEFAULT_QUIZ_SETTINGS);
    setLadderSettingsRaw(DEFAULT_LADDER_SETTINGS);
    setChallengeSettingsRaw(DEFAULT_CHALLENGE_SETTINGS);
    setGlobalSettings(DEFAULT_GLOBAL_SETTINGS);
    setQuizCustomStart(!isDefaultRange(DEFAULT_QUIZ_SETTINGS.start, DEFAULT_QUIZ_SETTINGS.end));
    setQuizCustomLength(isCustomLength(DEFAULT_QUIZ_SETTINGS.length));
    setLadderCustomStart(!isDefaultRange(DEFAULT_LADDER_SETTINGS.start, DEFAULT_LADDER_SETTINGS.end, false));
    setLadderCustomLength(isCustomLength(DEFAULT_LADDER_SETTINGS.length));
    setSeqProgress({ signature: null, cursor: 0 });
  };

  // ---------- user management ----------
  const loadUserBundle = async (user) => {
    const [runState, userLog, mastery] = await Promise.all([loadState(user), loadLog(user), loadMastery(user)]);
    applyLoadedRunState(runState);
    setLog(userLog || []);
    setLadderRaw(withValidTrack(normalizeLadder(mastery), normalizeSettings(runState && runState.ladderSettings, DEFAULT_LADDER_SETTINGS)));
  };

  const switchUser = async (name) => {
    setUserPanelOpen(false);
    if (name === activeUser) return;
    setActiveUser(name);
    await saveUsers({ names: usersRef.current, lastUser: name });
    await loadUserBundle(name);
  };

  const createUser = async () => {
    const name = newUserName.trim();
    const current = usersRef.current;
    if (!name || current.length >= MAX_USERS) return;
    setUserPanelOpen(false);
    setNewUserName("");
    if (current.includes(name)) { switchUser(name); return; }
    const next = [...current, name];
    usersRef.current = next;
    setUsers(next);
    setActiveUser(name);
    await saveUsers({ names: next, lastUser: name });
    resetTabDefaults();
    setQueue([]);
    setCurrent(null);
    setLog([]);
    setLadderRaw(withValidTrack({ ...DEFAULT_LADDER }, DEFAULT_LADDER_SETTINGS));
    setScreen("setup");
  };

  const createFirstUser = async () => {
    const name = nameGateValue.trim();
    if (!name) return;
    const next = [name];
    usersRef.current = next;
    setUsers(next);
    setActiveUser(name);
    await saveUsers({ names: next, lastUser: name });
    resetTabDefaults();
    setLog([]);
    setLadderRaw(withValidTrack({ ...DEFAULT_LADDER }, DEFAULT_LADDER_SETTINGS));
    setScreen("setup");
    startIntroFor(name); // v45: a brand-new first user sees it right away
  };

  const requestDelete = (name) => setDeleteTarget(name);

  const confirmDelete = async (passcode) => {
    if (passcode !== TEACHER_PASSCODE) return false;
    const target = deleteTarget;
    setDeleteTarget(null);
    const current = usersRef.current;
    const next = current.filter((u) => u !== target);
    usersRef.current = next;
    await deleteUserData(target);
    setUsers(next);
    setUserPanelOpen(false);
    if (target === activeUser) {
      if (next.length > 0) {
        await saveUsers({ names: next, lastUser: next[0] });
        setActiveUser(next[0]);
        await loadUserBundle(next[0]);
      } else {
        await saveUsers({ names: [], lastUser: null });
        setActiveUser(null);
        setScreen("namegate");
      }
    } else {
      await saveUsers({ names: next, lastUser: activeUser });
    }
    return true;
  };

  const exportBackup = async () => {
    try {
      const { names, lastUser } = await loadUsers();
      const userData = {};
      for (const name of names || []) {
        const [st, lg, ms] = await Promise.all([loadState(name), loadLog(name), loadMastery(name)]);
        userData[name] = { state: st, log: lg, mastery: ms };
      }
      const payload = { version: 2, exportedAt: new Date().toISOString(), users: { names, lastUser }, userData };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const date = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `times-tables-backup-${date}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      setToast({ message: "Couldn't create the backup file.", tone: "error" });
    }
  };

  const importBackup = async (file) => {
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!parsed || !parsed.users || !parsed.userData) {
        setToast({ message: "That file doesn't look like a valid backup.", tone: "error" });
        return;
      }
      const names = parsed.users.names || [];
      for (const name of names) {
        const data = parsed.userData[name] || {};
        if (data.state) await saveState(name, data.state);
        if (data.log) await saveLog(name, data.log);
        if (data.mastery) await saveMastery(name, data.mastery);
      }
      await saveUsers(parsed.users);
      const restoredUser = parsed.users.lastUser && names.includes(parsed.users.lastUser) ? parsed.users.lastUser : (names[0] || null);
      usersRef.current = names;
      setUsers(names);
      setActiveUser(restoredUser);
      if (restoredUser) await loadUserBundle(restoredUser);
      setToast({ message: "Backup restored.", tone: "info" });
    } catch {
      setToast({ message: "Couldn't read that backup file.", tone: "error" });
    }
  };

  // ---------- starting quizzes ----------
  const resetRunRefs = (length) => {
    correctFirstTryRef.current = 0;
    totalAtStartRef.current = length;
    answerTimesRef.current = [];
    answerExtrasRef.current = [];
    totalTimesRef.current = [];
    firstTryMissesRef.current = 0;
    missedFactObjsRef.current = [];
    failShownRef.current = false;
    pauseFlagRef.current = false;
    pendingSeqRef.current = null;
    setFailInfo(null);
  };

  const startQuiz = () => {
    const sig = poolSignature(quizSettings);
    const cursor = quizSettings.order === "sequential" && seqProgress.signature === sig ? seqProgress.cursor : 0;
    const { queue: q, nextCursor } = buildQuizQueue(quizSettings, cursor);
    if (q.length === 0) return;
    resetRunRefs(q.length);
    if (quizSettings.order === "sequential" && quizSettings.length !== "ALL") pendingSeqRef.current = { kind: "quiz", signature: sig, cursor: nextCursor };
    setQueue(q);
    setTotalCount(q.length);
    setAnsweredCount(0);
    setWrongCount(0);
    setMissedFacts([]);
    setCurrent(q[0]);
    if (quizSettings.answerMode === "mc") setChoices(makeChoices(q[0]));
    setFeedback(null);
    setInputVal("");
    setPauseRequested(false);
    setIsPaused(false);
    setRunMode({ kind: "normal", operation: quizSettings.operation });
    setLadderResult(null);
    setScreen("quiz");
  };

  const reallyStartLadderQuiz = (number, mode) => {
    const order = ladderModeOrder(mode);
    const answerMode = mode.startsWith("type") ? "type" : "mc";
    // v42: only Type In · Random · Test ALL ("type-test") can pass a number.
    // Type In · Random is now practice (uses Quiz Length, operation, etc.).
    // v43: Test ALL on ANY unpassed number inside the Ladder range counts
    // (was: only the current step). The ▲ step is just the suggestion.
    const passedEitherNow = [...(ladder.mastered || []), ...(ladder.tempMastered || [])];
    const inStepRange = ladderStepNumbers(ladderSettings).includes(number);
    // v44: Test ALL on a green number at a bigger canonical End is an
    // UPGRADE test (e.g. Senior 12 → Royal 12): it asks only the facts not
    // yet passed under the Facts Passed Rule, and a pass records the new End.
    const upgrade = mode === "type-test" && inStepRange && isUpgradeTest(number, ladderSettings, ladder);
    // v52: green at 12, no yellow, End 13-19 → a real attempt for the yellow pill.
    const yellowAttempt = mode === "type-test" && inStepRange && !upgrade && isYellowAboveAttempt(number, ladderSettings, ladder);
    const isMasteryAttempt = mode === "type-test" && inStepRange
      && (!passedEitherNow.includes(number) || upgrade || yellowAttempt);
    // v51 (choice A): Practice Start is part of the In Order bookmark, so
    // changing it starts In Order at the new first fact. Left off the key
    // at 1 so places saved before v51 still match.
    const psKey = (ladderSettings.practiceStart ?? 1) > 1 ? `|ps${ladderSettings.practiceStart}` : "";
    const cursorKey = `${number}|${poolSignature(ladderSettings)}${psKey}`;
    const cursor = order === "sequential" ? (ladder.seqCursor?.[cursorKey] ?? 0) : 0;
    const { queue: q, nextCursor } = buildLadderQueue(number, mode, ladderSettings, cursor, ladder.excludeMastered, ladder);
    if (q.length === 0) {
      // Upgrade test with nothing left to ask — every new fact was already
      // proven through other numbers — so upgrade on the spot.
      if (upgrade) {
        const newEnd = passEndFor(ladderSettings.end);
        const masteredEnd = { ...(ladder.masteredEnd || {}), [number]: newEnd };
        const titleBefore = currentTitleFor(ladder.mastered, ladder.masteredEnd);
        const titleAfter = currentTitleFor(ladder.mastered, masteredEnd);
        setLadder((prev) => ({ ...prev, masteredEnd: { ...(prev.masteredEnd || {}), [number]: newEnd } }));
        setUpgradeInfo({ number, end: newEnd, newTitle: titleAfter && titleAfter !== titleBefore ? titleAfter : null });
      }
      return;
    }
    resetRunRefs(q.length);
    if (mode !== "type-test" && order === "sequential" && nextCursor !== null && ladderSettings.length !== "ALL") {
      pendingSeqRef.current = { kind: "ladder", cursorKey, cursor: nextCursor };
    }
    setQueue(q);
    setTotalCount(q.length);
    setAnsweredCount(0);
    setWrongCount(0);
    setMissedFacts([]);
    setCurrent(q[0]);
    if (answerMode === "mc") setChoices(makeChoices(q[0]));
    setFeedback(null);
    setInputVal("");
    setPauseRequested(false);
    setIsPaused(false);
    setRunMode({ kind: "ladder", number, mode, answerMode, order, isMasteryAttempt, yellowAttempt, operation: mode === "type-test" ? "both" : ladderSettings.operation });
    setLadderResult(null);
    setScreen("quiz");
  };

  // (Yellow badges are cleared by the Range section's "Lose your yellow
  // badges?" pop-up when the End gets bigger — v44 — not here.)
  const startLadderQuiz = (number, mode) => {
    reallyStartLadderQuiz(number, mode);
  };

  const startChallenge = (level) => {
    const pool = challengeRunPool(level, ladder.mastered, ladder.masteredEnd);
    if (pool.length === 0) return;
    const q = buildChallengeQueue(pool);
    resetRunRefs(q.length);
    setQueue(q);
    setTotalCount(q.length);
    setAnsweredCount(0);
    setWrongCount(0);
    setMissedFacts([]);
    setCurrent(q[0]);
    setFeedback(null);
    setInputVal("");
    setPauseRequested(false);
    setIsPaused(false);
    setRunMode({ kind: "challenge", level, answerMode: "type", operation: "both" });
    setLadderResult(null);
    setScreen("quiz");
  };

  // ---------- finishing a quiz ----------
  const finishQuiz = useCallback((remaining, opts = {}) => {
    const stopped = !!opts.stopped;
    if (!stopped && remaining.length > 0) {
      setCurrent(remaining[0]);
      if (effectiveAnswerMode === "mc") setChoices(makeChoices(remaining[0]));
      setFeedback(null);
      setInputVal("");
      setCorrectAnswerShown(null);
      setWillRepeat(false);
      return;
    }
    const total = totalAtStartRef.current;
    const percent = total > 0 ? Math.round((correctFirstTryRef.current / total) * 100) : 0;
    const times = answerTimesRef.current;
    const isLadder = runMode.kind === "ladder";
    const activeSettings = isLadder ? ladderSettings : runMode.kind === "challenge" ? challengeSettings : quizSettings;
    const speedModeFinal = activeSettings.speedMode || "normal";
    const baseThresholdSeconds = globalSettings.slowThresholdSeconds ?? 5;
    const effectiveThresholdSeconds = speedModeFinal !== "normal" ? baseThresholdSeconds / 2 : baseThresholdSeconds;
    const limitMs = effectiveThresholdSeconds * 1000;
    const avgMs = times.length > 0 ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) : null;
    const extras = answerExtrasRef.current;
    const overLimit = times.filter((t, i) => t > limitMs + (extras[i] || 0)).length;
    const totalMs = totalTimesRef.current.reduce((a, b) => a + b, 0);

    const entry = {
      date: new Date().toISOString(),
      totalQuestions: total,
      percentCorrect: percent,
      mode: effectiveAnswerMode,
      operation: runMode.operation ?? activeSettings.operation,
      range: isLadder
        ? `Ladder ${runMode.number}s`
        : runMode.kind === "challenge"
        ? `Challenge ${runMode.level}`
        : `${Math.min(quizSettings.start, quizSettings.end)}–${Math.max(quizSettings.start, quizSettings.end)}`,
      avgAnswerTimeMs: avgMs,
      overLimitCount: overLimit,
      slowThresholdSeconds: effectiveThresholdSeconds,
      totalTimeMs: totalMs,
    };
    // v46: pass attempts (Test ALL that can pass a number, incl. upgrade
    // tests, and every Challenge) get their own History row: label, End,
    // correct / missed counts (first try) and whether it passed.
    const isPassAttempt = runMode.kind === "challenge" || (isLadder && runMode.isMasteryAttempt);
    if (isPassAttempt) {
      const correct = correctFirstTryRef.current;
      entry.passAttempt = runMode.kind === "challenge" ? "challenge" : "test";
      entry.correctCount = correct;
      entry.missedCount = total - correct;
      entry.passed = correct >= total - allowedMisses(total);
      // v49: show the rounded End (a pass at End 15 counts for Step 12).
      // v52: a yellow-pill attempt (green 12, End 13-19) shows the End tested.
      if (isLadder) entry.range = `Ladder ${runMode.number}s up to ${runMode.yellowAttempt ? ladderSettings.end : (passEndFor(ladderSettings.end) ?? ladderSettings.end)}`;
    }
    const user = activeUserRef.current;
    // v44: a quiz stopped from the fail pop-up isn't a finished quiz.
    // v53: a stopped pass attempt (fail pop-up Stop, or ✕ — opts.quit) with
    // at least 1 question answered gets a "Stopped" History row, kept out
    // of the averages (HistoryScreen filters e.stopped). Other stopped quizzes
    // and app close are not saved.
    const answered = answerTimesRef.current.length;
    const logStopped = stopped && isPassAttempt && answered > 0;
    if (logStopped) {
      entry.stopped = true;
      entry.answeredCount = answered;
      entry.missedCount = answered - correctFirstTryRef.current;
      entry.passed = false;
    }
    if (user && (!stopped || logStopped)) setLog((prev) => { const next = [entry, ...prev]; saveLog(user, next); return next; });
    // v53: ✕ only saves the Stopped row; the quit handler does the rest.
    if (opts.quit) return;
    // v48: a finished quiz moves the In Order place forward (see pendingSeqRef).
    const pendingSeq = pendingSeqRef.current;
    pendingSeqRef.current = null;
    if (!stopped && pendingSeq) {
      if (pendingSeq.kind === "quiz") setSeqProgress({ signature: pendingSeq.signature, cursor: pendingSeq.cursor });
      else setLadder((prev) => ({ ...prev, seqCursor: { ...prev.seqCursor, [pendingSeq.cursorKey]: pendingSeq.cursor } }));
    }
    // v44: pass = first-try misses within the allowance (1 per full 100
    // questions). Under 100 questions that's 0, i.e. the old 100% rule.
    const passedRun = !stopped && (total - correctFirstTryRef.current) <= allowedMisses(total);
    const workOn = workOnList(runMode.kind, missedFactObjsRef.current);

    let banner = null;
    if (runMode.kind === "challenge") {
      const level = runMode.level;
      if (passedRun) {
        const allNumbers = Array.from({ length: level }, (_, i) => i + 1);
        const masteredList = [...new Set([...ladder.mastered, ...allNumbers])];
        const masteredEnd = { ...ladder.masteredEnd };
        // v44: keep the bigger End — a number already passed at a bigger
        // End on the Ladder keeps it (was overwritten with the band End).
        allNumbers.forEach((n) => { masteredEnd[n] = Math.max(masteredEnd[n] ?? 0, challengeMasteredEnd(n)); });
        setLadder({ ...ladder, mastered: masteredList, masteredEnd });
        banner = { challengeLevel: level, mastered: true };
      } else {
        banner = { challengeLevel: level, mastered: false, missed: true, workOn, stopped };
      }
    } else if (isLadder && runMode.isMasteryAttempt) {
      const number = runMode.number;
      if (passedRun) {
        const stepNumbers = ladderStepNumbers(ladderSettings);
        // v49 (audit item 4): the End rounds down (10-11 -> 10, 12-19 -> 12,
        // 20 -> 20); End 9 or lower gives a yellow badge. Yellow numbers are
        // never pass attempts (the yellow pop-up clears them first when the
        // End grows), so a green pass never needs to remove a yellow one.
        const passEnd = passEndFor(ladderSettings.end);
        const canonical = passEnd != null;
        const masteredList = (canonical && !ladder.mastered.includes(number)) ? [...ladder.mastered, number] : ladder.mastered;
        const masteredEnd = canonical ? { ...ladder.masteredEnd, [number]: passEnd } : ladder.masteredEnd;
        // v51 "Yellow above 12": End 13-19 is green at 12 PLUS a yellow
        // badge showing the End reached (yellow counts for nothing).
        const addYellow = !canonical || yellowAboveTwelve(ladderSettings.end);
        const tempMasteredList = !addYellow
          ? (ladder.tempMastered || [])
          : ((ladder.tempMastered || []).includes(number) ? ladder.tempMastered : [...(ladder.tempMastered || []), number]);
        const tempMasteredEnd = !addYellow ? (ladder.tempMasteredEnd || 0) : Math.max(ladder.tempMasteredEnd || 0, ladderSettings.end);
        const passedEither = [...masteredList, ...tempMasteredList];
        // v43: numbers can be passed out of order, so the next step is the
        // first unpassed number in the whole range (not just after this one).
        // If everything is passed, stay on this number (as before).
        const next = stepNumbers.find((n) => !passedEither.includes(n)) ?? number;
        // v45: did this pass earn a NEW title? (green passes only)
        const titleBefore = currentTitleFor(ladder.mastered, ladder.masteredEnd);
        const titleAfter = canonical ? currentTitleFor(masteredList, masteredEnd) : titleBefore;
        const newTitle = titleAfter && titleAfter !== titleBefore ? titleAfter : null;
        setLadder({ ...ladder, currentNumber: next, mastered: masteredList, masteredEnd, tempMastered: tempMasteredList, tempMasteredEnd, lastMode: "mc-seq" });
        banner = { number, mastered: true, nextNumber: next === number ? null : next, end: runMode.yellowAttempt ? ladderSettings.end : (passEnd ?? ladderSettings.end), newTitle };
      } else {
        banner = { number, mastered: false, missed: true, stopped };
      }
    }
    if (stopped && !banner) banner = { stopped: true };
    setLadderResult(banner);
    setScreen("results");
  }, [effectiveAnswerMode, globalSettings, quizSettings, ladderSettings, runMode, ladder, setLadder]);

  // ---------- repeat-scheduling + answer submission ----------
  const advanceAfterAnswer = useCallback((wasCorrect, fact, wasSlow) => {
    setQueue((prev) => {
      const rest = prev.slice(1);
      const isType = effectiveAnswerMode === "type";
      const activeSpeedSettings = runMode.kind === "ladder" ? ladderSettings : runMode.kind === "challenge" ? challengeSettings : quizSettings;
      const speedMode = activeSpeedSettings.speedMode || "normal";
      const testMode = speedMode === "test";
      const fastPaced = speedMode === "fast" || speedMode === "test";
      const makeId = () => `${fact.key}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      let next = rest;
      let addedCount = 0;
      const repeatsUsed = fact.repeatsUsed || 0;
      const canRepeatAgain = repeatsUsed < 1;

      if (!testMode) {
        if (!wasCorrect) {
          // Always an immediate repeat on any wrong answer — no gate,
          // no cap, same in Choose and Type In.
          next = [{ ...fact, id: makeId(), isRepeat: true, repeatKind: "immediate" }, ...rest];
          addedCount += 1;
        } else if (fact.repeatKind === "immediate" && canRepeatAgain) {
          // This fact was just an immediate repeat from a wrong
          // answer, and now got answered correctly (fast or slow) —
          // schedule one more delayed check-back to confirm it's
          // really learned, on top of the immediate repeat it already
          // got.
          const insertAt = Math.min(rest.length, 3 + Math.floor(Math.random() * 4));
          next = [...rest.slice(0, insertAt), { ...fact, id: makeId(), isRepeat: true, repeatsUsed: repeatsUsed + 1, repeatKind: "delayed" }, ...rest.slice(insertAt)];
          addedCount += 1;
        } else if (wasSlow) {
          // Slow-but-correct: always an immediate repeat, tagged
          // slowRepeat, no matter how many times in a row this fact
          // has been slow. Unlike a wrong answer, this never escalates
          // to a later delayed check-back — only wrong answers earn
          // that second, delayed repeat.
          next = [{ ...fact, id: makeId(), isRepeat: true, slowRepeat: true }, ...rest];
          addedCount += 1;
        }
      }

      if (addedCount > 0) setTotalCount((c) => c + addedCount);

      const delay = fastPaced
        ? (wasCorrect ? 1750 : 2500)
        : isType
          ? (wasCorrect ? 3500 : 2500)
          : (wasCorrect ? 2000 : 3000);

      setTimeout(() => {
        if (pauseFlagRef.current) {
          pausedQueueRef.current = next;
          setPauseRequested(false);
          setIsPaused(true);
        } else {
          finishQuiz(next);
        }
      }, delay);

      return next;
    });
  }, [effectiveAnswerMode, finishQuiz, runMode, quizSettings.speedMode, ladderSettings.speedMode, challengeSettings.speedMode]);

  const submitAnswer = (rawAnswer) => {
    if (feedback || !current) return;
    const answer = parseInt(rawAnswer, 10);
    const wasCorrect = answer === current.answer;
    const elapsed = Date.now() - startTimeRef.current;
    const activeSpeedSettingsNow = runMode.kind === "ladder" ? ladderSettings : runMode.kind === "challenge" ? challengeSettings : quizSettings;
    const speedModeNow = activeSpeedSettingsNow.speedMode || "normal";
    const testModeNow = speedModeNow === "test";
    const fastPacedNow = speedModeNow !== "normal";
    const baseThresholdSeconds = globalSettings.slowThresholdSeconds ?? 5;
    const effectiveThresholdSeconds = fastPacedNow ? baseThresholdSeconds / 2 : baseThresholdSeconds;
    // v51: Fast/Fastest Type In gets +0.5 s for 2-digit, +1 s for 3-digit answers.
    const extraMs = extraTimeMs(current.answer, speedModeNow, effectiveAnswerMode);
    const limitMs = effectiveThresholdSeconds * 1000 + extraMs;
    const wasSlow = elapsed > limitMs;

    setFeedback(wasCorrect ? "correct" : "wrong");
    setCorrectAnswerShown(current.answer);
    setWillRepeat((!wasCorrect || wasSlow) && !testModeNow);
    setAnsweredCount((c) => c + 1);

    if (!current.isRepeat) { answerTimesRef.current.push(elapsed); answerExtrasRef.current.push(extraMs); }
    totalTimesRef.current.push(elapsed);
    if (!current.isRepeat && wasCorrect) correctFirstTryRef.current += 1;
    if (!wasCorrect) {
      setWrongCount((c) => c + 1);
      setMissedFacts((f) => [...f, `${current.a} ${current.op} ${current.b}`]);
    }
    // v44: on a pass attempt (Ladder Test ALL / upgrade test, Challenge),
    // the moment first-try misses go over the allowance, passing is
    // impossible — pause after this answer and show the fail pop-up.
    const passAttempt = runMode.kind === "challenge" || (runMode.kind === "ladder" && runMode.isMasteryAttempt);
    if (passAttempt && !current.isRepeat && !wasCorrect) {
      firstTryMissesRef.current += 1;
      missedFactObjsRef.current.push(current);
      if (!failShownRef.current && firstTryMissesRef.current > allowedMisses(totalAtStartRef.current)) {
        failShownRef.current = true;
        pauseFlagRef.current = true;
        setFailInfo({ workOn: workOnList(runMode.kind, missedFactObjsRef.current) });
      }
    }
    advanceAfterAnswer(wasCorrect, current, wasSlow);
  };

  const submitTypeForm = (e) => {
    e.preventDefault();
    if (inputVal.trim() !== "") submitAnswer(inputVal.trim());
  };

  const quitToSetup = () => {
    setScreen("setup");
    setQueue([]);
    setCurrent(null);
    setPauseRequested(false);
    setIsPaused(false);
    setRunMode({ kind: "normal" });
  };

  const quitToLadderSetup = () => {
    // v51: after a Ladder quiz, stay on the number just quizzed; only a
    // pass (new badge or upgrade) goes to the ▲ (first unpassed number).
    const passedNow = !!(ladderResult && ladderResult.mastered);
    setLadderReturnNumber(runMode.kind === "ladder" && !passedNow ? runMode.number : null);
    setScreen("setup");
    setActiveTab("gradient");
    setQueue([]);
    setCurrent(null);
    setPauseRequested(false);
    setIsPaused(false);
    setRunMode({ kind: "normal" });
  };

  const quitToChallengesSetup = () => {
    setScreen("setup");
    setActiveTab("challenges");
    setQueue([]);
    setCurrent(null);
    setPauseRequested(false);
    setIsPaused(false);
    setRunMode({ kind: "normal" });
  };

  const requestPause = () => setPauseRequested(true);
  const resumeFromPause = () => {
    const q = pausedQueueRef.current;
    pausedQueueRef.current = null;
    setIsPaused(false);
    if (q) finishQuiz(q);
  };

  const remaining = queue.length;
  const progressPct = totalCount > 0 ? Math.round((answeredCount / totalCount) * 100) : 0;

  if (!ready) {
    return <div style={s.appBg}><div style={{ color: "#EDEAE0", fontFamily: s.appBg.fontFamily, opacity: 0.6 }}>Loading…</div></div>;
  }

  // ---------- developer settings preview (BD## users only) ----------
  const showDevToggle = isDevUser(activeUser);
  // The current title comes from two independent chains (logic.js
  // chainHighestReached / currentTitleFor — one shared rule for the header,
  // the pass messages and the milestone pills):
  //   Chain A (Learner -> Junior -> Wiz -> Senior): 1 through 12, every
  //     number required (the 1s and 10s too, whatever SKIP is set to —
  //     v49); 11/12 count only when passed at End 12 or more.
  //   Chain B (Royal -> Crown -> King): 11 through 20, its own fresh start,
  //     counting only numbers passed at End 20 (v49).
  // Chain B wins whenever it has begun. Neither chain is gated by Start.
  const currentTitle = currentTitleFor(ladder.mastered, ladder.masteredEnd);
  const previewLadderNumber = ladderStepNumbers(DEFAULT_LADDER_SETTINGS)[0] ?? null;
  const previewLadder = { ...DEFAULT_LADDER, currentNumber: previewLadderNumber };
  const noop = () => {};

  const displayedQuizSettings = devPreview ? DEFAULT_QUIZ_SETTINGS : quizSettings;
  const displayedLadderSettings = devPreview ? DEFAULT_LADDER_SETTINGS : ladderSettings;
  const displayedChallengeSettings = devPreview ? DEFAULT_CHALLENGE_SETTINGS : challengeSettings;
  const displayedLadder = devPreview ? previewLadder : ladder;

  return (
    <div style={s.appBg}>
      <style>{globalCss}</style>
      <div style={s.gridOverlay} />
      <div style={s.container}>
        <Toast message={toast?.message} tone={toast?.tone} onDismiss={() => setToast(null)} />

        {intro && <IntroScreen showing={intro.showing} onDone={() => setIntro(null)} />}
        {!intro && screen === "namegate" && <NameGate value={nameGateValue} setValue={setNameGateValue} onSubmit={createFirstUser} />}

        {!intro && screen === "setup" && (
          <div style={s.card}>
            {showDevToggle && (
              <div style={s.devToggleWrap}>
                <button
                  style={{ ...s.devToggleBtn, ...(!devPreview ? s.devToggleBtnActive : {}), marginRight: 6 }}
                  onClick={() => setDevPreview(false)}
                >
                  Current Settings
                </button>
                <button
                  style={{ ...s.devToggleBtn, ...(devPreview ? s.devToggleBtnActive : {}) }}
                  onClick={() => setDevPreview(true)}
                >
                  Default Settings
                </button>
                <span style={{ marginLeft: 6, fontSize: 10, fontWeight: 700, color: "rgba(237,234,224,0.4)" }}>{APP_VERSION}</span>
              </div>
            )}
            <div style={s.headerRow}>
              <span style={s.times}>×÷</span>
              <div>
                <h1 style={s.h1}>Times Tables 20</h1>
                <p style={s.subtitle}>from <span style={{ color: "#EDEAE0" }}>Be A Math Wiz</span></p>
              </div>
            </div>

            <UserBar
              activeUser={activeUser}
              users={users}
              open={userPanelOpen}
              setOpen={setUserPanelOpen}
              newUserName={newUserName}
              setNewUserName={setNewUserName}
              onSwitch={switchUser}
              onCreate={createUser}
              onDelete={requestDelete}
              currentTitle={currentTitle}
            />
            <div style={{ height: 10 }} />
            <div style={{ display: "flex", justifyContent: "center" }}>
              <button style={{ ...s.segBtn, flex: "none", minWidth: 108, padding: "9px 14px", background: "#1E3A8A", color: "#EDEAE0", border: "1px solid rgba(255,255,255,0.12)", textTransform: "uppercase" }} onClick={() => setScreen("guide")}>Guide</button>
            </div>
            <div style={{ height: 14 }} />

            <div style={s.segGroup}>
              {[{ key: "gradient", label: "Math Wiz Ladder" }, { key: "quizzes", label: "Quizzes" }, { key: "challenges", label: "Challenge Tests" }].map((t) => (
                <button key={t.key} onClick={() => setActiveTab(t.key)} style={{ ...s.segBtn, textTransform: "uppercase", ...(activeTab === t.key ? s.segBtnActive : {}) }}>{t.label}</button>
              ))}
            </div>
            <div style={{ height: 36 }} />

            {devPreview && <p style={s.previewNote}>Previewing default settings for a brand-new user — changes here aren't saved.</p>}
            <div style={{ ...s.previewWrap, ...(devPreview ? { pointerEvents: "none" } : {}) }}>
              {activeTab === "challenges" ? (
                <ChallengesPanel
                  masteredList={displayedLadder.mastered}
                  masteredEnd={displayedLadder.masteredEnd || {}}
                  onStartChallenge={devPreview ? noop : startChallenge}
                  settings={displayedChallengeSettings}
                  patch={devPreview ? noop : patchChallengeSettings}
                />
              ) : activeTab === "gradient" ? (
                <LadderPanel
                  ladder={displayedLadder}
                  ladderNumbers={ladderDisplayNumbers(displayedLadderSettings, displayedLadder.mastered)}
                  stepNumbers={ladderStepNumbers(displayedLadderSettings)}
                  onStartLadder={devPreview ? noop : startLadderQuiz}
                  onSetLadderTrack={devPreview ? noop : (n) => setLadder((prev) => prev.currentNumber === n ? prev : ({ ...prev, currentNumber: n, lastMode: "mc-seq" }))}
                  onSetLadderExcludeMastered={devPreview ? noop : (v) => setLadder((prev) => prev.excludeMastered === v ? prev : ({ ...prev, excludeMastered: v }))}
                  onClearYellow={devPreview ? noop : () => setLadder((prev) => ({ ...prev, tempMastered: [], tempMasteredEnd: 0 }))}
                  settings={displayedLadderSettings}
                  patch={devPreview ? noop : patchLadderSettings}
                  customStart={ladderCustomStart}
                  setCustomStart={devPreview ? noop : setLadderCustomStart}
                  customLength={ladderCustomLength}
                  setCustomLength={devPreview ? noop : setLadderCustomLength}
                  onHistory={devPreview ? noop : () => setScreen("history")}
                  selectedMode={ladderMode || ladder.lastMode || "mc-seq"}
                  setSelectedMode={devPreview ? noop : (key) => { setLadderMode(key); setLadder((prev) => prev.lastMode === key ? prev : ({ ...prev, lastMode: key })); }}
                  onExport={devPreview ? noop : exportBackup}
                  onImport={devPreview ? noop : importBackup}
                  globalSettings={globalSettings}
                  patchGlobalSettings={devPreview ? noop : patchGlobalSettings}
                  initialPreview={devPreview ? null : ladderReturnNumber}
                />
              ) : (
                <QuizzesPanel
                  settings={displayedQuizSettings}
                  patch={devPreview ? noop : patchQuizSettings}
                  customStart={quizCustomStart}
                  setCustomStart={devPreview ? noop : setQuizCustomStart}
                  customLength={quizCustomLength}
                  setCustomLength={devPreview ? noop : setQuizCustomLength}
                  onStart={devPreview ? noop : startQuiz}
                  onHistory={devPreview ? noop : () => setScreen("history")}
                />
              )}
            </div>
          </div>
        )}

        {!intro && screen === "quiz" && current && (
          <QuizScreen
            current={current}
            settings={{ ...quizSettings, answerMode: effectiveAnswerMode }}
            divideSymbols={runMode.kind === "ladder" ? ladderSettings.divideSymbols : runMode.kind === "challenge" ? ["obelus"] : quizSettings.divideSymbols}
            choices={choices}
            inputVal={inputVal}
            setInputVal={setInputVal}
            feedback={feedback}
            correctAnswerShown={correctAnswerShown}
            willRepeat={willRepeat}
            onSubmitType={submitTypeForm}
            onSubmitChoice={(c) => submitAnswer(c)}
            inputRef={inputRef}
            answeredCount={answeredCount}
            totalCount={totalCount}
            remaining={remaining}
            progressPct={progressPct}
            onQuit={() => {
              // v53: log a Stopped row for a pass attempt quit with ✕.
              if (runMode.kind === "challenge" || (runMode.kind === "ladder" && runMode.isMasteryAttempt)) finishQuiz([], { stopped: true, quit: true });
              (runMode.kind === "ladder" ? quitToLadderSetup : runMode.kind === "challenge" ? quitToChallengesSetup : quitToSetup)();
            }}
            pauseRequested={pauseRequested}
            isPaused={isPaused}
            onRequestPause={requestPause}
            onResume={resumeFromPause}
          />
        )}

        {!intro && screen === "results" && (
          <ResultsScreen
            answeredCount={answeredCount}
            wrongCount={wrongCount}
            firstTryCorrect={correctFirstTryRef.current}
            firstTryAnswered={answerTimesRef.current.length}
            missedFacts={missedFacts}
            onRestart={runMode.kind === "ladder" ? quitToLadderSetup : runMode.kind === "challenge" ? quitToChallengesSetup : quitToSetup}
            restartLabel={runMode.kind === "ladder" ? "Back to Math Wiz Ladder" : runMode.kind === "challenge" ? "Back to Challenge Tests" : "Back to Quizzes"}
            ladderResult={ladderResult}
          />
        )}

        {!intro && screen === "history" && (
          <HistoryScreen log={log} settings={globalSettings} setSettings={setGlobalSettings} onBack={() => setScreen("setup")} />
        )}
        {!intro && screen === "guide" && <GuideScreen onBack={() => setScreen("setup")} />}
      </div>

      {deleteTarget && (
        <ConfirmModal title={`Delete "${deleteTarget}"?`} onSubmit={confirmDelete} onCancel={() => setDeleteTarget(null)} />
      )}
      {failInfo && isPaused && (
        <YesNoModal
          title="You did not pass this time."
          message={<>
            <p style={{ margin: 0 }}>You can keep going to practice.</p>
            {failInfo.workOn.length > 0 && <p style={{ margin: "8px 0 0" }}>Work on: {failInfo.workOn.join(", ")}</p>}
          </>}
          confirmLabel="Keep Going"
          cancelLabel="Stop"
          backdropClose={false}
          onConfirm={() => { pauseFlagRef.current = false; setFailInfo(null); resumeFromPause(); }}
          onCancel={() => {
            // If the failing answer was the last question, the quiz is
            // already finished — treat Stop like a normal finish (saved).
            // v49 (audit item 3): in Normal/Fast the miss adds a repeat, so
            // "finished" means only repeats are left, not an empty queue.
            const left = pausedQueueRef.current || [];
            const finishedAnyway = left.every((f) => f.isRepeat);
            pauseFlagRef.current = false;
            setFailInfo(null);
            pausedQueueRef.current = null;
            setIsPaused(false);
            finishQuiz([], { stopped: !finishedAnyway });
          }}
        />
      )}
      {upgradeInfo && (
        <YesNoModal
          title={`${upgradeInfo.number}s up to ${upgradeInfo.end} PASSED!`}
          message={<>
            <p style={{ margin: 0 }}>{`You already passed every new ${upgradeInfo.number}s fact through other numbers, so there is nothing new to test.`}</p>
            {upgradeInfo.newTitle && <p style={{ margin: "8px 0 0" }}>{`You are now a ${upgradeInfo.newTitle}${upgradeInfo.newTitle.endsWith("!") ? "" : "!"}`}</p>}
          </>}
          confirmLabel="OK"
          cancelLabel={null}
          onConfirm={() => setUpgradeInfo(null)}
        />
      )}
    </div>
  );
}
