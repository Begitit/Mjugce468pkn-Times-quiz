import { useMemo } from "react";
import { s } from "./styles.js";
import { Section, SegGroup } from "./components.jsx";
import { AVG_HISTORY_COUNT, averageOf, OPERATION_ABBREV, formatMinSec } from "./logic.js";

export function QuizScreen({
  current, settings, divideSymbols, choices, inputVal, setInputVal, feedback, correctAnswerShown, willRepeat,
  onSubmitType, onSubmitChoice, inputRef, answeredCount, totalCount, remaining, progressPct,
  onQuit, pauseRequested, isPaused, onRequestPause, onResume,
}) {
  // Picked once per question (keyed on current.id, which every fact —
  // original or repeat — always has), not on every re-render, so the
  // symbol doesn't flicker/change while the same question is showing.
  // Only matters for division; multiply always renders current.op ("×")
  // as-is, untouched by this feature.
  const divSymbolKey = useMemo(() => {
    if (current.op !== "\u00F7") return null;
    const list = divideSymbols && divideSymbols.length ? divideSymbols : ["obelus"];
    return list[Math.floor(Math.random() * list.length)];
  }, [current.id]);

  if (isPaused) {
    return (
      <div style={s.card}>
        <div style={s.headerRow}>
          <span style={s.times}>⏸</span>
          <div>
            <h1 style={s.h1}>Paused</h1>
            <p style={s.subtitle}>{answeredCount} answered · {remaining} left</p>
          </div>
        </div>
        <button style={s.primaryBtn} onClick={onResume}>Continue</button>
      </div>
    );
  }

  return (
    <div style={s.card}>
      <div style={s.progressRow}>
        <div style={s.progressTrack}>
          <div style={{ ...s.progressFill, width: `${progressPct}%` }} />
        </div>
        <button style={s.quitBtn} onClick={onQuit} aria-label="Quit quiz">✕</button>
      </div>
      <div style={s.progressLabel}>{answeredCount} answered · {remaining} left</div>
      <div style={{ ...s.questionBox, borderColor: feedback === "correct" ? "#8FBF8A" : feedback === "wrong" ? "#E0785A" : "rgba(255,255,255,0.12)" }}>
        {willRepeat ? (
          <div style={s.repeatBanner}>Will repeat</div>
        ) : current.repeatKind === "immediate" || current.slowRepeat ? (
          <div style={s.repeatBanner}>Repeating</div>
        ) : current.repeatKind === "delayed" ? (
          <div style={s.repeatBanner}>Repeat</div>
        ) : null}
        <div style={s.question}>
          {divSymbolKey === "fraction" ? (
            <span style={{ display: "inline-flex", flexDirection: "column", alignItems: "center", verticalAlign: "middle", lineHeight: 1.15 }}>
              <span>{current.a}</span>
              <span style={{ background: "currentColor", width: `${Math.max(String(current.a).length, String(current.b).length)}ch`, height: "0.06em", margin: "0.08em 0" }} />
              <span>{current.b}</span>
            </span>
          ) : divSymbolKey === "bracket" ? (
            <span style={{ display: "inline-flex", alignItems: "baseline" }}>
              <span>{current.b}</span>
              <span style={{ position: "relative", display: "inline-block", marginLeft: "0.15em", paddingLeft: "0.12em", paddingTop: "0.03em" }}>
                {/* Vertical line — reaches down to the dividend's bottom */}
                <span style={{ position: "absolute", left: 0, top: "0.02em", width: "0.06em", height: "1.32em", background: "currentColor" }} />
                {/* Horizontal line — same top, 50% longer than the vertical line or as long as the dividend, whichever is longer */}
                <span style={{ position: "absolute", left: 0, top: "0.02em", height: "0.06em", width: `max(1.98em, ${String(current.a).length}ch)`, background: "currentColor" }} />
                {current.a}
              </span>
            </span>
          ) : divSymbolKey === "slash" ? (
            <>{current.a}<span style={{ ...s.op, margin: "0 0.2em" }}>/</span>{current.b}</>
          ) : divSymbolKey === "obelus" ? (
            <>{current.a}<span style={{ ...s.op, margin: "0 0.2em" }}>{current.op}</span>{current.b}</>
          ) : (
            <>{current.a} <span style={s.op}>{current.op}</span> {current.b}</>
          )}
        </div>
        {settings.answerMode === "type" ? (
          <div style={s.answerForm}>
            <input
              ref={inputRef}
              type="number"
              inputMode="numeric"
              className="answer-input"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") onSubmitType(e); }}
              disabled={!!feedback}
              style={s.answerInput}
              placeholder="?"
              autoFocus
            />
            <button type="button" onClick={onSubmitType} style={s.submitBtn} disabled={!!feedback}>Check</button>
          </div>
        ) : (
          <div style={s.choiceGrid}>
            {choices.map((c) => (
              <button
                key={c}
                onClick={() => onSubmitChoice(c)}
                disabled={!!feedback}
                style={{ ...s.choiceBtn, ...(feedback && c === correctAnswerShown ? s.choiceCorrect : {}), ...(feedback === "wrong" && c !== correctAnswerShown ? s.choiceDim : {}) }}
              >
                {c}
              </button>
            ))}
          </div>
        )}
        {feedback && (
          <div style={{ ...s.feedbackText, color: feedback === "correct" ? "#8FBF8A" : "#E0785A" }}>
            {feedback === "correct" ? "CORRECT" : `Not quite — it's ${correctAnswerShown}`}
          </div>
        )}
      </div>
      <button style={{ ...s.secondaryBtn, opacity: pauseRequested ? 0.6 : 1 }} onClick={onRequestPause} disabled={pauseRequested}>
        {pauseRequested ? "Pausing after this question…" : "Pause before next question"}
      </button>
    </div>
  );
}

export function ResultsScreen({ answeredCount, wrongCount, firstTryCorrect, firstTryAnswered, missedFacts, onRestart, restartLabel, ladderResult }) {
  // v47: first-try counts only (same count the pass rule and History use).
  // Before v47 this was answeredCount - wrongCount, which counted repeated
  // questions. v48: resumed Quizzes-tab quizzes now keep their first-try
  // data, so the v47 fallback to the old count is gone.
  const correctCount = firstTryCorrect;
  const missedCount = firstTryAnswered - firstTryCorrect;
  const uniqueMissed = Array.from(new Set(missedFacts));
  return (
    <div style={s.card}>
      <div style={s.headerRow}>
        <span style={s.times}>✓</span>
        <div>
          <h1 style={s.h1}>{ladderResult && ladderResult.stopped ? "Quiz Stopped" : "Quiz Done!"}</h1>
          <p style={s.subtitle}>{correctCount} correct on first try · {missedCount} missed</p>
        </div>
      </div>
      {ladderResult && ladderResult.challengeLevel !== undefined && (
        <div style={{ marginBottom: 16, padding: 12, borderRadius: 10, background: "rgba(232,185,74,0.12)", border: "1px solid rgba(232,185,74,0.4)", color: "#E8B94A", fontSize: 14, fontWeight: 600 }}>
          {ladderResult.mastered
            ? `Challenge ${ladderResult.challengeLevel} PASSED!\u00A0\u00A0\u00A0You have won the title and every number below it.`
            : <>
                {`You did not pass the ${ladderResult.challengeLevel} challenge this time.`}
                {ladderResult.workOn && ladderResult.workOn.length > 0 && <div style={{ marginTop: 6, fontWeight: 500 }}>Work on: {ladderResult.workOn.join(", ")}</div>}
              </>}
        </div>
      )}
      {ladderResult && ladderResult.challengeLevel === undefined && ladderResult.number !== undefined && (
        <div style={{ marginBottom: 16, padding: 12, borderRadius: 10, background: "rgba(232,185,74,0.12)", border: "1px solid rgba(232,185,74,0.4)", color: "#E8B94A", fontSize: 14, fontWeight: 600 }}>
          {ladderResult.mastered
            // v45: "Ns up to End PASSED!" + 3 non-breaking spaces (the gap
            // must not collapse). A newly earned title replaces "Next up" /
            // the whole-ladder line. Titles ending in "!" (Math Wiz!) don't
            // get a second one.
            ? `${ladderResult.number}s up to ${ladderResult.end} PASSED!\u00A0\u00A0\u00A0` + (ladderResult.newTitle
                ? `You are now a ${ladderResult.newTitle.replace(/!$/, "")}!`
                : ladderResult.nextNumber
                  ? `Next up: the ${ladderResult.nextNumber}s.`
                  : "You have passed the whole ladder.")
            : `Not quite — give the ${ladderResult.number}s another go.`}
        </div>
      )}
      {uniqueMissed.length > 0 && (
        <div style={s.missedBox}>
          <div style={s.missedLabel}>Facts you missed</div>
          <div style={s.missedList}>
            {uniqueMissed.map((f) => <span key={f} style={s.missedChip}>{f}</span>)}
          </div>
        </div>
      )}
      <button style={s.primaryBtn} onClick={onRestart}>{restartLabel}</button>
    </div>
  );
}

export function HistoryScreen({ log, settings, setSettings, onBack }) {
  const dropWorst = settings.dropWorstScore;
  // v53: Stopped rows are kept out of the averages and the count.
  const scored = log.filter((e) => !e.stopped);
  const recentAvg = averageOf(scored.slice(0, AVG_HISTORY_COUNT), dropWorst);
  const overallAvg = averageOf(scored, dropWorst);

  return (
    <div style={s.card}>
      <div style={s.headerRow}>
        <span style={s.times}>≡</span>
        <div>
          <h1 style={s.h1}>Scores History</h1>
          <p style={s.subtitle}>{scored.length} finished quizzes</p>
        </div>
      </div>
      <Section label="Skip the worst quiz score:">
        <SegGroup options={[{ v: true, l: "On" }, { v: false, l: "Off" }]} value={dropWorst} onChange={(v) => setSettings((t) => ({ ...t, dropWorstScore: v }))} />
      </Section>
      <div style={s.statsRow}>
        <div style={s.statBox}>
          <div style={s.statLabel}>Last {AVG_HISTORY_COUNT} Quizzes</div>
          <div style={s.statValue}>{recentAvg === null ? "—" : `${recentAvg}%`}</div>
        </div>
        <div style={s.statBox}>
          <div style={s.statLabel}>All Quizzes</div>
          <div style={s.statValue}>{overallAvg === null ? "—" : `${overallAvg}%`}</div>
        </div>
      </div>
      {log.length > 0 ? (
        <div style={s.historyList}>
          {log.map((e, i) => {
            const modeLabel = e.mode === "mc" ? "Choose Answer" : "Type Answer";
            const opTag = e.operation ? ` - ${OPERATION_ABBREV[e.operation]}` : "";
            const totalTime = formatMinSec(e.totalTimeMs);
            if (e.passAttempt) {
              // v46: pass-attempt row (Test ALL or Challenge). Answer type and
              // operation are fixed by these modes, so they are not shown.
              const label = e.passAttempt === "challenge" ? e.range : "Test ALL";
              // v53: Stopped rows — no %, questions as "5 of 24Q".
              return (
                <div key={i} style={s.historyRow}>
                  <div style={s.historyTopLine}>
                    <span style={s.historyDate}>{new Date(e.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</span>
                    <span style={s.historyMode}>{label} · {e.stopped ? "Stopped" : e.passed ? "Passed" : "Not passed"}</span>
                    {!e.stopped && <span style={s.historyPercent}>{e.percentCorrect}%</span>}
                  </div>
                  <div style={s.historyDetailLine}>
                    {e.passAttempt === "test" && e.range && <span>{e.range}</span>}
                    <span>{e.stopped ? `${e.answeredCount} of ${e.totalQuestions}Q` : `${e.totalQuestions} questions`}</span>
                    <span>{e.correctCount} correct</span>
                    <span>{e.missedCount} missed</span>
                    {e.avgAnswerTimeMs != null && <span><span style={s.historyTimeValue}>{(e.avgAnswerTimeMs / 1000).toFixed(1)} sec.</span> avg</span>}
                    {e.overLimitCount != null && <span>{e.overLimitCount} over {e.slowThresholdSeconds ?? 5} sec. limit</span>}
                    {totalTime != null && <span><span style={s.historyTimeValue}>{totalTime}</span> Total</span>}
                  </div>
                </div>
              );
            }
            return (
              <div key={i} style={s.historyRow}>
                <div style={s.historyTopLine}>
                  <span style={s.historyDate}>{new Date(e.date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</span>
                  <span style={s.historyMode}>{modeLabel}{opTag}</span>
                  <span style={s.historyPercent}>{e.percentCorrect}%</span>
                </div>
                <div style={s.historyDetailLine}>
                  <span>{e.totalQuestions}Q</span>
                  {e.range && <span>{e.range}</span>}
                  {e.avgAnswerTimeMs != null && <span><span style={s.historyTimeValue}>{(e.avgAnswerTimeMs / 1000).toFixed(1)} sec.</span> avg</span>}
                  {e.overLimitCount != null && <span>{e.overLimitCount} over {e.slowThresholdSeconds ?? 5} sec. limit</span>}
                  {totalTime != null && <span><span style={s.historyTimeValue}>{totalTime}</span> Total</span>}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <p style={s.subtitle}>No finished quizzes yet.</p>
      )}
      <button style={s.primaryBtn} onClick={onBack}>Go Back</button>
    </div>
  );
}
