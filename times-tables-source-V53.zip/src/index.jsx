import { createRoot } from "react-dom/client";
import { PasscodeGate } from "./components.jsx";
import App from "./app.jsx";

const root = createRoot(document.getElementById("root"));
root.render(
  <PasscodeGate>
    <App />
  </PasscodeGate>
);
