# Times Tables — older changelog (v39 and earlier)

Moved out of README.md at V49 to keep the README readable. These entries are
history: many describe rules that were replaced later. For the CURRENT rules,
read README.md (Key design points and the feature sections), not this file.

**Note on version-number duplication in this changelog**: v27 appears
twice below with two unrelated descriptions — "Challenge Tests intro
paragraph reworded" (the original, older v27) and, further down,
"repeat-scheduling fix + Challenge Tests EVERY" (a *different* v27,
from a later work session that reused the version number by mistake
— the app's `APP_VERSION` wasn't bumped at the start of that session,
an error caught and fixed from v28 onward). Both entries are real and
both describe things that actually shipped; the number just isn't
unique for that one version. Don't let the collision cause either
entry to be discarded or merged.

### Recently built (v39) — "Exclude" → "SKIP" wording

"Exclude" is roughly a 4th–5th-grade word; players are 2nd–3rd grade.
User-facing text changed in setup.jsx (3 spots):
1. Section label (both tabs): `Exclude 1×, 10×, ÷1, ÷10` → `Skip 1×, 10×, ÷1, ÷10`
   (sectionLabel CSS uppercases it, so it shows as SKIP 1×, 10×, ÷1, ÷10).
2. Ladder no-numbers message: …the "SKIP 1×, 10×" setting below.
3. Ladder fallback message: …your current Range/SKIP settings — showing
   previously mastered numbers only.
Code comments and identifiers still say "Exclude Easy" / excludeEasy —
intentionally unchanged (not user-visible).

### Recently built (v38) — noindex + Backup section collapsible

**noindex:** the HTML shell above now includes
`<meta name="robots" content="noindex" />`. It had been dropped from the
template at some point; it backs up the unlisted random repo name so
search engines don't list the page. Keep it in every build.

**Backup collapsible** (Ladder tab, setup.jsx `LadderPanel`): the
Save Backup File / Restore from File row and its explanation line are
now behind one centered **Backup** button, styled and sized like the
Teacher Settings button (`backupBtn`, `flex: none`, `padding: 16px 20px`).
Tapping it reveals the row + text and the button becomes **Done**; Done
hides them. Always starts closed — local `backupOpen` useState, not
saved. Same open/close pattern as Division Symbols (Choose/Done). No
auto-close after save/restore (considered and rejected). The hidden
file input stays mounted regardless.

### Recently built (v37) — Division Symbols section collapsible

`DivideSymbolsSection` (setup.jsx, used on both Quizzes and Ladder tabs)
now collapses. A **Choose** button sits right of the "Division Symbols"
title (passed as JSX through `Section`'s `label`; button overrides the
label's uppercase so it reads "Choose"/"Done" as written). Tapping it
reveals the note and the four checkboxes and the button becomes
**Done**; Done hides everything but the title and button. Always starts
collapsed — local `useState(false)`, not saved to settings. Button uses
the plain `segBtn` look in both states (no gold active style — not
requested).

### Recently built (v36) — long division bracket, final confirmed position

User confirmed via a Visualizer mock-up graphic (not a live render —
this environment has no browser) that the v35 bracket sat too high by
about 10% of the digits' height, and asked for the vertical line about
10% longer. Applied: raise `top` from `-0.08em` to `0.02em` (undoing
≈10% of a digit's height worth of raise), vertical line `height` from
`1.2em` to `1.32em` (10% longer), and the horizontal line's
1.5×-vertical minimum recalculated from `max(1.8em, ...)` to
`max(1.98em, ...)` (1.5 × 1.32em) to stay consistent with the
existing rule. `paddingTop: "0.03em"` on the dividend box untouched —
not part of this request. Same values in both `quiz.jsx` (the live
question) and `setup.jsx` (`DivisionSymbolExample`, the settings-page
preview), kept in sync as always. This closes out the long division
bracket's shape/position work for now — no open questions on it as of
v36.

### Recently built (v27) — Challenge Tests intro paragraph reworded

`ChallengesPanel`'s intro now reads: "A Challenge Test is for students
who know their times facts really, really well. It lets you jump
ahead straight to an important step instead of learning and passing
the ladder one number at a time. Pass it with every answer right, and
you win that title AND every number below it — no extra practice
needed." (was: "A Challenge Test lets you jump straight to a step
instead of climbing the ladder one number at a time. Pass it with
every answer right, and you win that title AND every number below it
— no extra practice needed.")

### Recently built (v25-v26) — Challenge Tests tab, full feature

New third tab, backend + UI + a shared chain-walk bugfix. See the
dedicated "Challenge Tests" section above for the full design — this
entry is just a pointer so it's not missed among the version-history
entries below.

### Recently built (v24) — Quizzes intro note: reworded, standard spacing

Reordered the clauses in the Quizzes intro note (added in v23): "...between the numbers you pick, Start to End, in the Range part below." (was: "...in the Range part below, from Start to End."). Also bumped the spacer after it from 18px to the standard 36px used between all other sections.

### Recently built (v23) — Quizzes/Ladder default swap, shared Range component split, new Quizzes intro note

- **Default tab + order flipped**: app now opens on Ladder by default (`activeTab` initial state `"quizzes"` → `"gradient"`), and the tab-toggle buttons are reordered so Math Wiz Ladder is first/left, Quizzes second/right (`app.jsx`).
- **New Quizzes intro note**, added as the very first line of `QuizzesPanel` (mirrors where Ladder's own intro sits): "Want extra tough practice? This page asks every question between the numbers you pick, in the Range part below, from Start to End." Went through several wording rounds this session — landed on "between the numbers you pick" (not "for all the numbers") and "asks every question" (not "ALL possible questions") specifically to read easier for younger students.
- **`RangeSection` (shared by both tabs) split behavior via a new `showTitleNote` prop** (default `true`, so Ladder's call site is unaffected without changes there): the "Custom range End other than 10/12/20 → practice only, no new title" note only applies to Ladder — Quizzes never grants titles/mastery at all regardless of Range, so showing that note there was actively misleading. Quizzes' call site now passes `showTitleNote={false}`.
- **Custom range's "APPLY" button renamed to "SET RANGE"** and given a highlighted state (gold border + text, `#E8B94A`, the app's existing accent color) whenever the typed Start/End differ from the currently-active range — a visual nudge on top of the clearer label, since the button is easy to forget to press otherwise. Reverts to neutral once pressed or once the fields are changed back to match the active range.

### Recently built (v22) — Guide button wider, Levels note reworded, diamond icon +10%

- Guide button (`app.jsx`, top nav) widened 20%: `minWidth: 90` → `108`. Padding and font untouched — the button was already sized by `minWidth` alone (content didn't need more), so this was the only change needed.
- Levels page's explanatory note reworded and shortened: removed both uses of "double" (the two-pass system it referred to was already removed in v18). New text: "A title means you have passed every number step up through that level. Anytime you do a full pass on a number you own the number. When you have done a full pass on all the numbers below and through a number level, then you get that title." (Old text also had a sentence about "the first gap sets your title on the one before the gap" — dropped, not part of the new wording.)
- Diamond icon size: see the "Known issue, accepted tradeoff" note above.

### Recently built (v21) — spacing fixes, four wording tweaks

### Recently built (v21) — spacing fixes, four wording tweaks

Two real spacing bugs, found by measuring actual rendered gaps via Playwright rather than reasoning about CSS margin-collapse by hand (which is how the v20 "fix" ended up wrong in two places):
- The gap below the Quizzes/Math-Wiz-Ladder **tab-toggle buttons** (top of the settings panel, `app.jsx`) was still 18px, not 36 — fixed. (Note: "Quizzes and Ladder Buttons" in the user's report meant this tab toggle, not the Start-Quiz/Scores-History pair at the bottom of each panel — those were already correctly ≥36px, confirmed by measurement.)
- The gap **above the Speed section** in the Ladder tab (when a number is previewed) was only 18px, not 36 — the v20 fix had moved the leading spacer to only 18px while also zeroing the preceding paragraph's own margin, net effect 18 instead of 36. Fixed by using a 36px spacer directly, in both the with-preview and without-preview-selected code paths (previously the no-preview path had no leading spacer logic at all before Quiz Length).
- Also fixed: Quizzes tab's Scores-History→Save-Backup-File gap measured 46px (backupRow's own `marginTop:10` was stacking on top of the intended 36px spacer, uncollapsed since a real spacer div sat between them) — zeroed backupRow's marginTop at this call site so the explicit spacer is the sole source of that gap.

**Wording** (four changes):
- Ladder "In Order" note: reordered the two clauses — "If you leave settings the same, and Quiz Length is less than the All length below, this app will start..." (was: Quiz-Length clause first, "leave settings the same" second)
- Operation section suggestion note: "A good idea is for each Type of Questions, do Multiply, then Divide, then Both." (was: "Suggestion: for each Type of Questions level, do Multiplication, then Division, then Both.")
- Speed section caption: "...Fastest has shorter times and no repeated questions." (was: "...and no repeats.")
- Range section's custom-end warning: "...you are playing for practice and can get yellow icons but no new title." (was: "...you are playing for temporary status and can get yellow icons.")

### Recently built (v20) — Section spacing standardized to 36px, new faceted diamond icon, wording tweak

**Spacing**: every section-to-section gap in both Quizzes and Ladder tabs is now 36px (Section's own 18px `marginBottom` plus an explicit 18px spacer div), replacing the mix of 18px/36px/6px gaps that existed before. Specifically: added spacers between every section in QuizzesPanel (previously had none — relied on the bare 18px); added the missing Range→Exclude Easy spacer in Ladder; removed SpeedSection's custom `style={{marginTop:10,marginBottom:6}}` override in Ladder (was fighting the standard spacing); bumped two paragraph `marginBottom`s from 16/10 to 18 (the "will give ALL questions" note and the "New Facts Only" note) so they collapse cleanly into the 36px rhythm. Also added a 36px gap after the Start/Scores-History button pair in both tabs (before the backup-file row in Quizzes; as trailing space in Ladder).

**Diamond icon**: replaced `DIAMOND_IMG` in components.jsx with a newly-drawn faceted version (8 facets: 3 upward + 2 downward-pointing crown facets, 3 pavilion facets, vs. the old ~5-facet design), same amber/gold palette family with interpolated in-between shades, one sparkle accent (traced from a user-provided reference, flipped horizontally, on the lower-left pavilion facet). Old design is fully described in this session's history if it ever needs reconstructing — was a simpler outline (`M2,5 L5,2 H11 L14,5 L8,15 Z`-based) with a single carved-out white sparkle triangle.

**Diamond sizing**: the diamond icon's rendered height now targets the cap-height of the "Royal" title text it sits beside (measured via canvas font metrics, not guessed): `size="0.9em"` at both real occurrences — `setup.jsx` Levels-list row (14px title text, target cap-height 10px) and `components.jsx` `TitleWithIcon`'s diamond branch (13px title text, target cap-height 9px), both landing within ±1px. Was `1.26em`/`1.36em` respectively. The `MilestoneButton` component's `TitleWithIcon` call was NOT touched — `milestoneFor()` never returns a "Royal" title, so that path never actually renders a diamond; changing it would've been a no-op on dead code. The Ladder screen's number-grid badge diamond (`size="1.8em"`, not paired with title text) is also unchanged/out of scope.

**Wording**: Ladder intro copy changed from "Pass Type In · Random with zero misses to unlock the next number." to "Pass Type In · Random with all answers correct to unlock the next number."

### Recently built (v19) — Ladder section reorder + "Mode"→"Type" wording pass

**Ladder tab section order** changed to match the Quizzes tab's flow more closely. Old order: Number grid → Range → Exclude Easy → Practice Facts → (Questions Mode + Speed, in the per-number preview block) → Operation → Quiz Length. New order: Number grid → Range → Exclude Easy → **Operation** → **Questions Mode preview block** (header/notes/mode-picker/"will give ALL questions" note) → **Practice Facts** → **Speed** (now its own conditional block, gated on `previewNumber != null` same as before, but no longer bundled with Questions Mode) → Quiz Length → Start/History. Note Speed used to live inside the same `{previewNumber != null && ...}` block as Questions Mode; it's now a separate block with the same condition, just relocated after Practice Facts.

**Wording — "Mode" replaced with "Type" everywhere it's user-facing** (code identifiers like `selectedMode`, `answerMode`, `runMode` etc. are unchanged, this is copy-only):
- `Section label="Math Operation"` → `"Math Types"` (OperationSection, shared by both tabs)
- `QuestionsModeSection`'s default `label` param: `"Questions Mode"` → `"Type of Questions"` (this default isn't actually rendered anywhere currently — both call sites override or hide it — but kept in sync)
- Quizzes tab's label override: `"QUESTIONS MODE - EASY TO HARD"` → `"TYPE OF QUESTIONS - EASY TO HARD"`
- Ladder tab's inline preview header (built manually, not via the label prop): `"{previewNumber}s — QUESTIONS MODE - EASY TO HARD"` → `"...— TYPE OF QUESTIONS - EASY TO HARD"`
- `OPERATION_SUGGESTION_NOTE`: "for each **Questions Mode** level..." → "for each **Type of Questions** level..."
- `QUESTIONS_MODE_NOTE`: "The In Order **modes** remember your place..." → "The In Order **types** remember your place..." (kept plural "types" to agree with plural "In Order modes/types", not literal singular "type")

**To revert either piece**: the section order is a JSX reordering only (no logic changed) — move the `OperationSection` call and the `previewNumber`-gated Questions-Mode block back down below `ExcludeEasySection`+warning and above `QuizLengthSection`, move `Section label="Practice Facts"` (+ its subtitle) back up to right after the warning block, and move `SpeedSection` back inside the Questions-Mode block. The wording is five string literals, all listed above with old→new.

### Recently built (v18) — two-pass mastery system removed entirely

Decision made (after the discussion recorded below, now superseded): remove the two-consecutive-passes requirement. Mastery is now granted on a single 100%-first-try pass. Explicitly RIPPED OUT, not commented out in place — restoration should be done from this changelog entry, not by uncommenting anything.

**Logic (app.jsx)**: the mastery-attempt handler no longer counts a streak. Old shape: on a 100% pass, increment `ladder.streak`; only grant mastery (advance to next number, add to `mastered`/`masteredEnd`/etc.) once `streak >= 2`, otherwise just save the incremented streak and show a "one more clean run" banner; on any non-100% pass, reset `streak` to `0`. New shape: on a 100% pass, immediately do everything the old `streak >= 2` branch did (grant mastery, advance, banner `{ mastered: true, ... }`); on a non-100% pass, just show `{ mastered: false, missed: true }` with no state update at all. `ladder.streak` is gone from `DEFAULT_LADDER` (logic.js) and from every place that used to reset it: the range-change self-heal effect (app.jsx, was `{ ...prev, currentNumber: nextCurrent, streak: 0 }`) and `onSetLadderTrack` (was `{ ...prev, currentNumber: n, streak: 0, lastMode: "mc-seq" }`).

**UI states removed** (all were driven by `streak === 1`, now unreachable since mastery fires on the first pass):
- The green "one clean pass" shield-with-"1" badge on the ladder grid (canonical/real path) — was `<ShieldBadge fill="#46AB68" numeral="1" />`, shown when `isCurrent && ladder.streak === 1`.
- The yellow/gold outlined version for the temp/short-range path — was `<ShieldBadge fill={YELLOW} outline numeral="1" active={isPreviewed} />`, gated by a `tempOne` flag (`isCurrent && ladder.streak === 1 && !isCanonicalEnd(settings.end)`). The sibling `tempCurrentZero` flag (the "temp, but not yet one pass" triangle state) is renamed `tempCurrent` and simplified to drop the streak condition entirely (`isCurrent && !isCanonicalEnd(settings.end)`) — it's now just "temp and current," full stop.
- Two Buttons-tab gallery rows demonstrating the above: `{ label: "One clean pass", n: 6, badge: "one" }` and `{ label: "Short-range one pass", n: 9, badge: "tempOne" }`, plus their corresponding render branches in `BadgeGallery`'s `renderCell` (`style.badge === "one"` → green shield+"1"; `style.badge === "tempOne"` → yellow outlined shield+"1").
- The inline ladder-preview banner: `"One clean pass down — one more perfect Type In · Random run masters the {previewNumber}s!"` (gold, shown when `previewNumber === ladder.currentNumber && ladder.streak === 1`).
- The quiz-complete gold box's middle branch: was `mastered ? "...mastered!..." : missed ? "Streak reset — give the {N}s another go." : "Perfect pass! One more clean run masters the {N}s."` (three branches, keyed on `ladderResult.streakNow`/`.missed`) → now two: `mastered ? "...mastered!..." : "Not quite — give the {N}s another go."`. `banner.streakNow` no longer exists.

**Copy changed** (both now accurately describe a single-pass system):
- Ladder screen intro: "Learn one number at a time. Pass Type In · Random with zero misses, **twice in a row**, to unlock the next number." → "...with zero misses **to unlock the next number**." (the "twice in a row" clause removed outright, not reworded).
- Ladder preview panel: "Type In · Random will give ALL questions for that number, **twice**, to pass — both Multiply and Divide." → "...will give ALL questions for that number — both Multiply and Divide — **to pass**." Note: this "twice" was genuinely about the two-pass system (confirmed after initially misreading it as being about operation coverage — a single attempt always covered both operations already, one time each; that part of the sentence was unrelated to the count).

**To restore this system**: re-add a `streak` counter to `DEFAULT_LADDER`; in the mastery handler, gate the grant-mastery branch on `newStreak >= 2` (where `newStreak = (ladder.streak||0)+1`) instead of `percent === 100` alone, with an else-branch that saves the incremented streak and returns `{ mastered: false, streakNow: newStreak }`; reset `streak: 0` in the two switching-effects and on a missed pass; reinstate the `tempOne`/`isCurrent && streak===1` badge branches, the two gallery rows, the inline preview banner, the gold box's three-way branch, and the "twice in a row" / "twice" copy — all given verbatim above.

## Two-pass mastery system — discussion that led to the v18 removal above (kept for context, decision already made, nothing further to act on)

Key findings from the discussion, preserved for context:
- The original assumption (both user's and mine) was that "lucky guessing" is what the two-pass requirement guards against. That's wrong at this quiz length — with 29–59 typed questions per mastery attempt (see the per-number counts below), guessing your way to 100% is essentially impossible. That justification doesn't hold.
- The mechanic as built: `ladder.streak` was a SINGLE shared field (not per-number), incremented only while `isCurrent`, and reset to 0 by `onSetLadderTrack` on ANY switch of the current number — including switching back to a number that already had one pass. So "one clean pass, come back later and finish it" — which is what the user originally expected/wanted — did NOT work: switching away and back wiped it, even across sessions where the app was closed and reopened (as long as the current number changed in between).
- Remaining honest justification was "tests retention, not relearning" — but this too was weakened by the fact that passing 29–59 questions cleanly already requires sustained focus, not just knowledge; requiring it twice, immediately, with zero tolerance for a single miss or an unrelated interruption wiping the first pass, arguably tested attention span/luck-of-timing as much as it tested mastery.
- Two options had surfaced: (1) remove the two-pass requirement entirely — one clean pass = mastery (chosen, see v18 above); (2) keep two passes, but make progress persist per-number instead of resetting on any switch. Option 2 was not pursued.
- Exact mastery question counts, for reference (computed directly from `masteryTestPool`, not estimated): End=10 → 29 questions (any number, Exclude Easy off) or 23–24 (on); End=12, Exclude Easy on → 29–30; End=20, Exclude Easy off → 59 (every number 1–20 alike); End=20, Exclude Easy on (which Auto-applies once Start&gt;10, e.g. viewing the 11–20 range) → 53–54. Every number within a given End/ExcludeEasy combo gets essentially the same count (±1 for whether the number equals one of its own partners). Verified live end-to-end after the v18 build: a single 29/29 clean pass on the 1s immediately produced "1s mastered! Next up: the 2s." — confirmed with actual browser automation, not just code review.

Total distinct fact families 1×1 through 20×20 (unordered, i.e. 3×4 and 4×3 counted once): 210 (20 squares + C(20,2)=190 non-square pairs). Multiplication+division combined, unique families: 610 (210 mult + 400 div, where the 190 non-square families contribute 2 division facts each and the 20 squares contribute 1 each).

### Recently built (v17)

- **Backup-note spacing**: the "This is for saving history..." note under the backup buttons was crowding them (`sectionNote`'s `-2px` top margin). Rather than inventing a one-off value, copied the exact spacing already proven to work for the Range section's note-after-buttons (`{ ...s.subtitle, marginTop: 10, marginBottom: 0 }`).
- **Ladder non-current-step banner reworded**: "This isn't your current ladder step. Practice here is free, but won't count toward a pass unless you move the current ladder step to here." (was "...won't count toward mastery unless you move the ladder step here.") — "mastery" → "a pass" per discussion that the two-pass system may be revisited (since resolved — see the v18 entry above).
- **Pill border → 2px**: added to `MilestoneButton` itself (was inheriting `1px` from `s.segBtn`'s shorthand, never overridden), so every pill everywhere — Levels page, both milestone pills, Buttons-tab mockup, the real ladder — now has the same 2px border as the "Mastered"-style buttons.
- **Buttons-tab mockup pill height pinned to match "10s"**: was 40.7px vs "10s"'s 35px, from two stacked causes — the pill inherited `9px` padding vs "10s"'s `8px` (2px), and the pill's icon (~17.7px) is taller than a plain text line (~15px), so the flex row's height followed the icon (~2.7px). Patching padding/font-size to indirectly land on 35 would've been fragile against future icon-size changes, so instead `MilestoneButton` gained an optional `style` prop (merged last, so it can override anything) and this one call site passes `{ height: 35, display: "flex", alignItems: "center", justifyContent: "center", padding: "0 10px" }` — pinned exactly, not approximated. Scoped to just this instance, not all pills, since matching "10s" is only meaningful where they sit side by side.
- **`numberFieldLabel` unified**: 11px/0.45 → 13px/0.55, matching the other notes. Affects the "Start"/"End" labels (Custom range) and "Questions" (Custom quiz length), "Answer time threshold (seconds)" (Teacher Settings).
- **`previewNote`** (dev-preview gold banner) — decided to KEEP as-is, gold, not unified. Same category as the streak/error messages: a functional state signal, not a passive explanation.

### Recently built (v16)

- **Crown and Diamond artwork replaced**: `CrownIcon` and `DiamondIcon` (components.jsx) no longer draw flat inline SVG paths — they now render a small `<img>` of hand-picked/edited artwork, base64-embedded directly in the file (`CROWN_IMG` / `DIAMOND_IMG` constants). Crown source: a gradient-gold crown photo with a custom-drawn faceted ruby centered on it (~1.3x its original planned size, vertically centered on the crown). Diamond source: a custom-drawn faceted gem that reuses the ORIGINAL flat icon's exact outline path (`M2,5 L5,2 H11 L14,5 L8,15 Z`) with facet shading added, brightened twice, left-side facets (upper + lower) darkened 10% for a light-from-the-right look. Both were built and iterated as standalone PNGs first, checked against actual Playwright screenshots at real in-app pixel sizes (not just eyeballed at full-res), before embedding. Sizing: every call site keeps its original `size` prop (em value) unchanged, so rendered WIDTH at each of the 5 spots (Levels rows 15–19, row 20, the two milestone pills, and the username bar) is identical to before; rendered HEIGHT differs slightly since the new artwork's aspect ratio isn't identical to the old flat SVG's viewBox. `objectFit: "contain"` on the `<img>` reproduces the old SVG's letterboxed/centered scaling behavior. Embedded PNGs were downsized before base64-encoding (crown to 240px wide, ~37KB; diamond already small, 128px, ~3.7KB) rather than embedding the full-resolution master, to keep the HTML file size reasonable given these only ever render at 17–35px.

- **Crown and Diamond artwork replaced**: `CrownIcon` and `DiamondIcon` (components.jsx) no longer draw flat inline SVG paths — they now render a small `<img>` of hand-picked/edited artwork, base64-embedded directly in the file (`CROWN_IMG` / `DIAMOND_IMG` constants). Crown source: a gradient-gold crown photo with a custom-drawn faceted ruby centered on it (~1.3x its original planned size, vertically centered on the crown). Diamond source: a custom-drawn faceted gem that reuses the ORIGINAL flat icon's exact outline path (`M2,5 L5,2 H11 L14,5 L8,15 Z`) with facet shading added, brightened twice, left-side facets (upper + lower) darkened 10% for a light-from-the-right look. Both were built and iterated as standalone PNGs first, checked against actual Playwright screenshots at real in-app pixel sizes (not just eyeballed at full-res), before embedding. Sizing: every call site keeps its original `size` prop (em value) unchanged, so rendered WIDTH at each of the 5 spots (Levels rows 15–19, row 20, the two milestone pills, and the username bar) is identical to before; rendered HEIGHT differs slightly since the new artwork's aspect ratio isn't identical to the old flat SVG's viewBox. `objectFit: "contain"` on the `<img>` reproduces the old SVG's letterboxed/centered scaling behavior. Embedded PNGs were downsized before base64-encoding (crown to 240px wide, ~37KB; diamond already small, 128px, ~3.7KB) rather than embedding the full-resolution master, to keep the HTML file size reasonable given these only ever render at 17–35px.
- **Levels number-column brightness**: resolved the long-open question — numbers now `#EDEAE0` (full-opacity cream), up from the dim `rgba(...,0.55)` note color. This is on `numStyle`, which is ALSO spread by the header's "Number" label — that label got an explicit color override back to the dim note color so only the actual data-row numbers brightened, not the header.
- **READY/TAPPED headers**: were already fixed to the dim note color in the v14 pass, but the font-size bump to 13px got missed at the time — done now.
- **`sectionNote` style unified**: 11px/0.45 → 13px/0.55, matching the other notes. Affects two spots: the "Suggestion: for each Questions Mode level..." text under Math Operation, and "This is for saving history and settings..." under the backup buttons.

### Recently built (v14)

- **Levels header positioning, decoupled from data rows**: header "Number" and "Title Won" now move independently of each other and of the data rows below (confirmed: they don't need to stay pixel-aligned with the data rows — "cannot stay perfectly aligned and have it all work best"). Header "Number" moved right 1 char (own `marginLeft: -16`, was sharing `numStyle`'s -24 with the data rows). Header "Title Won" moved left 1 char net from where it rendered before (`marginLeft: -16` added on top of the reduced cascade from Number's change). Data rows (`numStyle`, used only by `row()` now) originally stayed at `marginLeft: -24` here — recalibrated again in v15 (see below), since -24 read as only ~2 characters of movement, not 3.
- **Levels milestone pill width**: all Levels-page pills (`row()`'s `MilestoneButton` call) now share `minWidth={150}` (was 80) so shorter titles like "Math Wiz!" render the same width as the longest ("Senior Math Wiz 12") instead of looking inconsistently sized. This is an estimate, not pixel-verified against a live render — flag if it needs adjusting either direction.
- **Senior Math Wiz 12 responsive break**: on screens ≥481px, forces a break after "Senior" (badge + "Senior" on line 1, "Math Wiz 12" on line 2) via a pure-CSS media query (`globalCss` in styles.js: `.tt-senior-narrow` / `.tt-senior-wide` classes, toggled at the same 481px breakpoint mentioned elsewhere for the phone-pill-overlap fix). Below 481px, the title renders as plain text and wraps however the browser naturally does — unchanged phone behavior. Implemented via a new `textNode` prop on `TitleWithIcon` (renders in place of `title.toUpperCase()` when passed) so this is isolated to the "Senior Math Wiz 12" case in `MilestoneButton` and doesn't touch any other title's rendering, including the username bar's own `TitleWithIcon` call (which already forces `whiteSpace: "nowrap"` and was never affected by this bug).
- **Buttons-tab final pill row**: reworked to fix a word-wrap regression from the v13 grid-alignment fix (the "Math Wiz!" pill was being flex-shrunk to fit inside the left grid column, forcing it to wrap). Now: the "10s" button alone sits in a normal centered flex box matching the READY column's own centering exactly (same mechanism as `renderCell`), and the pill+caption block is `position: absolute` anchored to the button's right edge (`left: 100%, marginLeft: 8`) — same 8px gap as before. Because it's absolutely positioned, the pill can't affect the grid's column-track sizing and always renders at its natural, unshrunk width (no `allowShrink` on this specific call, unlike the Levels-page and previous Buttons-tab calls — this one should never shrink/wrap). Gallery captions and this pill's caption bumped 11px→13px (see note unification below).
- **"Move the ladder step here" wrap bug**: the inline button now has `display: "inline"` (was defaulting to the browser's `inline-block` for `<button>`), so it wraps mid-phrase like normal text instead of jumping as a whole atomic unit to the next line when it doesn't fully fit.
- **Questions Mode note text** (`QUESTIONS_MODE_NOTE`) reworded: "The In Order modes remember your place. If Quiz Length is less than the All length below, and you leave other settings the same, this app will start next time right where you left off, after the last finished quiz!"
- **Note-style consistency pass** (accessibility-driven — user has low vision, wants readable, consistent secondary text): unified READY/TAPPED headers, Levels' "Number"/"Title Won"/"Important Levels" headers, and the Buttons-tab gallery/pill captions to the same plain note style as "New Facts Only skips..." — `fontSize: 13`, color `rgba(237,234,224,0.55)`, no bold. Previously these varied: headers were 12–13px bold at 0.6–0.75 opacity, captions were 11px at 0.55. Explicitly EXCLUDED from this unification, kept as their original distinct colors on purpose: the gold "one clean pass" encouragement message and the red password-error messages (both are meaningful-color signals, not passive explanatory notes) — and the small muted `APP_VERSION` label (explicitly told to leave as-is). If any Buttons-tab caption needs reverting to its old look: original was `fontSize: 11`, same color `rgba(237,234,224,0.55)` as now (only the size changed, color was already correct).

### Recently built (v15) — fixes to four v14 regressions, found via live Playwright rendering rather than guessed blind

- **Buttons-tab pill still wrapped to 2 lines despite "lots of room"**: root cause was the absolutely-positioned pill block being anchored via `left: 100%` to a ~92px-wide positioned ancestor (the "10s" button's own wrapper). Per the CSS spec, when only `left` is set on an absolutely positioned element (no `width`, no `right`), the shrink-to-fit width calculation's "available space" is measured from that small containing block, not the actual empty page space — so it was clamping to a near-minimum width and wrapping, even though there was visibly tons of room on the page itself. Fixed with `width: "max-content"` on that div. This also uncovered a second issue: taking the pill out of normal flow meant its height was no longer reserved by its container, so it started overlapping the "Back" button below it — fixed with `paddingBottom: 30` on the row's outer grid container.
- **Math Wiz! pill not matched to Senior pill's width**: root cause was `MilestoneButton` spreading `s.segBtn`, which carries `flex: "1 1 auto"` (flex-grow: 1) — nothing ever reset flex-grow back to 0, so every pill was silently growing to fill whatever space was left over in its own row after that row's own title text, meaning pill width varied per-row based on unrelated content (a short row title left more room for its pill to grow into, so the SHORTER-titled row's pill could render WIDER). Fixed with an explicit `flexGrow: 0` in `MilestoneButton`'s style, combined with the shared `minWidth={150}` from v14 — confirmed both pills now render identically.
- **Data rows still only looked like a 2-character shift, not 3**: the original ~8px/char estimate undershot. Recalibrated `numStyle`'s `marginLeft` from `-24` to `-36` for the data rows (header is unaffected, already decoupled in v14). Still an estimate calibrated from feedback, not a measured character width — flag if still off.
- **Levels row-title wrap for milestone rows**: for the 5 actual milestone ("milepost") rows — 5, 10, 12, 15, 20 — where the title's first word isn't "Math" (Junior/Senior/Crown), the row now splits that first word into its own flex item so it wraps together with the badge on line 1, with only the remaining words dropping to line 2 (`splitFirst` in `row()`, setup.jsx). Titles starting with "Math" ("Math Wiz!", "Math Wiz King") are untouched — the whole thing still drops below the badge as before, matching the request ("if the first word is not Math..."). Scoped specifically to milestone rows via `!!milestoneTitle` — an early pass wrongly applied this to every row (6–9, 11, 13–14, 16–19 too), adding an unwanted extra gap after the first word on rows that never needed it; caught and corrected before shipping via a live screenshot comparison.
- All four fixes above were verified against actual Playwright-rendered screenshots (desktop ~1200px and mobile ~390px) before shipping, not just reasoned about — worth doing this for future visual bug reports on this project given how many of these turned out to have non-obvious root causes (flex shrink-to-fit measured against a tiny containing block, `flex-grow` leaking through a spread shorthand). Playwright with a Chromium browser is available in the container for this.

### Recently built (v35)

- **Long division bracket, raise dialed way back**: a screenshot
  showed the v34 raise (`top: "-0.25em"`, vertical line `1.4em`,
  dividend `paddingTop: "0.1em"`) put the bracket much too far above
  the digits — a large empty gap, not a tight hook right above them.
  Reduced to `top: "-0.08em"`, vertical line `1.2em`, dividend
  `paddingTop: "0.03em"`; horizontal line's 1.5×-vertical minimum
  recalculated to `1.8em` (1.5 × 1.2em) to match. **Not visually
  confirmed on this end** — there's no browser in this environment to
  render-check against, so this is a best-effort read of the
  screenshot's proportions; flag it again if the gap still isn't
  right and it can be dialed in further.

### Recently built (v34)

- **Long division bracket, raised layout**: divisor and dividend are
  now baseline-aligned in one line (`alignItems: "baseline"` on the
  outer flex, instead of `"flex-start"`), and the bracket itself (both
  lines) is raised above the tops of the digits — anchored at
  `top: "-0.25em"` instead of flush with the box top. The vertical
  line's height was bumped to `1.4em` (from `1.15em`) so, even
  starting higher, it still reaches down to the bottom of the
  dividend. The dividend has a small `paddingTop: "0.1em"` pulling it
  close under the horizontal line without crossing it. The 1.5×
  multiplier for the horizontal line's minimum length was recalculated
  against the new vertical line height: `2.1em` (1.5 × 1.4em, up from
  1.725em/1.15em) — same "50% longer than vertical, or as long as the
  dividend, whichever is longer" rule, just re-based on the new
  vertical length. Settings-preview version kept in sync as always.

### Recently built (v33)

- **Fraction bar length**: was a fixed `1.3em`; now
  `${Math.max(digitsInDividend, digitsInDivisor)}ch` — `ch` is exact
  monospace digit width in this font, so the bar now matches the width
  of whichever number (dividend or divisor) has more digits, instead
  of being a fixed width regardless of the numbers shown.
- **Long division bracket, horizontal-line length**: the bracket is
  now built from two independent, absolutely-positioned lines (instead
  of relying on a box's border-top, which was really just "however
  wide the padding made the box") — a vertical line fixed at `1.15em`
  tall, and a horizontal line at `max(1.725em, ${digitsInDividend}ch)`
  — 1.725em is exactly 1.5× the vertical line's height, so the
  horizontal line is now genuinely "50% longer than the vertical line,
  or as long as the dividend, whichever is longer," using CSS `max()`
  to pick between the two different units (em vs ch) at render time.
  Same shape in both the live quiz question and the Division Symbols
  settings preview, kept in sync as always.

### Recently built (v32)

- **Long division bracket, drawn instead of glyph**: the ⟌ Unicode
  character is gone. It's now an actual CSS bracket — a `borderLeft` +
  `borderTop` box wrapping the dividend, positioned right after the
  divisor with no extra gap, so the dividend sits tucked right under
  the horizontal rule and hugging the vertical line at the top-left
  corner, matching how it looks on paper. Same shape used both in the
  live quiz question (`quiz.jsx`) and the Division Symbols settings
  preview (`setup.jsx`) — kept in sync deliberately, not just one.
- **Fraction bar, one solid piece**: was a `borderTop` line (which can
  show a faint anti-aliasing seam in some browsers); now a solid
  filled block (`background: currentColor`, explicit height) — a
  guaranteed continuous bar, no seam possible. Same fix in both the
  live quiz question and the settings preview.
- **Obelus (÷) and Slash (/) spacing tightened**: these were rendered
  with a literal space text-node on each side of the symbol, which at
  the question's large monospace font size reads as a wide gap.
  Replaced with a single tight `margin: "0 0.2em"` on the symbol span,
  with no literal-space text nodes at all. Multiply ("×") is
  deliberately untouched — kept on its own original-spacing branch,
  since this request was specifically about the two divide symbols.

### Recently built (v31)

- **Teacher Settings "Answer time threshold" is now truly global**:
  previously it read/wrote whichever tab-local settings object hosted
  the field (`quizSettings`, then `ladderSettings` after the v30 move)
  — a different object than the one gameplay actually reads
  (`globalSettings.slowThresholdSeconds`), so it never really did
  anything. Added `patchGlobalSettings`, and the field on the Ladder
  tab now reads/writes `globalSettings` directly. Confirmed this
  correctly feeds Fast/Fastest too, since both derive from the same
  base (`effectiveThresholdSeconds = fastPaced ? base/2 : base`).
- **Divide Symbols**: new "Division Symbols" section on the Quizzes
  and Ladder tabs (right below Math Types/Operation, not on Challenge
  Tests — it has no Operation choice of its own), four checkboxes —
  Obelus (÷, default/only one on by default), Slash (/), Fraction bar,
  Long division bracket (⟌) — each showing a live 6-and-2 example.
  Multiple checked → one is picked at random per division question
  (multiply questions are untouched, always "×"). New
  `divideSymbols: ["obelus"]` default field on `DEFAULT_QUIZ_SETTINGS`
  and `DEFAULT_LADDER_SETTINGS`; Challenge Tests has no setting of its
  own for this and always uses the default (obelus only), consistent
  with it having no Operation-choice UI either. The symbol is picked
  once per question (`useMemo` keyed on `current.id`, which every
  fact — original or repeat — always has) so it doesn't change/flicker
  while the same question is on screen; a repeat of the same fact gets
  an independent random pick, same as any other question. Long
  division bracket renders divisor-then-bracket-then-dividend
  (`{b}⟌{a}`), matching standard notation; fraction bar is a real
  stacked layout (dividend over divisor with a rule between), not a
  string. The missed-facts history log text is untouched — it always
  logs the canonical "÷", regardless of which symbol was shown.

### Recently built (v30)

- **MC answer choice font size**: 19px → 21px (`choiceBtn` in styles.js).
- **"Correct" feedback text** → all caps: **"CORRECT"**.
- **Backup and Teacher sections moved** from the bottom of the Quizzes
  tab to the bottom of the Math Wiz Ladder tab, since Ladder is now
  the main section. `onExport`/`onImport` props moved from
  `QuizzesPanel` to `LadderPanel` accordingly; the `fileRef`/
  `teacherUnlocked`/`teacherModalOpen` local state moved with the JSX.
  Quizzes tab no longer has a Backup/Teacher block at all.
  **(RESOLVED — verified Oct 2026: the field now reads/writes
  `globalSettings.slowThresholdSeconds`, the same setting the quiz uses.)**
  **Note for a future item, not fixed here**: the Teacher Settings
  "Answer time threshold" field reads/writes `settings.slowThresholdSeconds`
  — i.e. now `ladderSettings.slowThresholdSeconds` — but the actual
  threshold used everywhere in the app (`app.jsx`) reads from
  `globalSettings.slowThresholdSeconds`. These are two different
  settings objects, so this field appears to have never actually
  changed the real threshold, regardless of which tab it lived on.
  Flagged, not touched, since it wasn't part of this build's scope.

### Recently built (v29)

- **Speed section added to Challenge Tests**: previously Challenge Tests had no visible speed control at all and silently inherited whatever `speedMode` was last set on the Quizzes tab — not a deliberate choice, just an oversight in how `activeSettings`/`activeSpeedSettings` picked a settings object by `runMode.kind`. Added a new minimal `DEFAULT_CHALLENGE_SETTINGS` (Speed only — Challenge Tests has no Range/Operation controls of its own, the pool is fixed by the level chosen), its own `challengeSettings` state, persisted and loaded the same way as quiz/ladder settings, and a `patchChallengeSettings`. The Speed section (Normal/Fast/Fastest) now renders on the Challenge Tests tab right after the challenge-level choice buttons — placement requested explicitly, not the same position as on Quizzes/Ladder (which put it earlier, before Range). All three `runMode.kind === "ladder" ? ladderSettings : quizSettings` speed-derivation sites (history-entry logging, repeat-scheduling, submit-answer timing) updated to a three-way check that also picks `challengeSettings` for `runMode.kind === "challenge"`.

### Recently built (v28)

- **Quizzes intro**: "asks every question" → "asks EVERY question", for
  emphasis. (v27 had instead capitalized "every" in the CHALLENGE
  TESTS intro, to match that intro's existing "AND" emphasis — that
  was reverted in this build; the Challenge Tests intro's "every" is
  back to lowercase, as it originally was. Only the Quizzes intro's
  "every" is capitalized now.)

### Recently built (v27)

- **Slow-but-correct repeat labels fixed**: previously showed "Repeat"
  on both the reveal screen and the immediate repeat question — wrong,
  since "Repeat" is supposed to mean a later, delayed re-insert.
  Slow-but-correct now shows "Will repeat" (reveal) then "Repeating"
  (immediate repeat), matching a wrong answer's first two stages, and
  never escalates further no matter how many times in a row it's slow
  — only a wrong answer ever earns the later delayed "Repeat". See the
  "Repeat-scheduling logic" section above for the corrected design;
  the old `repeatFlag` state was removed and folded into `willRepeat`.
- **Challenge Tests intro**: "and every number below it" → "and EVERY
  number below it", matching the existing "AND" emphasis already in
  that sentence. (Reverted in v28 — see above.)

