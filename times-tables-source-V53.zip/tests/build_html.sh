#!/bin/sh
# Build one version's single-file HTML. Usage: sh tests/build_html.sh SRC_DIR VERSION OUT.html
# (v51) Used by run_all.sh; needs esbuild (npm install in SRC_DIR or this dir).
set -e
DIR="$1"; VER="$2"; OUT="$3"
ESB="$(dirname "$0")/../node_modules/.bin/esbuild"
[ -x "$ESB" ] || ESB="npx esbuild"
# v51: stop if APP_VERSION (app.jsx) doesn't match the version being built
# (V51 first shipped still labeled v50). "prev" builds skip the check.
if [ "$VER" != "prev" ] && ! grep -q "const APP_VERSION = \"v$VER\";" "$DIR/src/app.jsx"; then
  echo "APP_VERSION in src/app.jsx is not v$VER — bump it first"; exit 1
fi
TMP="$(mktemp -d)"
$ESB "$DIR/src/index.jsx" --bundle --minify --format=iife --jsx=automatic --log-level=warning --outfile="$TMP/bundle.js"
{
  printf '<!doctype html>\n<html lang="en">\n  <head>\n    <meta charset="UTF-8" />\n'
  printf '    <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n'
  printf '    <meta name="robots" content="noindex" />\n    <title>indexV%s</title>\n' "$VER"
  printf '    <style>\n      html, body, #root { height: 100%%; margin: 0; }\n    </style>\n  </head>\n'
  printf '  <body>\n    <div id="root"></div>\n    <script>\n'
  cat "$TMP/bundle.js"
  printf '\n    </script>\n  </body>\n</html>\n'
} > "$OUT"
rm -rf "$TMP"
