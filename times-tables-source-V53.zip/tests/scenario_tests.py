#!/usr/bin/env python3
"""Saved scenario tests (Playwright) — behavior not visible on one screen:
repeats, In Order place, resume after closing, Ladder passing, Challenge
backfill, titles, fail pop-up Stop. Written Oct 2026 from the V48
notes-vs-code audit (item numbers below = audit items, see README audit log).

Usage:
  python3 tests/scenario_tests.py BUILD.html            # run all
  python3 tests/scenario_tests.py BUILD.html R1 P6      # run only these ids
  python3 tests/scenario_tests.py --list                # list tests

Needs: Python Playwright + Chromium, and Node (for tests/scenario_logic.mjs).
Time is faked with page.clock (answer delays skipped, "slow" answers made by
jumping the clock), so the whole run takes about a minute.

Kinds of test:
  check  current behavior is the intended rule. FAIL = a regression.
  fix    agreed fix not built yet (audit FIX items, Q for V49). These FAIL
         until the fix is built; when one passes, the fix works — change its
         kind to "check".
  known  DECIDE items and audit item 8: the test records the CURRENT
         behavior. Result KNOWN = unchanged. CHANGED = behavior is different
         now: fine if a decision was built (then rewrite the test as a
         check), otherwise a regression.
Exit code 1 if any check FAILs or any known test is CHANGED (fix FAILs are
expected and don't change the exit code).
"""
import json, os, re, subprocess, sys, time, traceback
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
USER = "Ann"
NB = "\u00A0"

# ---------------------------------------------------------------- settings
def quiz_settings(**kw):
    d = {"operation": "mult", "order": "sequential", "answerMode": "type", "start": 1, "end": 10,
         "length": 10, "excludeEasy": False, "excludeEasyMode": "manual", "speedMode": "normal",
         "divideSymbols": ["obelus"]}
    d.update(kw); return d

def ladder_settings(**kw):
    d = {"operation": "mult", "start": 1, "end": 10, "length": 10, "excludeEasy": False,
         "excludeEasyMode": "manual", "speedMode": "normal", "divideSymbols": ["obelus"]}
    d.update(kw); return d

def mastery(mastered=(), ends=None, current=None, temp=(), temp_end=0, seq=None, exclude_mastered=False):
    return {"currentNumber": current, "mastered": list(mastered),
            "masteredEnd": {str(k): v for k, v in (ends or {}).items()},
            "tempMastered": list(temp), "tempMasteredEnd": temp_end, "seqCursor": seq or {},
            "lastMode": "mc-seq", "excludeMastered": exclude_mastered}

def ends_for(nums, e):
    return {n: e for n in nums}

# ---------------------------------------------------------------- page helpers
QJS = r"""() => {
  const norm = (t) => t.replace(/\s+/g, ' ').trim();
  const ds = [...document.querySelectorAll('div')].filter(d => /^\d+ ?[×÷] ?\d+$/.test(norm(d.innerText)));
  const out = {};
  const h1 = document.querySelector('h1'); out.h1 = h1 ? h1.innerText : null;
  out.modal = [...document.querySelectorAll('h1')].map(h => h.innerText).filter(t => /did not pass|PASSED|Lose your|Change range/.test(t))[0] || null;
  if (!ds.length) return out;
  const q = ds[ds.length - 1], box = q.parentElement;
  out.q = norm(q.innerText).replace(/^(\d+) ?([×÷]) ?(\d+)$/, '$1 $2 $3');
  out.banner = box.firstElementChild !== q ? box.firstElementChild.textContent : null;
  const inp = document.querySelector('input.answer-input');
  out.type = !!inp; out.disabled = inp ? inp.disabled : [...box.querySelectorAll('button')].some(b => b.disabled);
  const fb = [...box.querySelectorAll('div')].find(d => /^(CORRECT|Not quite)/.test(d.innerText));
  out.feedback = fb ? fb.innerText : null;
  const lab = [...document.querySelectorAll('div')].find(d => d.children.length === 0 && /answered · \d+ left$/.test(d.innerText));
  out.prog = lab ? lab.innerText : null;
  return out;
}"""

READY_JS = r"""() => {
  const t = document.body.innerText;
  if (/Quiz Done!|Quiz Stopped|You did not pass this time|Paused/.test(t)) return true;
  const inp = document.querySelector('input.answer-input');
  if (inp) return !inp.disabled;
  return !/CORRECT|Not quite/.test(t) && /answered · \d+ left/.test(t);
}"""

TITLE_JS = r"""(name) => {
  const sp = [...document.querySelectorAll('span')].find(s => s.innerText === name);
  if (!sp) return null;
  const box = sp.parentElement.parentElement;
  return box.innerText.split('\n').map(x => x.trim()).filter(x => x && x !== name && x !== 'Switch' && x !== 'User').join(' ');
}"""


def solve(q):
    m = re.match(r"^(\d+) ?([×÷]) ?(\d+)$", q)
    a, op, b = int(m[1]), m[2], int(m[3])
    return a * b if op == "×" else a // b


class Fail(AssertionError):
    pass


def check(cond, msg):
    if not cond:
        raise Fail(msg)


class App:
    def __init__(self, ctx, html):
        self.ctx, self.html = ctx, html
        self.pg = ctx.new_page()
        self.pg.set_default_timeout(5000)
        self.pg.clock.install()
        self.pg.goto("file://" + html)

    # --- setup
    def seed(self, quiz=None, ladder=None, challenge=None, glob=None, seq=None, mastery_=None, log=None):
        st = {"quizSettings": quiz or quiz_settings(), "ladderSettings": ladder or ladder_settings(),
              "challengeSettings": challenge or {"speedMode": "normal"},
              "globalSettings": glob or {"dropWorstScore": False, "slowThresholdSeconds": 5},
              "seqProgress": seq or {"signature": None, "cursor": 0}, "screen": "setup"}
        self.pg.evaluate("""([u, st, m, lg]) => { localStorage.clear(); localStorage.setItem('tt_unlocked','true');
          localStorage.setItem('times-tables-users-v1', JSON.stringify({names:[u], lastUser:u}));
          localStorage.setItem('times-tables-state-v1:'+u, JSON.stringify(st));
          if (m) localStorage.setItem('times-tables-mastery-v1:'+u, JSON.stringify(m));
          if (lg) localStorage.setItem('times-tables-log-v1:'+u, JSON.stringify(lg));
          localStorage.setItem('times-tables-intro-v1:'+u, '99'); }""", [USER, st, mastery_, log])
        self.reopen()

    def reopen(self):
        """Close and reopen the app (page reload)."""
        self.pg.reload()
        sk = self.pg.get_by_role("button", name="Skip Intro", exact=True)
        sk.wait_for(timeout=5000); sk.click()
        self.pg.wait_for_timeout(50)

    def btn(self, name):
        return self.pg.get_by_role("button", name=name, exact=True).first

    def click(self, name):
        self.btn(name).click(); self.pg.wait_for_timeout(30)

    def tab(self, name):
        self.pg.get_by_role("button", name=re.compile("^" + name + "$", re.I)).first.click()
        self.pg.wait_for_timeout(30)

    def body(self):
        return self.pg.locator("body").inner_text().replace(NB, " ")

    def ls(self, kind):
        return self.pg.evaluate("(k) => JSON.parse(localStorage.getItem(k))", f"times-tables-{kind}-v1:{USER}")

    def header_title(self):
        t = self.pg.evaluate(TITLE_JS, USER)  # shown in capitals (CSS); compare as upper case
        return t.upper() if t else t

    # --- quiz
    def q(self):
        return self.pg.evaluate(QJS)

    def answer(self, correct=True, slow_ms=0):
        """Answer the current question; returns its text. Leaves the
        feedback showing (call advance() to move on)."""
        info = self.q()
        check(info.get("q") and not info.get("disabled"), f"no question to answer: {info}")
        ans = solve(info["q"])
        val = ans if correct else ans + 1
        if slow_ms: self.pg.clock.fast_forward(slow_ms)
        if info["type"]:
            inp = self.pg.locator("input.answer-input")
            inp.fill(str(val)); inp.press("Enter")
        else:
            if not correct:  # pick any wrong choice
                for c in self.pg.locator("button").all_inner_texts():
                    if c.strip().isdigit() and int(c) != ans: val = int(c); break
            self.click(str(val))
        self.pg.wait_for_function("() => /CORRECT|Not quite/.test(document.body.innerText)", polling=20, timeout=3000)
        return info["q"]

    def advance(self):
        self.pg.clock.run_for(4000)
        self.pg.wait_for_function(READY_JS, polling=20, timeout=4000)

    def step(self, correct=True, slow_ms=0):
        q = self.answer(correct, slow_ms); self.advance(); return q

    def in_quiz(self):
        i = self.q(); return bool(i.get("q")) and not re.search(r"Quiz Done!|Quiz Stopped|Paused", self.body())

    def finish(self, limit=400):
        """Answer everything correctly until the results screen; returns the
        list of questions asked."""
        asked = []
        for _ in range(limit):
            if not self.in_quiz(): return asked
            asked.append(self.step())
        raise Fail("quiz did not finish")

    def results_line(self):
        m = re.search(r"(\d+) correct on first try · (\d+) missed", self.body())
        return (int(m[1]), int(m[2])) if m else None


# ---------------------------------------------------------------- tests
TESTS = []
def test(tid, kind, ref, title):
    def deco(fn):
        TESTS.append({"id": tid, "kind": kind, "ref": ref, "title": title, "fn": fn}); return fn
    return deco

SIG10 = "mult|1|10|false"

# ===== Repeats (Quizzes tab, Type In · In Order, 1–10 ×, 10 questions)

@test("R1", "check", "repeats", "Wrong answer: immediate repeat, then one delayed check-back 3–6 questions later")
def t_r1(a):
    a.seed(quiz=quiz_settings()); a.tab("Quizzes"); a.click("Start Quiz")
    a.answer(correct=False)
    check(a.q()["banner"] == "Will repeat", "wrong answer should show 'Will repeat'")
    a.advance()
    i = a.q(); check(i["q"] == "1 × 1" and i["banner"] == "Repeating", f"expected immediate repeat of 1 × 1, got {i}")
    check(i["prog"] == "1 answered · 10 left", f"repeat should add one question: {i['prog']}")
    a.step()  # correct on the repeat -> one delayed check-back
    seen = []
    while a.in_quiz():
        i = a.q(); seen.append((i["q"], i["banner"])); a.step()
    idx = [k for k, (q, b) in enumerate(seen) if q == "1 × 1"]
    check(len(idx) == 1, f"1 × 1 should come back exactly once more, saw {seen}")
    check(seen[idx[0]][1] == "Repeat", f"delayed check-back should show 'Repeat': {seen[idx[0]]}")
    check(3 <= idx[0] <= 6, f"delayed check-back after 3–6 other questions, came after {idx[0]}")
    check(a.results_line() == (9, 1), f"results {a.results_line()} (want 9 correct · 1 missed)")
    check(a.ls("log")[0]["percentCorrect"] == 90, "History row should be 90%")

@test("R2", "check", "repeats / audit 9 KEEP", "Slow-but-correct repeats right away, again each time it is slow (no limit), never a delayed check-back")
def t_r2(a):
    a.seed(quiz=quiz_settings()); a.tab("Quizzes"); a.click("Start Quiz")
    a.answer(slow_ms=6000)
    check(a.q()["banner"] == "Will repeat", "slow correct answer should show 'Will repeat'")
    a.advance()
    for k in range(2):  # slow twice more on the repeats
        i = a.q(); check(i["q"] == "1 × 1" and i["banner"] == "Repeating", f"slow repeat #{k+1}: {i}")
        a.step(slow_ms=6000)
    i = a.q(); check(i["q"] == "1 × 1", f"third slow answer should repeat again: {i}")
    a.step()  # fast -> no more repeats
    asked = a.finish()
    check("1 × 1" not in asked, f"no delayed check-back after slow repeats: {asked}")
    check(a.results_line() == (10, 0), f"slow-correct counts as correct: {a.results_line()}")

@test("R3", "check", "repeats", "Speed Fastest: no repeats for wrong or slow answers")
def t_r3(a):
    a.seed(quiz=quiz_settings(speedMode="test")); a.tab("Quizzes"); a.click("Start Quiz")
    a.answer(correct=False)
    check(a.q()["banner"] is None, "Fastest should not show 'Will repeat'")
    a.advance()
    i = a.q(); check(i["q"] == "1 × 2" and i["prog"] == "1 answered · 9 left", f"no repeat in Fastest: {i}")
    a.step(slow_ms=6000)
    i = a.q(); check(i["q"] == "1 × 3", f"slow answer not repeated in Fastest: {i}")
    asked = a.finish()
    check(len(asked) == 8, f"10 questions total, got {len(asked) + 2}")
    check(a.results_line() == (9, 1), f"results {a.results_line()}")

@test("R4", "check", "repeats", "Fast halves the slow limit (3 s is slow in Fast, not in Normal)")
def t_r4(a):
    a.seed(quiz=quiz_settings(speedMode="fast")); a.tab("Quizzes"); a.click("Start Quiz")
    a.step(slow_ms=3000)
    i = a.q(); check(i["q"] == "1 × 1" and i["banner"] == "Repeating", f"3 s should be slow in Fast: {i}")
    a.seed(quiz=quiz_settings(speedMode="normal")); a.tab("Quizzes"); a.click("Start Quiz")
    a.step(slow_ms=3000)
    i = a.q(); check(i["q"] == "1 × 2", f"3 s should not be slow in Normal: {i}")

# ===== In Order place

@test("O1", "check", "In Order (v48)", "Quizzes: a finished quiz moves the place; quitting with ✕ leaves it")
def t_o1(a):
    a.seed(quiz=quiz_settings()); a.tab("Quizzes"); a.click("Start Quiz")
    check(a.q()["q"] == "1 × 1", "first quiz starts at 1 × 1")
    a.finish(); a.click("Back to Quizzes"); a.click("Start Quiz")
    check(a.q()["q"] == "2 × 1", f"after a finished quiz: {a.q()['q']} (want 2 × 1)")
    for _ in range(3): a.step()
    a.pg.get_by_role("button", name="Quit quiz").click(); a.click("Start Quiz")
    check(a.q()["q"] == "2 × 1", f"after ✕: {a.q()['q']} (want 2 × 1 again)")

@test("O2", "check", "In Order / audit 7 KEEP", "Quizzes: Quiz Length ALL starts from the top and does not move or reset the place")
def t_o2(a):
    qs = quiz_settings(end=3, length="ALL")  # 1–3: 9 facts
    a.seed(quiz=qs, seq={"signature": "mult|1|3|false", "cursor": 4}); a.tab("Quizzes"); a.click("Start Quiz")
    check(a.q()["q"] == "1 × 1", f"ALL starts at the top: {a.q()['q']}")
    asked = a.finish()
    check(len(asked) == 9, f"ALL = 9 questions, got {len(asked)}")
    check(a.ls("state")["seqProgress"] == {"signature": "mult|1|3|false", "cursor": 4}, f"place changed: {a.ls('state')['seqProgress']}")
    a.click("Back to Quizzes"); a.click("10"); a.click("Start Quiz")
    check(a.q()["q"] == "2 × 2", f"next sized quiz resumes old place: {a.q()['q']} (want 2 × 2)")

@test("O3", "known", "audit 8", "Quizzes bookmark ignores Choose/Type In, Quiz Length and Speed (one shared place)")
def t_o3(a):
    a.seed(quiz=quiz_settings(), seq={"signature": SIG10, "cursor": 10}); a.tab("Quizzes")
    a.click("Start Quiz"); check(a.q()["q"] == "2 × 1", "Type In: 2 × 1")
    a.pg.get_by_role("button", name="Quit quiz").click()
    a.click("Choose · In Order"); a.click("20"); a.click("Fast"); a.click("Start Quiz")
    i = a.q(); check(not i["type"] and i["q"] == "2 × 1", f"Choose, length 20, Fast still at the same place: {i}")
    a.pg.get_by_role("button", name="Quit quiz").click()

@test("O4", "known", "audit 8", "Quizzes bookmark is one slot: a finished quiz with another Range overwrites it")
def t_o4(a):
    a.seed(quiz=quiz_settings(), seq={"signature": SIG10, "cursor": 10}); a.tab("Quizzes")
    a.click("1–12"); a.click("Yes"); a.click("Start Quiz")
    check(a.q()["q"] == "1 × 1", f"new Range starts at the top: {a.q()['q']}")
    a.pg.get_by_role("button", name="Quit quiz").click()
    a.click("1–10"); a.click("Yes"); a.click("Start Quiz")
    check(a.q()["q"] == "2 × 1", "back to 1–10 without finishing: place kept")
    a.pg.get_by_role("button", name="Quit quiz").click()
    a.click("1–12"); a.click("Yes"); a.click("Start Quiz"); a.finish(); a.click("Back to Quizzes")
    a.click("1–10"); a.click("Yes"); a.click("Start Quiz")
    check(a.q()["q"] == "1 × 1", f"1–10 place lost after finishing a 1–12 quiz: {a.q()['q']}")

@test("O5", "check", "In Order (v48)", "Ladder: place kept per number; finish moves it, ✕ leaves it")
def t_o5(a):
    a.seed(ladder=ladder_settings(length=4), mastery_=mastery(current=2))
    a.click("2s"); a.click("Type In · In Order"); a.click("Start Quiz")
    check(a.q()["q"] == "2 × 1", "2s start at 2 × 1")
    a.finish(); back_to_ladder(a)
    a.click("2s"); a.click("Start Quiz")
    check(a.q()["q"] == "2 × 5", f"after finish: {a.q()['q']} (want 2 × 5)")
    a.step(); a.pg.get_by_role("button", name="Quit quiz").click()
    a.click("2s"); a.click("Start Quiz")
    check(a.q()["q"] == "2 × 5", f"after ✕: {a.q()['q']} (want 2 × 5)")
    a.pg.get_by_role("button", name="Quit quiz").click()
    a.click("3s"); a.click("Start Quiz")
    check(a.q()["q"] == "3 × 1", f"3s have their own place: {a.q()['q']}")

@test("O6", "known", "audit 8", "Ladder bookmark key includes Start; New Facts Only uses the same bookmark on a shorter list")
def t_o6(a):
    seq = {"3|" + SIG10: 4}
    a.seed(ladder=ladder_settings(length=4), mastery_=mastery([1, 2], ends_for([1, 2], 10), current=3, seq=seq))
    a.click("3s"); a.click("Type In · In Order"); a.click("Start Quiz")
    check(a.q()["q"] == "3 × 5", f"All Facts: {a.q()['q']} (want 3 × 5)")
    a.pg.get_by_role("button", name="Quit quiz").click()
    a.click("New Facts Only"); a.click("3s"); a.click("Start Quiz")
    check(a.q()["q"] == "3 × 7", f"New Facts Only: {a.q()['q']} (want 3 × 7: same cursor, 3×1 and 3×2 removed)")
    a.pg.get_by_role("button", name="Quit quiz").click()
    a.seed(ladder=ladder_settings(start=2, length=4), mastery_=mastery([1, 2], ends_for([1, 2], 10), current=3, seq=seq))
    a.click("3s"); a.click("Type In · In Order"); a.click("Start Quiz")
    check(a.q()["q"] == "3 × 1", f"Start 2 (same 3s questions): {a.q()['q']} (want 3 × 1: different key)")

# ===== Resume after closing (Quizzes tab only)

@test("C1", "check", "resume (v48)", "Quizzes: close between questions, reopen: same place, counts, History and In Order place correct")
def t_c1(a):
    a.seed(quiz=quiz_settings()); a.tab("Quizzes"); a.click("Start Quiz")
    a.step(correct=False); a.step(); a.step()  # 1×1 wrong, 1×1 repeat, 1×2
    i = a.q(); check(i["q"] == "1 × 3", f"before closing: {i}")
    a.reopen()
    i = a.q(); check(i["q"] == "1 × 3", f"resumed on: {i}")
    check(i["prog"] == "3 answered · 9 left", f"progress kept: {i['prog']}")
    asked = a.finish()
    check(asked.count("1 × 1") == 1, f"delayed check-back of 1 × 1 kept after resume: {asked}")
    log = a.ls("log"); check(len(log) == 1 and log[0]["totalQuestions"] == 10, f"History row: {log}")
    a.click("Back to Quizzes"); a.tab("Quizzes")  # (v50: already on Quizzes; tab() kept harmless)
    a.click("Start Quiz")
    check(a.q()["q"] == "2 × 1", f"In Order place moved by the resumed quiz: {a.q()['q']}")
    # first-try counts after resume: see C4 (audit 10)

@test("C4", "check", "audit 10 (also between questions)", "Quizzes: close BETWEEN questions, reopen: the last answer before closing still counts")
def t_c4(a):
    a.seed(quiz=quiz_settings()); a.tab("Quizzes"); a.click("Start Quiz")
    a.step(); a.step()  # 1×1, 1×2 correct; 1×3 showing, no feedback
    check(a.q()["q"] == "1 × 3" and not a.q()["feedback"], "closing while 1 × 3 shows")
    a.reopen(); a.finish()
    res = a.results_line(); log = a.ls("log")
    check(res == (10, 0) and log[0]["percentCorrect"] == 100,
          f"results {res}, History {log[0]['percentCorrect']}% (want 10 correct · 0 missed, 100%): saved first-try stats lag one answer")

@test("C2", "check", "audit 10", "Quizzes: close during answer feedback, reopen: that question is not lost (10 correct, 100%)")
def t_c2(a):
    a.seed(quiz=quiz_settings()); a.tab("Quizzes"); a.click("Start Quiz")
    a.step(); a.step(); a.answer()  # 1×3 answered, feedback showing
    a.reopen()
    first = a.q()["q"]
    a.finish()
    res = a.results_line(); log = a.ls("log")
    check(res == (10, 0) and log[0]["percentCorrect"] == 100,
          f"resumed on {first}; results {res}, History {log[0]['percentCorrect']}% (want 10 correct · 0 missed, 100%)")

@test("C5", "check", "resume tab (v50)", "Quizzes quiz resumed after closing: Back to Quizzes lands on the Quizzes tab")
def t_c5(a):
    a.seed(quiz=quiz_settings()); a.tab("Quizzes"); a.click("Start Quiz")
    a.step()
    a.reopen()
    check(a.in_quiz(), "quiz resumed")
    a.finish(); a.click("Back to Quizzes")
    check(a.btn("Start Quiz").count() > 0 and a.btn("2s").count() == 0, "on the Quizzes tab (no Ladder number buttons)")

@test("C3", "check", "resume (by design)", "Ladder and Challenge quizzes are not resumed after closing")
def t_c3(a):
    a.seed(mastery_=mastery(current=2)); a.click("2s"); a.click("Start Quiz"); a.step()
    a.reopen(); check(not a.in_quiz() and "Start Quiz" in a.body(), "Ladder quiz should not resume")
    a.tab("Challenge Tests"); a.pg.get_by_text("Step 5", exact=True).click(); a.step()
    a.reopen(); check(not a.in_quiz(), "Challenge should not resume")

# ===== Ladder passing

def back_to_ladder(a):  # label changes in V49 (test V1)
    a.click("Back to Quiz Ladder") if a.btn("Back to Quiz Ladder").count() else a.click("Back to Math Wiz Ladder")

def start_test_all(a, n):
    a.click(f"{n}s"); a.click("Type In · Random · Test ALL"); a.click("Start Quiz")

@test("P1", "check", "Ladder pass", "Test ALL all correct at End 10: green, End saved, ▲ to first unpassed, PASSED message, History row")
def t_p1(a):
    a.seed(mastery_=mastery(current=1))
    start_test_all(a, 2)
    asked = a.finish()
    check(len(asked) == L["test_all_2s_end10"], f"{len(asked)} questions (want {L['test_all_2s_end10']})")
    check(f"2s up to 10 PASSED!   Next up: the 1s." in a.body(), "PASSED message")
    m = a.ls("mastery")
    check(m["mastered"] == [2] and m["masteredEnd"].get("2") == 10 and m["currentNumber"] == 1, f"mastery {m}")
    row = a.ls("log")[0]
    check(row.get("passAttempt") == "test" and row["passed"] and row["range"] == "Ladder 2s up to 10", f"History {row}")

@test("P2", "check", "audit 2 (v49)", "End 7 (too small): new warning shows; a Test ALL pass gives a yellow badge")
def t_p2(a):
    a.seed(ladder=ladder_settings(end=7), mastery_=mastery(current=3))
    a.click("3s"); a.click("Type In · Random · Test ALL")
    check("This range is too small to pass a Math Wiz Ladder step. You can win a yellow practice badge." in a.body(), "v49 warning shown")
    a.click("Start Quiz"); asked = a.finish()
    check(len(asked) == L["test_all_3s_end7"], f"{len(asked)} questions")
    m = a.ls("mastery")
    check(m["tempMastered"] == [3] and m["tempMasteredEnd"] == 7 and m["mastered"] == [], f"yellow pass: {m}")
    check("3s up to 7 PASSED!" in a.body(), "PASSED message")

@test("P3", "check", "audit 2 choice B + 5b (v49)", "End 10 + SKIP On: no too-small warning, SKIP Off note, Test ALL still asks ×1/×10, green pass")
def t_p3(a):
    a.seed(ladder=ladder_settings(excludeEasy=True), mastery_=mastery(current=3))
    a.click("3s"); a.click("Type In · Random · Test ALL")
    b = a.body()
    check("too small" not in b, "no too-small warning at End 10")
    check("To win a title through Step 10 or Step 12, set SKIP the EASY FACTS to Let App Pick, or to Off. The 1s and 10s are steps you need to pass." in b, "SKIP Off note")
    a.click("Start Quiz"); asked = a.finish()
    check(L["test_all_3s_end10_skip"] == L["test_all_2s_end10"] and len(asked) == L["test_all_3s_end10_skip"], f"{len(asked)} questions (want {L['test_all_2s_end10']}, same as SKIP Off)")
    check(any(q in asked for q in ("3 × 1", "3 × 10")), "×1/×10 facts asked")
    m = a.ls("mastery")
    check(m["mastered"] == [3] and m["masteredEnd"].get("3") == 10, f"green pass: {m}")

@test("P4", "check", "fail pop-up (v44)", "Test ALL miss: fail pop-up with Work on list; Keep Going finishes; Not passed row")
def t_p4(a):
    a.seed(mastery_=mastery(current=2))
    start_test_all(a, 2)
    a.step(); missed = a.answer(correct=False); a.advance()
    b = a.body()
    check("You did not pass this time." in b and f"Work on: {missed}" in b, f"fail pop-up: {b[-300:]}")
    a.click("Keep Going")
    i = a.q(); check(i["q"] == missed and i["banner"] == "Repeating", f"Keep Going continues with the repeat: {i}")
    a.finish()
    check("Not quite — give the 2s another go." in a.body(), "not-passed message")
    row = a.ls("log")[0]; check(row["passed"] is False and row["missedCount"] == 1, f"History {row}")
    check(a.ls("mastery")["mastered"] == [], "nothing passed")

@test("P5", "check", "fail pop-up (v44, v53)", "Fail pop-up Stop mid-quiz: Quiz Stopped, saved as a Stopped History row (v53)")
def t_p5(a):
    a.seed(mastery_=mastery(current=2))
    start_test_all(a, 2)
    a.step(correct=False); a.click("Stop")
    check("Quiz Stopped" in a.body(), "title Quiz Stopped")
    log = a.ls("log") or []
    check(len(log) == 1 and log[0].get("stopped") and log[0]["answeredCount"] == 1 and log[0]["missedCount"] == 1 and log[0]["correctCount"] == 0,
          f"one Stopped row, 1 answered, 1 missed: {log}")

def stop_on_last(a, speed):
    a.seed(ladder=ladder_settings(end=7, speedMode=speed), mastery_=mastery(current=3))
    start_test_all(a, 3)
    for _ in range(L["test_all_3s_end7"] - 1): a.step()
    a.step(correct=False)
    check("You did not pass this time." in a.body(), "fail pop-up on the last question")
    a.click("Stop")

@test("P6", "check", "audit 3", "Fail pop-up Stop on the LAST question (Normal): normal finish, saved")
def t_p6(a):
    stop_on_last(a, "normal")
    log = a.ls("log") or []
    check("Quiz Done!" in a.body() and len(log) == 1, f"title {'Quiz Done!' if 'Quiz Done!' in a.body() else 'Quiz Stopped'}, History rows {len(log)} (want Quiz Done!, 1 row)")

@test("P7", "check", "fail pop-up (v44)", "Fail pop-up Stop on the LAST question (Fastest): normal finish, saved")
def t_p7(a):
    stop_on_last(a, "test")
    log = a.ls("log") or []
    check("Quiz Done!" in a.body() and len(log) == 1 and log[0]["passed"] is False, f"Fastest: {log}")

@test("P8", "check", "audit 4 choice A (v49)", "Yellow number at its own End: Test ALL is practice only (widening clears yellow first)")
def t_p8(a):
    a.seed(ladder=ladder_settings(end=7), mastery_=mastery(current=1, temp=[7], temp_end=7))
    # v51: a yellow pill shows its End ("7s to 7")
    a.click("7s to 7"); a.click("Type In · Random · Test ALL"); a.click("Start Quiz")
    asked = a.finish()
    check(len(asked) == L["test_all_7s_end7"], f"{len(asked)} questions")
    check("PASSED" not in a.body(), "no PASSED message (practice)")
    m = a.ls("mastery"); check(m["tempMastered"] == [7] and 7 not in m["mastered"], f"still yellow: {m}")
    check("passAttempt" not in a.ls("log")[0], "History: normal practice row")

@test("P9", "check", "upgrade test (v44)", "Upgrade test 12s End 12 → 20 asks only facts not yet passed; pass records End 20")
def t_p9(a):
    ends = {**ends_for(range(1, 11), 10), 11: 12, 12: 12}
    a.seed(ladder=ladder_settings(end=20), mastery_=mastery(range(1, 13), ends, current=13))
    start_test_all(a, 12)
    asked = a.finish()
    check(len(asked) == L["upgrade_12s_12to20"], f"{len(asked)} questions (want {L['upgrade_12s_12to20']})")
    old = [q for q in asked if (lambda m: m and int(m[1]) == 12 and int(m[2]) <= 12)(re.match(r"(\d+) × (\d+)", q))]
    check(not old, f"already-passed facts asked: {old}")
    check("12s up to 20 PASSED!" in a.body(), "PASSED message")
    m = a.ls("mastery"); check(m["masteredEnd"]["12"] == 20, f"End 20 saved: {m['masteredEnd']}")
    check(a.ls("log")[0]["range"] == "Ladder 12s up to 20", "History label")

def instant_upgrade(a):
    a.seed(ladder=ladder_settings(end=20), mastery_=mastery([11, *range(13, 21)], {11: 12, **ends_for(range(13, 21), 20)}, current=1))
    before = a.header_title()
    start_test_all(a, 11)
    return before

@test("P10", "check", "upgrade test (v44)", "Instant upgrade (nothing new to test): pop-up, End 20 saved, header title updates")
def t_p10(a):
    before = instant_upgrade(a)
    check(L["upgrade_11s_instant"] == 0, "scenario needs 0 questions")
    check(before == "", f"header before (v49: 11 at End 12 gives no title without 1–10): {before!r}")
    b = a.body()
    check("11s up to 20 PASSED!" in b and "nothing new to test" in b, "instant pop-up")
    check(a.ls("mastery")["masteredEnd"]["11"] == 20, "End 20 saved")
    a.click("OK")
    check(a.header_title() == "ROYAL MATH WIZ 11", f"header after: {a.header_title()}")

@test("P11", "check", "audit 4 (v49)", "Test ALL at End 15: green at 12 + yellow 7s to 15 (v51), '7s up to 12 PASSED!', History 'up to 12', both tap notes, Back goes to the ▲")
def t_p11(a):
    a.seed(ladder=ladder_settings(end=15), mastery_=mastery(current=7))
    start_test_all(a, 7)
    a.finish()
    check("7s up to 12 PASSED!" in a.body(), "PASSED message shows the rounded End")
    # v51 "Yellow above 12": End 13-19 also gives a yellow badge for the End reached
    m = a.ls("mastery"); check(7 in m["mastered"] and m["masteredEnd"].get("7") == 12 and m["tempMastered"] == [7] and m["tempMasteredEnd"] == 15, f"green at 12 + yellow at 15: {m}")
    check(a.ls("log")[0]["range"] == "Ladder 7s up to 12", f"History {a.ls('log')[0]['range']}")
    # v51: after a pass, Back goes to the ▲ (first unpassed = 1s)
    back_to_ladder(a)
    check("1s — TYPE OF QUESTIONS" in a.body(), "after a pass, Back shows the ▲ number (1s)")
    check(a.btn("7s").count() == 1 and a.btn("7s to 15").count() == 1, "two pills: green 7s and yellow 7s to 15")
    a.click("7s"); b = a.body()
    check("This number is already passed. You can still practice it." in b and "This number has a practice pass through 15. You can still practice it." in b, "both tap notes")

# ===== v51

@test("PS1", "check", "Practice Start (v51)", "Practice Start 9: 12s In Order practice starts at 12 × 9; Test ALL still asks every fact")
def t_ps1(a):
    a.seed(ladder=ladder_settings(end=20, practiceStart=9), mastery_=mastery(current=1))
    a.click("12s"); a.click("Type In · In Order"); a.click("Start Quiz")
    check(a.q()["q"] == "12 × 9", f"first question {a.q()['q']} (want 12 × 9)")
    a.pg.get_by_role("button", name="Quit quiz").click()
    a.click("Type In · Random · Test ALL"); a.click("Start Quiz")
    prog = a.q()["prog"]
    check(prog == f"0 answered · {L['test_all_12s_end20']} left", f"Test ALL ignores Practice Start: {prog}")

@test("PS2", "check", "Practice Start (v51)", "Set Start saves Practice Start; a smaller End pulls it down to the End; In Order place restarts at the new first fact")
def t_ps2(a):
    a.seed(ladder=ladder_settings(end=20), mastery_=mastery(current=1, seq={"12|mult|1|20|false": 3}))
    a.click("12s"); a.click("Type In · In Order"); a.click("Start Quiz")
    check(a.q()["q"] == "12 × 4", f"saved place at Practice Start 1: {a.q()['q']}")
    a.pg.get_by_role("button", name="Quit quiz").click()
    # v53: 1–20 is Custom on the Ladder and opens the Custom boxes on load —
    # close them (tap Custom again) so "Increase Start" is Practice Start's.
    if a.btn("SET RANGE").count(): a.click("Custom Range: 1–20")
    a.click("Practice Start")  # v52: a button that opens the spinner
    for _ in range(4): a.click("Increase Start")
    a.click("Set Start")
    check(a.btn("Practice Start: 5").count() == 1, "button shows the value (Practice Start: 5)")
    check(a.ls("state")["ladderSettings"].get("practiceStart") == 5, f"saved {a.ls('state')['ladderSettings'].get('practiceStart')}")
    a.click("Start Quiz")
    check(a.q()["q"] == "12 × 5", f"new Practice Start starts at its first fact: {a.q()['q']}")
    a.pg.get_by_role("button", name="Quit quiz").click()
    a.seed(ladder=ladder_settings(end=20, practiceStart=15), mastery_=mastery(current=1))
    a.click("1–10"); a.click("Yes")
    check(a.ls("state")["ladderSettings"].get("practiceStart") == 10, f"End 10 pulls Practice Start down: {a.ls('state')['ladderSettings'].get('practiceStart')}")

@test("PS3", "check", "Practice Start button (v52)", "Practice Start is a closed button; tapping opens spinner, Set Start, Go Back and note; Go Back changes nothing. Range note shows only while Custom is open")
def t_ps3(a):
    # v53: End 12 (1–20 is no longer a Ladder preset, so it would load as Custom).
    a.seed(ladder=ladder_settings(end=12), mastery_=mastery(current=1))
    note = "This picks where your practice questions start"
    check(a.btn("Set Start").count() == 0 and note not in a.body(), "closed by default")
    a.click("Practice Start")
    check(a.btn("Set Start").count() == 1 and a.btn("Go Back").count() == 1 and note in a.body(), "opens with Set Start, Go Back and the note")
    a.click("Increase Start"); a.click("Go Back")
    check(a.btn("Set Start").count() == 0 and a.ls("state")["ladderSettings"].get("practiceStart", 1) == 1, "Go Back closes without changing anything")
    rn = "An End of 10 or 11 counts toward Math Wiz!"
    check(rn not in a.body() and "If your Custom End is 9 or lower" not in a.body(), "Range note hidden while Custom is closed")
    a.click("Custom")
    check(rn in a.body() and "Any End of 12 to 19 counts toward Senior Math Wiz 12." in a.body(), "whole Range note shows while Custom is open")

@test("Y2", "check", "yellow on green 12 (v52)", "Green 12, no yellow, End 15: Test ALL is a real attempt (only ×13–×15 facts); pass adds yellow 12s to 15; retest at End 15 is practice")
def t_y2(a):
    a.seed(ladder=ladder_settings(end=15), mastery_=mastery(mastered=[12], ends={12: 12}, current=1))
    a.click("12s"); a.click("Type In · Random · Test ALL"); a.click("Start Quiz")
    asked = a.finish()
    check(len(asked) == L["yellow_attempt_12s_end15"], f"{len(asked)} questions (want {L['yellow_attempt_12s_end15']})")
    check("12s up to 15 PASSED!" in a.body(), "banner 12s up to 15 PASSED!")
    m = a.ls("mastery"); check(m["tempMastered"] == [12] and m["tempMasteredEnd"] == 15 and m["masteredEnd"]["12"] == 12, f"green 12 + yellow 15: {m}")
    e = a.ls("log")[0]; check(e.get("passAttempt") and e["range"] == "Ladder 12s up to 15", f"History pass row: {e.get('range')} {e.get('passAttempt')}")
    back_to_ladder(a)
    a.click("12s to 15"); a.click("Type In · Random · Test ALL"); a.click("Start Quiz")
    a.finish()
    check("PASSED" not in a.body() and "passAttempt" not in a.ls("log")[0], "retest at End 15 is practice only")

@test("B1", "check", "Back to Ladder (v51)", "After a practice quiz, Back to Math Wiz Ladder stays on the number just quizzed (not the ▲)")
def t_b1(a):
    a.seed(ladder=ladder_settings(start=11, end=20, length=3), mastery_=mastery(current=11))
    a.click("12s"); a.click("Start Quiz"); a.finish(); back_to_ladder(a)
    check("12s — TYPE OF QUESTIONS" in a.body(), "Back stays on 12s")

@test("X1", "check", "extra time (v51)", "Fast Type In: 2-digit answers get +0.5 s, 3-digit +1 s before counting as slow")
def t_x1(a):
    a.seed(quiz=quiz_settings(speedMode="fast", start=4, end=10)); a.tab("Quizzes"); a.click("Start Quiz")
    check(a.q()["q"] == "4 × 4", f"first question {a.q()['q']}")
    a.step(slow_ms=2800)
    i = a.q(); check(i["q"] == "4 × 5" and i["banner"] is None, f"2.8 s on a 2-digit answer is not slow in Fast: {i}")
    a.step(slow_ms=3200)
    i = a.q(); check(i["q"] == "4 × 5" and i["banner"] == "Repeating", f"3.2 s on a 2-digit answer is slow: {i}")
    a.seed(quiz=quiz_settings(speedMode="fast", start=10, end=10)); a.tab("Quizzes"); a.click("Start Quiz")
    a.step(slow_ms=3300)
    i = a.q(); check(i["banner"] is None, f"3.3 s on a 3-digit answer is not slow in Fast: {i}")

@test("V2", "check", "Q for V49", "Instant upgrade pop-up adds 'You are now a …!' when the title changes")
def t_v2(a):
    instant_upgrade(a)
    check("You are now a Royal Math Wiz 11!" in a.body(), "pop-up has no 'You are now a Royal Math Wiz 11!' line")

@test("V1", "check", "Q for V49", "Ladder results button reads 'Back to Math Wiz Ladder'")
def t_v1(a):
    a.seed(ladder=ladder_settings(length=1), mastery_=mastery(current=2))
    a.click("2s"); a.click("Start Quiz"); a.finish()
    check(a.btn("Back to Math Wiz Ladder").count() == 1, "button reads " + ("'Back to Quiz Ladder'" if a.btn("Back to Quiz Ladder").count() else "something else"))

# ===== Challenge Tests

@test("CH1", "check", "Challenge (v44)", "Challenge 5 from nothing: Type In, 1 miss allowed at 100+ questions, backfills 1–5 at End 10")
def t_ch1(a):
    a.seed(); a.tab("Challenge Tests")
    check(f"{L['challenge5_none']} left" in a.body(), "left count")
    a.pg.get_by_text("Step 5", exact=True).click()
    check(a.q()["type"], "Challenge uses Type In")
    a.step(correct=False)
    check("You did not pass" not in a.body(), "1 miss allowed (115 questions)")
    asked = a.finish()
    check(len(asked) + 1 == L["challenge5_none"] + 2, f"{len(asked) + 1} answers (want {L['challenge5_none']} + immediate repeat + delayed check-back)")
    check("Challenge 5 PASSED!   You have won the title and every number below it." in a.body(), "PASSED message")
    m = a.ls("mastery")
    check(sorted(m["mastered"]) == [1, 2, 3, 4, 5] and all(m["masteredEnd"][str(n)] == 10 for n in range(1, 6)), f"backfill {m}")
    row = a.ls("log")[0]; check(row["passAttempt"] == "challenge" and row["passed"] and row["missedCount"] == 1, f"History {row}")
    a.click("Back to Challenge Tests"); check(a.header_title() == "JUNIOR MATH WIZ", f"header {a.header_title()}")

@test("CH2", "check", "Challenge (v44)", "Challenge 5 with 3s passed at End 20: fewer questions, 3s keep End 20")
def t_ch2(a):
    a.seed(mastery_=mastery([3], {3: 20}, current=1)); a.tab("Challenge Tests")
    check(f"{L['challenge5_3at20']} left" in a.body(), "left count uses Facts Passed Rule")
    a.pg.get_by_text("Step 5", exact=True).click()
    asked = a.finish()
    check(len(asked) == L["challenge5_3at20"], f"{len(asked)} questions")
    m = a.ls("mastery")
    check(m["masteredEnd"]["3"] == 20 and m["masteredEnd"]["5"] == 10, f"bigger End kept: {m['masteredEnd']}")

@test("CH3", "check", "Challenge (v44, v53)", "Challenge fail pop-up on the 2nd miss lists numbers to work on; Stop saves only a Stopped row")
def t_ch3(a):
    a.seed(); a.tab("Challenge Tests"); a.pg.get_by_text("Step 5", exact=True).click()
    m1 = a.answer(correct=False); a.advance(); a.step()  # miss + its repeat
    check("You did not pass" not in a.body(), "no pop-up after 1 miss")
    while True:
        i = a.q()
        if i["banner"] is None: break
        a.step()
    m2 = a.answer(correct=False); a.advance()
    b = a.body(); check("You did not pass this time." in b and "Work on:" in b, "pop-up on 2nd miss")
    a.click("Stop")
    log = a.ls("log") or []
    check("Quiz Stopped" in a.body() and len(log) == 1 and log[0].get("stopped") and log[0]["passAttempt"] == "challenge"
          and not (a.ls("mastery") or {}).get("mastered"), f"Stop saves only a Stopped row (v53), nothing passed: {log}")

# ===== v53
@test("ST1", "check", "Stopped rows (v53)", "✕ on Test ALL after 2 answers: Stopped row (2 of NQ, no %), kept out of averages and count; ✕ before answering: no row")
def t_st1(a):
    prior = [{"date": "2026-10-01T10:00:00.000Z", "totalQuestions": 10, "percentCorrect": 50, "mode": "type", "operation": "mult", "range": "1–10"}]
    a.seed(mastery_=mastery(current=2), log=prior)
    start_test_all(a, 2)
    a.pg.get_by_role("button", name="Quit quiz").click(); a.pg.wait_for_timeout(30)
    check(len(a.ls("log")) == 1, f"✕ before answering adds no row: {len(a.ls('log'))}")
    start_test_all(a, 2)
    a.step(); a.step()
    a.pg.get_by_role("button", name="Quit quiz").click(); a.pg.wait_for_timeout(30)
    log = a.ls("log")
    check(len(log) == 2 and log[0].get("stopped") and log[0]["answeredCount"] == 2 and log[0]["correctCount"] == 2 and log[0]["missedCount"] == 0,
          f"Stopped row: {log[0]}")
    n = log[0]["totalQuestions"]
    a.click("Scores History")
    b = a.body()
    check("Test ALL · Stopped" in b and f"2 of {n}Q" in b, "row label and 2 of NQ")
    check("1 finished quizzes" in b, "count leaves out Stopped")
    check(b.count("50%") >= 3 and "100%" not in b, "no % on Stopped row; averages = 50% (Stopped left out)")
    check("10Q" in b and "10q" not in b, "normal row shows 10Q")

@test("ST2", "check", "Stopped rows (v53)", "✕ on a practice quiz and on a practice Test ALL saves no row")
def t_st2(a):
    a.seed(mastery_=mastery(mastered=[2], ends={2: 10}, current=3))
    start_test_all(a, 2); a.step()
    a.pg.get_by_role("button", name="Quit quiz").click(); a.pg.wait_for_timeout(30)
    check(not a.ls("log"), f"practice Test ALL ✕: no row {a.ls('log')}")

@test("L20", "check", "Range presets (v53)", "Ladder has no 1–20 preset (1–20 shows as Custom Range: 1–20); Quizzes keeps it")
def t_l20(a):
    a.seed(mastery_=mastery(current=1))
    check(a.btn("1–20").count() == 0 and a.btn("11–20").count() == 1, "Ladder: no 1–20 button")
    a.tab("Quizzes")
    check(a.btn("1–20").count() == 1, "Quizzes: 1–20 button")
    a.seed(ladder=ladder_settings(end=20), mastery_=mastery(current=1))
    check(a.btn("Custom Range: 1–20").count() == 1, "Ladder 1–20 shows as Custom Range: 1–20")

@test("TG1", "check", "toggle buttons (v53)", "Tapping Custom or Practice Start again closes its section without changing anything")
def t_tg1(a):
    a.seed(ladder=ladder_settings(end=12), mastery_=mastery(current=1))
    a.click("Custom"); check(a.btn("SET RANGE").count() == 1, "Custom opens")
    a.click("Increase End"); a.click("Custom Range: 1–12")  # label while open
    s = a.ls("state")["ladderSettings"]
    check(a.btn("SET RANGE").count() == 0 and s["end"] == 12, f"Custom again closes, End unchanged: {s['end']}")
    a.click("Practice Start"); check(a.btn("Set Start").count() == 1, "Practice Start opens")
    a.click("Increase Start"); a.click("Practice Start")
    check(a.btn("Set Start").count() == 0 and a.ls("state")["ladderSettings"].get("practiceStart", 1) == 1, "Practice Start again closes, unchanged")

# ===== Titles

@test("T1", "check", "titles", "Header titles for common progress (Junior, Math Wiz!, no title for 2–9 with SKIP (v49), Royal 12 at End 20, Crown, King)")
def t_t1(a):
    want = {"1-5@10": "Junior Math Wiz", "1-10@10": "Math Wiz!", "2-9 SKIP on": None,
            "1-12, 11/12@20": "Royal Math Wiz 12", "11-15@20": "Crown Math Wiz", "11-20@20": "Math Wiz King"}
    check(L["titles_ok"] == want, f"logic titles {L['titles_ok']}")
    a.seed(ladder=ladder_settings(excludeEasy=True), mastery_=mastery(range(2, 10), ends_for(range(2, 10), 10), current=11))
    check(a.header_title() == "", f"header {a.header_title()!r} (v49: the 1s are required)")
    a.seed(mastery_=mastery(range(11, 21), ends_for(range(11, 21), 20), current=1))
    check(a.header_title() == "MATH WIZ KING", f"header {a.header_title()}")

@test("T2", "check", "audit 1", "1–12 passed at End 12: header shows Senior Math Wiz 12")
def t_t2(a):
    ends = {**ends_for(range(1, 11), 10), 11: 12, 12: 12}
    a.seed(ladder=ladder_settings(end=12), mastery_=mastery(range(1, 13), ends, current=1))
    check(a.header_title() == "SENIOR MATH WIZ 12" and L["title_1to12_at12"] == "Senior Math Wiz 12",
          f"header {a.header_title()}, currentTitleFor {L['title_1to12_at12']}")

@test("T3", "check", "audit 1", "Passing 12s at End 12 (1–11 passed): 'You are now a Senior Math Wiz 12!'")
def t_t3(a):
    ends = {**ends_for(range(1, 11), 10), 11: 12}
    a.seed(ladder=ladder_settings(end=12), mastery_=mastery(range(1, 12), ends, current=12))
    start_test_all(a, 12)
    asked = a.finish()
    check(len(asked) == L["test_all_12s_end12"], f"{len(asked)} questions")
    m = re.search(r"12s up to 12 PASSED!\s+([^\n]*)", a.body())
    check(m and m[1] == "You are now a Senior Math Wiz 12!", f"message: {m[0] if m else a.body()[:200]}")

def guide_text(a):
    a.click("Guide"); t = a.body(); a.click("Go Back"); return t

@test("T4", "check", "audit 5", "Chain B vs Guide 'These are learned through times 20' (11, 12 at End 12 + 13 → title 13)")
def t_t4(a):
    a.seed(); g = guide_text(a)
    code_fixed = L["title_item5a"] != "Royal Math Wiz 13"
    guide_fixed = "These are learned through times 20." not in g
    check(code_fixed or guide_fixed, f"currentTitleFor([11,12,13], 11/12@12, 13@20) = {L['title_item5a']} and the Guide sentence is unchanged")

@test("T5", "check", "audit 5", "SKIP On vs Guide 'passed every number step' (2–9, 11, 12 → title 12 without 1 or 10)")
def t_t5(a):
    a.seed(); g = guide_text(a)
    code_fixed = L["title_item5b"] not in ("Royal Math Wiz 12", "Senior Math Wiz 12")
    guide_fixed = "A title means you have passed every number step up through that step." not in g
    check(code_fixed or guide_fixed, f"currentTitleFor(2–9, 11, 12, SKIP On) = {L['title_item5b']} and the Guide intro is unchanged")


# ---------------------------------------------------------------- runner
def main():
    args = sys.argv[1:]
    if "--list" in args:
        for t in TESTS: print(f"{t['id']:5} {t['kind']:6} {t['ref']:24} {t['title']}")
        return 0
    if not args: print(__doc__); return 2
    html, only = os.path.abspath(args[0]), set(args[1:])
    global L
    L = json.loads(subprocess.check_output(["node", os.path.join(HERE, "scenario_logic.mjs")]))
    run = [t for t in TESTS if not only or t["id"] in only]
    counts, bad, t0 = {}, 0, time.time()
    with sync_playwright() as p:
        br = p.chromium.launch()
        for t in run:
            ctx = br.new_context(viewport={"width": 390, "height": 844})
            s0 = time.time(); err = None
            try:
                t["fn"](App(ctx, html))
            except Fail as e:
                err = str(e)
            except Exception as e:
                err = f"ERROR {type(e).__name__}: {str(e).splitlines()[0][:200]}"
            ctx.close()
            k = t["kind"]
            if k == "check": status = "PASS" if not err else "FAIL"
            elif k == "fix": status = "FIXED" if not err else "AWAITING FIX"
            else: status = "KNOWN" if not err else "CHANGED"
            if status in ("FAIL", "CHANGED"): bad += 1
            counts[status] = counts.get(status, 0) + 1
            print(f"{status:12} {t['id']:4} [{t['ref']}] {t['title']}  ({time.time() - s0:.1f}s)")
            if err: print(f"{'':12} -> {err}")
        br.close()
    print(f"\n{len(run)} tests in {time.time() - t0:.0f}s: " + ", ".join(f"{v} {k}" for k, v in counts.items()))
    print("FIXED = a fix test now passes: confirm, then change its kind to check. "
          "CHANGED = a known issue behaves differently: built decision or regression.")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
