#!/bin/sh
# Code regression check: every REMOVED non-comment source line, old → new.
# Usage: sh tests/code_diff.sh OLD_DIR NEW_DIR   (each containing src/)
# Read each line: it should be intentionally replaced, not lost.
diff -u "$1/src" "$2/src" | grep '^-' | grep -v '^---' | grep -v '^-[[:space:]]*//' | grep -v '^-[[:space:]]*$'
