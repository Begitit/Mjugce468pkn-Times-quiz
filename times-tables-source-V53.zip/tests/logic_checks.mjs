// Logic regression check (Node). Usage: node tests/logic_checks.mjs [--update]
// Computes key numbers (Challenge sizes, Facts Passed Rule results, upgrade
// pools, miss allowance) and compares them with tests/logic_snapshot.json.
// Any difference is printed. After an INTENDED change, re-run with --update
// and note why in the README changelog.
import fs from "fs";
import path from "path";
import { fileURLToPath, pathToFileURL } from "url";
const here = path.dirname(fileURLToPath(import.meta.url));
const tmp = path.join(here, ".logic_tmp.mjs");
fs.copyFileSync(path.join(here, "../src/logic.js"), tmp);
const L = await import(pathToFileURL(tmp).href);
fs.unlinkSync(tmp);
const r = (n) => Array.from({ length: n }, (_, i) => i + 1);
const ends = (ns, e) => Object.fromEntries(ns.map((n) => [n, e]));
const out = {};
// Challenge question counts under several progress states
const states = {
  none: [[], {}],
  "1-5@10": [r(5), ends(r(5), 10)],
  "1-10@10": [r(10), ends(r(10), 10)],
  "1-10@20": [r(10), ends(r(10), 20)],
  "1-12@12": [r(12), ends(r(12), 12)],
  "1-12@20": [r(12), ends(r(12), 20)],
  "11-20@20": [r(20).slice(10), ends(r(20).slice(10), 20)],
};
for (const [k, [m, e]] of Object.entries(states))
  out["challenge " + k] = L.CHALLENGE_LEVELS.map(({ level }) => L.challengeRunPool(level, m, e).length);
// Challenges in order: total questions and repeats
{
  let m = [], e = {}, seen = new Set(), total = 0, rep = 0;
  for (const { level } of L.CHALLENGE_LEVELS) {
    for (const f of L.challengeRunPool(level, m, e)) { const k = f.a + f.op + f.b; if (seen.has(k)) rep++; seen.add(k); total++; }
    for (let n = 1; n <= level; n++) { if (!m.includes(n)) m.push(n); e[n] = Math.max(e[n] ?? 0, L.challengeMasteredEnd(n)); }
  }
  out["challenge sequence total/repeats"] = [total, rep];
}
// Ladder Test ALL / upgrade / New Facts Only
const s20 = { start: 1, end: 20, excludeEasy: false, operation: "mult" };
const s10 = { ...s20, end: 10 };
out["test ALL 7s End10 nothing passed"] = L.ladderAllCount(7, "type-test", s10, false, { mastered: [], masteredEnd: {} });
out["upgrade 12s 12->20"] = L.ladderAllCount(12, "type-test", s20, false, { mastered: r(12), masteredEnd: ends(r(12), 12) });
out["upgrade 12s with 13-20@20"] = L.ladderAllCount(12, "type-test", s20, false, { mastered: r(20), masteredEnd: { ...ends(r(12), 12), ...ends(r(20).slice(12), 20) } });
out["NFO 12s mult End20, 1-11@12"] = L.ladderAllCount(12, "mc-random", s20, true, { mastered: r(11), masteredEnd: ends(r(11), 12) });
out["NFO 5s End10, 5 passed"] = L.ladderAllCount(5, "mc-random", s10, true, { mastered: [5], masteredEnd: { 5: 10 } });
out["allowed misses 99/100/199/200"] = [99, 100, 199, 200].map(L.allowedMisses);
// v51: Practice Start (practice pools only; Test ALL ignores it), extra time
out["practice 12s End20 PS9 mult / both"] = [L.ladderAllCount(12, "mc-random", { ...s20, practiceStart: 9 }, false, {}), L.ladderAllCount(12, "mc-random", { ...s20, operation: "both", practiceStart: 9 }, false, {})];
out["Test ALL 12s End20 PS9 (ignores PS)"] = L.ladderAllCount(12, "type-test", { ...s20, practiceStart: 9 }, false, { mastered: [], masteredEnd: {} });
out["practiceStartOf PS15 End10 / unset"] = [L.practiceStartOf({ ...s10, practiceStart: 15 }), L.practiceStartOf(s10)];
out["v52 yellow attempt 12s End15 (green 12) / already yellow"] = [L.ladderTestPool(12, { ...s20, end: 15 }, { mastered: [12], masteredEnd: { 12: 12 }, tempMastered: [] }).length, L.isYellowAboveAttempt(12, { ...s20, end: 15 }, { mastered: [12], masteredEnd: { 12: 12 }, tempMastered: [12] })];
out["extraTimeMs 7/56/144 fast type, 144 normal, 144 mc"] = [L.extraTimeMs(7, "fast", "type"), L.extraTimeMs(56, "test", "type"), L.extraTimeMs(144, "fast", "type"), L.extraTimeMs(144, "normal", "type"), L.extraTimeMs(144, "fast", "mc")];
const snap = path.join(here, "logic_snapshot.json");
if (process.argv.includes("--update") || !fs.existsSync(snap)) {
  fs.writeFileSync(snap, JSON.stringify(out, null, 1));
  console.log("snapshot written");
} else {
  const old = JSON.parse(fs.readFileSync(snap, "utf8"));
  let diffs = 0;
  for (const k of new Set([...Object.keys(old), ...Object.keys(out)])) {
    if (JSON.stringify(old[k]) !== JSON.stringify(out[k])) { diffs++; console.log(`CHANGED ${k}: ${JSON.stringify(old[k])} -> ${JSON.stringify(out[k])}`); }
  }
  console.log(diffs ? `${diffs} difference(s)` : "logic: no differences");
}
