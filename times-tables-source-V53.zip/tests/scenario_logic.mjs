// Logic values used by tests/scenario_tests.py (Node). Prints one JSON object.
// Usage: node tests/scenario_logic.mjs
// Also run on its own: it imports src/logic.js the same way logic_checks.mjs does.
import fs from "fs";
import path from "path";
import { fileURLToPath, pathToFileURL } from "url";
const here = path.dirname(fileURLToPath(import.meta.url));
const tmp = path.join(here, ".scenario_logic_tmp.mjs");
fs.copyFileSync(path.join(here, "../src/logic.js"), tmp);
let L;
try { L = await import(pathToFileURL(tmp).href); } finally { fs.unlinkSync(tmp); }
const r = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
const ends = (ns, e) => Object.fromEntries(ns.map((n) => [n, e]));
const s = (end, excludeEasy = false) => ({ start: 1, end, excludeEasy, operation: "mult" });
const p1to12 = { mastered: r(1, 12), masteredEnd: { ...ends(r(1, 10), 10), 11: 12, 12: 12 } };
const out = {
  // Titles
  title_1to12_at12: L.currentTitleFor(p1to12.mastered, p1to12.masteredEnd),
  title_item5a: L.currentTitleFor([11, 12, 13], { 11: 12, 12: 12, 13: 20 }),
  title_item5b: L.currentTitleFor([...r(2, 9), 11, 12], { ...ends(r(2, 9), 10), 11: 12, 12: 12 }),
  titles_ok: {
    "1-5@10": L.currentTitleFor(r(1, 5), ends(r(1, 5), 10)),
    "1-10@10": L.currentTitleFor(r(1, 10), ends(r(1, 10), 10)),
    "2-9 SKIP on": L.currentTitleFor(r(2, 9), ends(r(2, 9), 10)),
    "1-12, 11/12@20": L.currentTitleFor(r(1, 12), { ...ends(r(1, 10), 10), 11: 20, 12: 20 }),
    "11-15@20": L.currentTitleFor(r(11, 15), ends(r(11, 15), 20)),
    "11-20@20": L.currentTitleFor(r(11, 20), ends(r(11, 20), 20)),
  },
  // Pool sizes
  test_all_2s_end10: L.ladderAllCount(2, "type-test", s(10), false, { mastered: [], masteredEnd: {} }),
  test_all_3s_end7: L.ladderAllCount(3, "type-test", s(7), false, { mastered: [], masteredEnd: {} }),
  test_all_7s_end7: L.ladderAllCount(7, "type-test", s(7), false, { mastered: [], masteredEnd: {} }),
  test_all_3s_end10_skip: L.ladderAllCount(3, "type-test", s(10), false, { mastered: [], masteredEnd: {} }),
  test_all_12s_end12: L.ladderAllCount(12, "type-test", s(12), false, { mastered: r(1, 11), masteredEnd: { ...ends(r(1, 10), 10), 11: 12 } }),
  upgrade_12s_12to20: L.ladderAllCount(12, "type-test", s(20), false, p1to12),
  upgrade_11s_instant: L.ladderAllCount(11, "type-test", s(20), false, { mastered: [11, ...r(13, 20)], masteredEnd: { 11: 12, ...ends(r(13, 20), 20) } }),
  challenge5_none: L.challengeRunPool(5, [], {}).length,
  challenge5_3at20: L.challengeRunPool(5, [3], { 3: 20 }).length,
  allowed_misses: [29, 99, 100].map(L.allowedMisses),
  yellow_attempt_12s_end15: L.ladderTestPool(12, s(15), { mastered: [12], masteredEnd: { 12: 12 }, tempMastered: [] }).length,
  test_all_12s_end20: L.ladderAllCount(12, "type-test", s(20), false, { mastered: [], masteredEnd: {} }),
  pool_sig_1to10: L.poolSignature(s(10)),
};
console.log(JSON.stringify(out));
