#!/usr/bin/env python3
"""Visible-text regression check (Playwright).

Usage:  python3 tests/text_inventory.py OLD.html NEW.html
Renders both builds through the same scripted states and prints every line
of visible text that exists in only one of them. Expected changes should be
the only output; anything else is a possible accidental loss or bug.
Add states to STATES as the app grows (rare pop-ups, special progress).
"""
import re, sys, json
from playwright.sync_api import sync_playwright

def user(pg, mastery):
    pg.evaluate("""(m)=>{localStorage.clear();localStorage.setItem('tt_unlocked','true');
      localStorage.setItem('times-tables-users-v1',JSON.stringify({names:['Ann'],lastUser:'Ann'}));
      localStorage.setItem('times-tables-mastery-v1:Ann',JSON.stringify(m));
      localStorage.setItem('times-tables-intro-v1:Ann','99');}""", mastery)
    pg.reload(); pg.wait_for_timeout(600)
    # v45+: the intro shows on every open; 4th+ showing has Skip Intro
    sk = pg.get_by_role("button", name="Skip Intro", exact=True)
    if sk.count(): sk.first.click(); pg.wait_for_timeout(300)

def B(pg, name):
    return pg.get_by_role("button", name=name, exact=True).first

def tab(pg, name):
    pg.get_by_role("button", name=re.compile("^" + name + "$", re.I)).first.click(); pg.wait_for_timeout(250)

def open_all(pg):
    for bt in ["Choose", "Backup", "Custom"]:
        if pg.get_by_role("button", name=bt, exact=True).count():
            B(pg, bt).click(); pg.wait_for_timeout(120)

PROGRESS = {"currentNumber": 3, "mastered": [1, 2], "masteredEnd": {"1": 10, "2": 10}, "tempMastered": [], "tempMasteredEnd": 0}
YELLOW = {"currentNumber": 3, "mastered": [], "masteredEnd": {}, "tempMastered": [2], "tempMasteredEnd": 7}

def run(path):
    out = []
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={"width": 390, "height": 844})
        pg.goto("file://" + path)
        def add(tag, mask_digits=False):
            for l in pg.locator("body").inner_text().split("\n"):
                l = l.strip()
                if not l: continue
                if mask_digits: l = re.sub(r"\s*[×÷/]\s*", " ? ", re.sub(r"\d+", "#", l))
                out.append(f"{tag} | {l}")
        # 1. normal progress, every tab with sections open
        user(pg, PROGRESS)
        for t in ["Math Wiz Ladder", "Quizzes", "Challenge Tests"]:
            tab(pg, t); open_all(pg); add(t)
        tab(pg, "Math Wiz Ladder")
        B(pg, "2s").click(); pg.wait_for_timeout(150); add("ladder: passed 2s tapped")
        B(pg, "Type In · Random · Test ALL").click(); pg.wait_for_timeout(150); add("ladder: Test ALL")
        B(pg, "1–12").click(); pg.wait_for_timeout(200); add("pop-up: change range"); B(pg, "No").click() if pg.get_by_role("button", name="No", exact=True).count() else None
        B(pg, "Scores History").click(); pg.wait_for_timeout(250); add("history"); B(pg, "Go Back").click(); pg.wait_for_timeout(150)
        tab(pg, "guide"); add("guide steps")
        tab(pg, "buttons"); add("guide buttons"); B(pg, "Go Back").click(); pg.wait_for_timeout(150)
        # 2. quiz screen (digits masked: questions are random)
        tab(pg, "Math Wiz Ladder"); B(pg, "3s").click(); B(pg, "Start Quiz").click(); pg.wait_for_timeout(500)
        add("quiz screen", mask_digits=True)
        # 3. yellow badges: range warning pop-up
        user(pg, YELLOW); tab(pg, "Math Wiz Ladder")
        B(pg, "1–12").click(); pg.wait_for_timeout(200); add("pop-up: yellow badges")
        # 4. intro screens (v45+): first showing, all four screens
        pg.evaluate("""()=>{localStorage.setItem('times-tables-intro-v1:Ann','0');}"""); pg.reload(); pg.wait_for_timeout(700)
        for i in range(4):
            add(f"intro screen {i+1}")
            pg.wait_for_timeout(10300)  # Next is hidden for 10 s on the 1st showing
            nb = pg.get_by_role("button", name=re.compile("^(Next|Let's Go!)$"))
            if nb.count() == 0: break
            nb.first.click(); pg.wait_for_timeout(200)
        b.close()
    return out

old, new = run(sys.argv[1]), run(sys.argv[2])
so, sn = set(old), set(new)
print("ONLY IN OLD (removed or changed):")
for x in old:
    if x not in sn: print("  ", x)
print("ONLY IN NEW (added or changed):")
for x in new:
    if x not in so: print("  ", x)
