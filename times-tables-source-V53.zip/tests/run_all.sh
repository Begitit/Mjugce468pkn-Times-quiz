#!/bin/sh
# One-command regression run (v51). Usage, from the NEW source folder:
#   sh tests/run_all.sh PREV_DIR NEW_VERSION
# PREV_DIR = the previous version's unzipped source. If it holds a saved
# build (build/indexV*.html, saved in every zip since v51) that is used as
# the baseline; otherwise the previous source is built. Builds the new HTML
# into build/indexV{NEW_VERSION}.html, then runs code diff, logic checks,
# text inventory and scenario tests (the last two in parallel) and prints
# one short report. Full outputs: /tmp/tt_*.log
NEW="$(cd "$(dirname "$0")/.." && pwd)"; PREV="$1"; VER="$2"
[ -n "$PREV" ] && [ -n "$VER" ] || { echo "usage: sh tests/run_all.sh PREV_DIR NEW_VERSION"; exit 2; }
mkdir -p "$NEW/build"
NEWHTML="$NEW/build/indexV$VER.html"
PREVHTML="$(ls "$PREV"/build/indexV*.html 2>/dev/null | head -1)"
if [ -z "$PREVHTML" ]; then
  PREVHTML=/tmp/tt_prev.html
  [ -d "$PREV/node_modules" ] || ln -s "$NEW/node_modules" "$PREV/node_modules"
  sh "$NEW/tests/build_html.sh" "$PREV" prev "$PREVHTML" &
fi
sh "$NEW/tests/build_html.sh" "$NEW" "$VER" "$NEWHTML"
wait
cd "$NEW"
sh tests/code_diff.sh "$PREV" "$NEW" > /tmp/tt_codediff.log
node tests/logic_checks.mjs > /tmp/tt_logic.log 2>&1; LOGIC=$?
python3 tests/text_inventory.py "$PREVHTML" "$NEWHTML" > /tmp/tt_text.log 2>&1 & P1=$!
python3 tests/scenario_tests.py "$NEWHTML" > /tmp/tt_scen.log 2>&1 & P2=$!
wait $P1; TEXT=$?; wait $P2; SCEN=$?
echo "=== REPORT ($(basename "$NEWHTML")) ==="
echo "Removed code lines: $(wc -l < /tmp/tt_codediff.log)  (read /tmp/tt_codediff.log)"
echo "Logic checks: exit $LOGIC"; grep -v '^$' /tmp/tt_logic.log | tail -15
echo "Text inventory: exit $TEXT"; cat /tmp/tt_text.log | tail -60
echo "Scenario tests: exit $SCEN"; grep -E 'FAIL|CHANGED|AWAITING|FIXED|tests in' /tmp/tt_scen.log | tail -25
