# Times Tables — readable source

This is the full readable source for the Times Tables quiz app (React,
bundled into a single `index.html` for GitHub Pages hosting / direct
download). The shipped `index.html` file is a minified bundle built
FROM this source — if you're picking this project back up in a new
chat, work from these files, not from the minified output.

**If you are Claude, reading this at the start of a new chat:** read
this whole file before touching any code. It replaces needing the
prior conversation's history — everything decided, built, and still
pending is captured here. Ask the user to upload `times-tables-source.zip`
(or unzip it into your working directory) before making any changes.

Older history (v39 and earlier) is in CHANGELOG.md.


## Audit plan (started after v48) — DONE at V49

V49 built the whole "Q for V49" list below (items 1, 2 choice B, 3, 4 choice
A, 5a, 5b, 10, V1, V2, Start Quiz, stale comment, README cleanup). Nothing
from the audit is open. Kept as a record and as the method for the next full
"Notes-vs-code audit" (every 10–20 builds or when stuck).

Why: several notes/README entries turned out not to match the code (Challenge
was multiple choice; In Order saved its place at quiz START though the note
says "after the last finished quiz"; the results count included repeats; stale
README items). The user asked for a systematic check.

Steps (user's plan — do 1-3 ONLY, then stop for the user to judge go / no-go):
1. List the claims: every statement about behavior in the app's visible text
   (notes under settings, the Guide, intro screens, pop-ups, results messages)
   and in this README (Key design points, then the changelog).
2. Keep only current rules: many changelog entries were replaced later; check
   each feature against its LATEST rule only.
3. Check each claim against the code: read the code that does it and mark it
   MATCHES / MISMATCH / UNCLEAR, with the file and line.
4 = scenario tests (Playwright) for behavior not visible on screen, and
5 = keeping them in tests/ so every build re-runs them: DONE Oct 2026 in a
tests-only session (times-tables-source-V48-tests.zip, no app change) —
`tests/scenario_tests.py`, see "Regression checks" step 5.

Priority order: what kids read in the app first, then Key design points, then
the latest changelog entry for each feature. A chat holds limited context, so
split the work into chunks (e.g. Ladder tab; Quizzes + Challenge + Guide;
README), one chat each.

Audit log (each chat adds what it checked, what matched, what was found;
fixes are NOT built during the audit — findings go to the user to decide):
- Noticed at v48, not yet decided: the Quizzes tab button reads "Start quiz"
  (lowercase q) while the Ladder reads "Start Quiz".
- Oct 2026, notes-vs-code audit #1 on V48 (steps 1–3: app visible text, README
  Key design points and feature sections, latest changelog rule per feature).
  No code changed. Status: FIX = agreed fix, DECIDE = direction not chosen,
  KEEP = intended, MAYBE = Maybe bin. Test ids = tests/scenario_tests.py.
  1. FIX — Senior Math Wiz 12 never shows: passing 1–12 at End 12 shows "Royal
     Math Wiz 12" (header and PASSED line) because of the Royal tie-break (tie
     at 11/12 forces End 20; logic.js currentTitleFor, app.jsx header ~899).
     Contradicts Guide Steps, Challenge 12 title, Ladder pill, v45 intent.
     Senior 12 shows only when chain A has a gap below 12. Tests T2, T3.
  2. DECIDE — "range too small" Test ALL warning ("…will not count towards
     passing a Wiz Ladder step…", highest partner < 10) is not enforced: End 10
     + SKIP On passes GREEN, End 5–9 passes YELLOW. Also old name "Wiz Ladder".
     Enforce, or reword/remove. Tests P2, P3 (record current behavior).
  3. FIX — fail pop-up Stop on the last question: README v44 says normal finish
     (saved), but in Normal/Fast a miss adds an immediate repeat, so the paused
     queue is never empty and it is treated as stopped (not saved). Only right
     in Fastest. Stop handler app.jsx ~1083. Tests P6 (fix), P7 (Fastest).
  4. DECIDE — a yellow number can't turn green: reallyStartLadderQuiz treats
     yellow as passed, so Test ALL on it at a narrower canonical End is
     practice; it stays yellow until End is widened past its End (which wipes
     it). The finishQuiz yellow→green code is unreachable. Test P8.
  5. FIX (code or Guide wording) — title chains vs Guide: chain B ignores End
     ([11,12,13] with 11/12@12, 13@20 → "Royal Math Wiz 13" though "These are
     learned through times 20"); with SKIP On, 1 and 10 are skippable in chain
     A (2–9, 11, 12 → title 12) though the Guide intro says every number
     step. Tests T4, T5 (pass when either the code or the Guide text changes).
  6. MAYBE — Test ALL notes ("gives ALL questions", "always tests everything")
     vs upgrade test asking only facts not yet passed. Act only on complaints.
  7. KEEP — a finished Quiz Length ALL quiz does not reset the In Order place.
     Test O2.
  8. Undecided, current behavior recorded — In Order bookmarks: Quizzes has
     one bookmark keyed Math Types|Start|End|SKIP (poolSignature), overwritten
     only when a quiz finishes with other settings; Ladder has one per number +
     same key (seqCursor). Ignored: Choose vs Type In, Quiz Length, Speed,
     Division Symbols, New Facts Only (same bookmark, different list → lands
     elsewhere); Ladder key includes Start though Start doesn't change Ladder
     questions. The app note "leave all the settings the same" is safe, just
     stricter than needed. Tests O3, O4, O6.
  9. KEEP — a slow-but-correct repeat answered slowly repeats again, no limit.
     Test R2.
  10. FIX — resume after closing during answer feedback skips that question
     and loses its count (10 Qs, close during #3 → "9 correct · 0 missed",
     History 90%): the queue moves at submit but the saved stats are the
     snapshot from before the answer. Fix: snapshot after the answer, or
     restore the answered question. Test C2. FOUND WHEN WRITING THE TESTS:
     the same lag happens when closing BETWEEN questions (no feedback showing)
     — the persist effect saves the queue at submit with the old snapshot and
     does not re-save when the next question appears, so the last answer
     before closing never counts. Test C4. Same fix should cover both.
  Q for V49 (agreed): results button "Back to Quiz Ladder" → "Back to Math
  Wiz Ladder" (test V1); instant upgrade pop-up adds "You are now a …!" when
  the title changes (test V2); fixes for 1, 3, 5, 10; decisions on 2 and 4;
  keep "Not quite — it's 12"; "Start quiz" vs "Start Quiz" already logged.
  Code comment above startLadderQuiz (~577) is stale (yellow clearing moved to
  the Range pop-up in v44) — update, no behavior change.
  README cleanup to apply at V49: fix or delete obsolete text in current-rule
  sections, leave changelog entries as history, move entries older than ~v40
  to CHANGELOG.md (README top: "Older history is in CHANGELOG.md"). Stale
  items: out-of-range mastered "dimmed/locked" (gone v43); custom "APPLY" (now
  SET RANGE); Questions Mode caption + Ladder no longer using
  QuestionsModeSection; Ladder Speed margin override (none); Speed "always
  visible" (Ladder: only once a number is selected); Speed caption quote ("no
  repeated questions"); two-pass badge terms (tempOne, tempCurrentZero — only
  tempCurrent exists); title icon size missing Diamond 0.99em; Guide tab
  "Levels" + old intros, "Important Steps" header, pill sizing (minWidth 150 +
  allowShrink), Buttons tab "Ready / When Tapped", "Important step button";
  File structure missing IntroScreen, NameGate, Toast; Royal tie-break, fail
  pop-up last-question and v48 resume text (update with fixes 1, 3, 10).
  README self-conflicts: build shell title/zip name vs versioned rule
  (versioned wins); orphan line in Pending section.
  Also noticed when writing the tests (not decided): after a resumed
  Quizzes-tab quiz, "Back to Quizzes" lands on the Ladder tab (the open tab
  isn't saved).
  Matched (no action): intro screens/delays/Skip; Speed caption, delays,
  threshold halving; ALL note; Division Symbols; SKIP/Auto; Range pop-ups incl.
  yellow-badge condition; Custom End note; Ladder intro; "already passed"
  note; New Facts Only empty state; Challenge intro/allowance/backfill/Type
  In/totals; fail pop-up text/Work on lists; results titles/counts/PASSED
  lines; upgrade pop-up; History rows/labels; stopped quizzes not saved;
  Backup all users; Teacher threshold 1–30; Buttons tab labels; tab settings/
  defaults; mastered persist; range confirm both tabs; dev toggle; 3-user
  limit; passwords; spinner; title table, icons, King offsets, UserBar rule;
  v40–v42 step rules; v41 presets; v36 bracket; v31 threshold/÷; v27 repeat
  labels.
  Testing setup agreed: regression checks every build; "Changes-notes-vs-code
  audit" in every build's regression report (only the app notes, Guide and
  README lines that build touched); full "Notes-vs-code audit" every 10–20
  builds or when stuck; saved scenario tests run every build (new behavior
  gets a saved test — no one-off unsaved test runs).

## How to rebuild the shipped HTML file

```
npm install
npx esbuild src/index.jsx --bundle --minify --format=iife --jsx=automatic --outfile=bundle.js
```

Then wrap `bundle.js` in this HTML shell and save as the final file:

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="robots" content="noindex" />
    <title>indexV{nn}</title>
    <style>
      html, body, #root { height: 100%; margin: 0; }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script>
      /* paste bundle.js contents here */
    </script>
  </body>
</html>
```

Always present BOTH the rebuilt `indexV{nn}.html` and a fresh
`times-tables-source-V{nn}.zip` (`zip -r times-tables-source-V{nn}.zip src
tests build README.md CHANGELOG.md package.json -x "node_modules/*"`; since
v51 `build/` holds that version's indexV{nn}.html) after every
build, via the file-share tool — never just one or the other. (Versioned
names win over plain ones — see "Version-tagged filenames" below.)

## The single most important rule for working on this project

**Only the literal word "build" (as its own clear instruction) changes
code.** Every other phrasing — "let's try X", "make it Y", "queue this",
even a direct imperative like "use that color everywhere" — is a
decision to note and hold, not an instruction to act on yet. This
project's owner works by iterating out loud over many messages before
committing, and voice-typing sometimes turns "queue this" into "do
this" by accident, so the bar is deliberately strict: literally nothing
else triggers a code change, no matter how explicit it sounds.

**Command words:**
- **"build"** — the only trigger that changes code (see steps below).
- **"Q"**, **"Q?"**, or **"queue"** (spelled out) — show the current queue.
- **"pin it"**, **"pin this"**, or **"pending"** — synonyms for "add to
  queue" (same as the default note-and-hold behavior, just an explicit
  ask to confirm it's captured).
- **"future"** or **"hold off"** — don't add to the active queue; just
  remember this as a possible idea for later (goes in "Hold-off /
  future items" below, not the "Pending" build queue).

When "build" finally arrives:
1. Gather everything currently queued that is unambiguous and not on
   hold.
2. List it out concisely before touching code, so there's a last
   chance to correct anything.
3. Only then edit, rebuild, and present the files.

If it's unclear whether something is confirmed or just a passing
thought, ask rather than guess — this user corrects specs over many
rounds before locking them in (colors, sizes, trigger logic have all
gone through multiple revisions) and treats every detail as provisional
until explicitly confirmed.

Two things NOT to reach for as a substitute for a real build:
- The Visualizer / inline widget tool (`show_widget`) is for previews
  only — mockups, color comparisons, icon previews. Never a substitute
  for actually editing the source when the user says "build."
- A file that's written but never rebuilt+presented does not exist to
  the user. If code was edited in a prior turn but not yet shipped,
  say so plainly rather than letting it look finished.

## File structure

- `src/logic.js` — all pure logic: storage keys/helpers, question-pool
  generation, quiz-queue building, mastery-test pool logic, formatting
  helpers, default settings, and the title system (`titleForNumber`,
  `isCanonicalEnd` — see "Badge & title system" below).
- `src/styles.js` — all style objects (the `s` export) and `globalCss`.
- `src/components.jsx` — shared UI atoms: PasscodeGate, ConfirmModal,
  YesNoModal, Toast, Section, SegGroup, NumberField, IntroScreen
  (+ INTRO_SCREENS), NameGate, UserBar, and the shared
  icon/title components: `DiamondIcon`, `CrownIcon`, `tierIconForTitle`,
  `TitleWithIcon`, `MilestoneButton`.
- `src/setup.jsx` — the Setup-screen sections, QuizzesPanel /
  LadderPanel, `ShieldBadge`, `TriangleMarker`, `BadgeGallery`,
  `LevelsList`, `GuideScreen`, `milestoneFor`.
- `src/quiz.jsx` — QuizScreen, ResultsScreen, HistoryScreen.
- `src/app.jsx` — the main state machine: user management, settings,
  quiz flow, ladder mastery logic, dev preview toggle, `currentTitle`
  computation, screen routing (adds `"guide"` alongside the existing
  `"setup"/"quiz"/"results"/"history"` values).
- `src/index.jsx` — mounts `<PasscodeGate><App /></PasscodeGate>`.

## Key design points to know before changing anything

- **Quizzes and Ladder tabs have fully independent settings**
  (`quizSettings` / `ladderSettings` in app.jsx) for Math Operation,
  Range (Start/End), Exclude Easy, and Quiz Length. Default Math
  Operation is Multiplication; default Range is 1–10, both tabs.
- **Ladder step numbers vs. partner width are two different things.**
  `ladderStepNumbers`/`rangeNumbers(start,end,excludeEasy)` decides
  which numbers show as ladder buttons. `numberPool(number, {end,
  excludeEasy})` always tests partners `1..end`, regardless of `start`.
- **Passing a number** (current rule, v42–v49):
  - A number is passed by a Type In · Random · Test ALL with no more
    first-try misses than the allowance (1 per full 100 questions).
  - Any unpassed number inside the Ladder range can be passed; the ▲ step
    is only a suggestion.
  - Test ALL on numbers 1–10 always includes the 1 and 10 partners (×1,
    ×10, ÷1, ÷10) whatever SKIP is set to (v49, `masteryTestPool`). SKIP
    still applies to numbers 11 and up.
  - Green vs yellow is set by the End (next bullet).
- **Green vs. yellow, rounded End (v49).** `passEndFor(end)` (logic.js)
  rounds the Ladder End DOWN: 9 or lower → null (yellow / practice),
  10–11 → 10, 12–19 → 12, 20 → 20. A pass with a rounded End → green
  (`ladder.mastered`, `ladder.masteredEnd[n]` = the rounded End). End 9 or
  lower → yellow (`ladder.tempMastered`, `ladder.tempMasteredEnd`), which
  lets the ▲ move past that number but never counts toward a title or the
  Facts Passed Rule. The PASSED message and the History row show the
  rounded End ("7s up to 12 PASSED!" for a pass at End 15). Making the End
  bigger than `tempMasteredEnd` while yellow badges exist shows the "Lose
  your yellow badges?" pop-up (Range section), which clears them; narrowing
  never does. A yellow number is never a pass attempt (choice A, v49), so
  it turns green only by being passed fresh after that pop-up.
  `isCanonicalEnd` (10/12/20) is now used only by the one-time masteredEnd
  backfill for very old data. `Start` never gates anything — only `End`.
  v51: a pass at End 13–19 ALSO adds a yellow badge for that End ("Yellow
  above 12"); yellow pills show their End ("12s to 16").
- **Practice Start (v51, Ladder only)** — `practiceStart` picks where a
  practice quiz's partners begin (`practicePool`); Test ALL ignores it.
- **Mastered numbers persist forever per user**, never pruned when
  Range changes — the ladder's displayed list is the union of current
  in-range step numbers and every number ever mastered. Passed numbers
  always render fully bright (v43 removed the dimmed/locked styles).
- **Milestone buttons are never dimmed either** — this was a real bug
  (a stray hardcoded `opacity: 0.9`) that's now fixed; don't reintroduce
  it.
- **Range changes require a confirm prompt** (Yes/No, no passcode) in
  both tabs before applying, via `pendingRange` + `YesNoModal` in
  `RangeSection`.
- **Dev preview toggle** ("Default Settings" vs "Current Settings") is
  gated to usernames matching `/^BD[\s-]*\d+$/i` — see `isDevUser` in
  logic.js. The Badge Gallery used to live behind this toggle; it does
  NOT anymore (see Guide page below) — it's a normal, always-available
  page now.
- **User limit is 3** per the whole app.
- **Passwords** (unchanged since the first version, only the on-screen
  label was renamed from "Passcode" to "Password"): app entry
  `VeggiesNotsugar`, delete/teacher `Deletesugar` — the underlying
  constant names (`APP_PASSCODE`, `TEACHER_PASSCODE`) and component
  name (`PasscodeGate`) were left as-is, display text only changed.
- **Custom NumberField spinners**: press-and-hold repeat, 450ms initial
  delay then every 125ms. Native number-input spin arrows are hidden
  everywhere (`globalCss`) — custom buttons are the only increment UI.
- **History row operation tag**: "Mode - MPLY/Div./Both"; avg-time and
  total-time render in full white (`s.historyTimeValue`, `#FFFFFF`).
- **Custom-range "SET RANGE" button** (was APPLY, renamed v23), with a
  "Go Back" button beside it (v47) — `RangeSection` in setup.jsx.
- **In Order note** (`QUESTIONS_MODE_NOTE` in setup.jsx, Quizzes tab and
  Ladder tab; the Ladder renders its own mode stack, not
  `QuestionsModeSection`): "The In Order types remember your place. After
  the last finished quiz, this app will start next time right where you
  left off. You have to leave all the settings the same for this to work."
  The place is saved only when a quiz finishes (v48). See audit item 8 for
  exactly which settings the bookmark key uses.
- **Ladder tab's Test ALL sentence** renders below the mode button stack.
- **`Section` (components.jsx) accepts an optional `style` prop**, and
  `SpeedSection` forwards one; no call site uses it now (the old Ladder
  Speed margin override was removed in v20 when spacing became 36px).

## Speed section & repeat labels

Replaces the old binary Test Mode Off/Faster toggle, which only
appeared on the Ladder tab and only for Type In · Random.

- **`speedMode`** (`"normal" | "fast" | "test"`) lives in both
  `quizSettings` and `ladderSettings` independently (default
  `"normal"`), replacing the old `ladderSettings.testMode` boolean.
  `normalizeSettings` in app.jsx folds any old saved `testMode` into
  `speedMode` on load (`true` → `"test"`, else `"normal"`) so existing
  users' saves keep working.
- **SPEED section** (`SpeedSection` in setup.jsx) on the Quizzes tab, the
  Ladder tab (only once a number is selected) and the Challenge Tests tab;
  applies regardless of which question mode is selected. Three
  buttons: **Normal** (no caption originally, now always shown),
  **Fast**, **Fastest**. Static caption below the buttons (not
  conditional on selection): "Normal is for learning. Fast has shorter
  times. Fastest has shorter times and no repeated questions." (display labels
  only — the underlying `speedMode` values are still `"fast"`/`"test"`).
- In `advanceAfterAnswer` (app.jsx), `speedMode === "test"` disables
  all repeat insertion (same as the old testMode gate) and both
  `"fast"` and `"test"` share the shorter 1750/2500ms delay; `"normal"`
  keeps the original per-answer-mode delays.
- **Fast/Fastest also halve the slow-answer threshold** used for the
  "correct but slow → gets repeated" mechanic and for History's
  "X over N sec. limit" stat — NOT the same thing as the post-answer
  delay above. Base value is the Teacher Settings `slowThresholdSeconds`
  (default 5, already a real adjustable setting, 1–30 — this was
  already "a variable, not hardcoded text" per how it was built).
  `effectiveThresholdSeconds = speedMode !== "normal" ? base / 2 :
  base` is computed independently in two places that both need it:
  `submitAnswer` (for `wasSlow`, live per-answer) and `finishQuiz` (for
  the log entry's `overLimitCount` and `slowThresholdSeconds` field).
  The log now stores the EFFECTIVE threshold actually used for that
  specific quiz run (halved when applicable), not just the base
  setting — so History's display line always reflects what really
  happened in that run rather than silently showing the base number
  even when Fast/Fastest was active. Old log entries predating this
  field still fall back to `?? 5` in the display (quiz.jsx).

### Repeat-scheduling logic (redesigned twice — `advanceAfterAnswer` in app.jsx)

The wrong-answer and slow-answer branches were reworked in two passes.
The first pass (a "wrong twice in a row escalates to delayed" design)
was WRONG and got corrected the same session — kept here briefly since
it explains why the code comments mention "wrong twice in a row" as a
discarded idea:

- **First attempt (discarded)**: wrong → immediate repeat; wrong AGAIN
  on that repeat → escalate to delayed. This was my own guess at
  reconciling "wrong answers repeat immediately" with "delayed repeat
  reserved for wrong answers" — flagged as an interpretation, not
  confirmed first. The user corrected it: a wrong answer should always
  repeat immediately, AND if that immediate repeat is then answered
  CORRECTLY, it should ALSO still get a separate delayed check-back —
  not "wrong twice in a row," but "wrong once, then right." This
  correction is directly why the stored build agreement (see below) now
  says to resolve any uncertainty or apparent conflict with the user
  BEFORE building, even after "build" is said — this was the case that
  prompted adding that rule.

**Current, corrected design (v27):**

- **Any wrong answer** (Choose or Type In, no distinction) → always an
  immediate repeat (front of queue, next question), tagged `repeatKind:
  "immediate"`. No gate, no cap — always happens, every time, matching
  how Type In always worked; Choose now matches it too (previously
  Choose wrong answers were delayed 3-6 questions later, capped at one
  — that delayed-on-first-wrong path is gone entirely).
- **That immediate repeat then gets answered CORRECTLY** (fast or slow
  — speed doesn't matter for this trigger) → schedules ONE additional
  delayed check-back (`repeatKind: "delayed"`, `repeatsUsed`
  incremented), capped by `canRepeatAgain` (`repeatsUsed < 1`) so it
  only happens once per fact. This is checked via `fact.repeatKind ===
  "immediate"` — i.e. "this fact just came from a wrong-answer
  immediate repeat" — before the slow-answer branch below, so a
  wrong-then-slow-correct answer goes through this path, not the
  slow-but-correct one.
- **Slow-but-correct answers** are a genuinely separate trigger from
  wrong answers, and apply to Choose mode too (`wasSlow` in
  `submitAnswer` has no `effectiveAnswerMode === "type"` gate — timing
  is tracked for both modes via `startTimeRef`). Every slow-but-correct
  answer, no matter how many times in a row it happens to the same
  fact, just gets ONE immediate repeat, tagged `slowRepeat: true` (kept
  as its own tag, separate from `repeatKind`). **It never escalates to
  a delayed check-back** — that's the one structural difference from a
  wrong answer, which does eventually earn a later delayed repeat (via
  the wrong-then-correct path above). A v25/26 version of this logic
  DID escalate a second consecutive slow-but-correct answer to a
  delayed check-back, matching the wrong-answer path — that was wrong
  and got corrected in v27 after live confirmation of the intended
  design: slow-but-correct is a two-stage-only mechanic ("Will repeat"
  then "Repeating"), full stop; only a wrong answer ever reaches a
  later, delayed "Repeat".
- **`willRepeat`** (drives the "Will repeat" banner) is `(!wasCorrect
  || wasSlow) && !testModeNow` — covers both wrong answers and
  slow-but-correct answers, since both always lead to an immediate
  repeat. The old separate `repeatFlag` state (which used to drive a
  mislabeled "Repeat" banner for slow-but-correct on the reveal screen)
  is gone — folded into `willRepeat`.
- **Three repeat labels**, all using the existing `s.repeatBanner`
  font/layout, none shown when `speedMode === "test"`:
  - **"Will repeat"** — shown on the answer-reveal screen right after
    a wrong answer OR a slow-but-correct answer (`willRepeat`).
  - **"Repeating"** — shown atop the very next question when it's an
    immediate repeat, whether that repeat came from a miss
    (`repeatKind: "immediate"`) or from a slow-but-correct answer
    (`slowRepeat`) — reachable from BOTH Choose and Type In (resolves
    the hold-off item about "Repeating" showing up in Choose mode —
    it's correct behavior, not a bug).
  - **"Repeat"** — shown atop a question that's a delayed re-insert
    (`repeatKind: "delayed"`), reachable ONLY via wrong-then-correct.
    Slow-but-correct never produces this label, at any repeat count.

## Badge & title system (built across this whole session — the bulk of recent work)

**Shields and markers on the ladder** (`ShieldBadge`, `TriangleMarker`
in setup.jsx), absolutely positioned so badge size never affects the
button's own box:
- Green filled shield + gold star = canonical mastery (numbers 1–10,
  and 11/12 if mastered under a canonical End of 12 specifically).
- Yellow (light yellow, `#FFF176`) **outline** shield = temp mastery.
  The star/numeral drawn inside always matches the shield's OWN current
  color — light yellow when untapped, black when tapped (`active`
  prop) — never a fixed color independent of the badge. When tapped,
  the star becomes an unfilled outline (not solid black), and is
  scaled down ~10% (via a `<g transform="scale(0.9)...">`, NOT a
  thinner stroke — the user explicitly asked never to narrow the
  stroke width, since an SVG stroke draws centered on the path and
  bleeds outward regardless of width) so it clears the shield's edge.
- Green numeral badge = one clean pass (not yet a second pass), same
  outline/temp treatment as above when non-canonical. The numeral on
  the real/green-filled version specifically renders yellow
  (`#FFF176`, `numeralColor` in `ShieldBadge`) rather than the star's
  gold (`#E8B94A`, `contentColor`) — gold-on-green was hard to read
  for the digit; the star elsewhere on the same badge type is
  unaffected and stays gold.
- Plain upward triangle (`TriangleMarker`, `currentColor` fill) = the
  active current-track number with 0 passes so far, under a canonical
  End.
- **Current-step button brightness**: the canonical current-step
  button (0-pass triangle, or 1-pass green numeral) used to share the
  exact same dimmed `quiet` (`rgba(237,234,224,0.65)`) color/border as
  an ordinary not-yet-reached number — no visual distinction from a
  ladder step you haven't gotten to at all, aside from the icon.
  Bumped to full-strength `#EDEAE0` (the same off-white/cream used for
  primary text everywhere else, just no longer dimmed) specifically
  for `isCurrent && !tempOne && !tempCurrentZero` — i.e. this only
  touches the canonical current-step case; the short-range (temp)
  current-step variants already have their own distinct gold-bordered
  treatment and are unaffected.
- **(Current names, since v18/v49:** only `tempCurrent` exists now —
  `isCurrent && passEndFor(settings.end) == null`, i.e. End 9 or lower.
  `tempOne`/`tempCurrentZero` below are the pre-v18 names; the one-pass
  badge itself is gone.)
- **Short-range (temp-End) variants** of the one-pass and current-step
  states get their own gold-bordered treatment, matching the existing
  short-range-mastered look:
  - `tempOne` (one clean pass, non-canonical End) and `tempCurrentZero`
    (0 passes, non-canonical End) are computed alongside `tempMastered`
    in setup.jsx's ladder render, each getting `{ color: YELLOW,
    borderColor: GOLD, borderWidth: 2, padding: "8px 9px" }` when
    untapped — previously `tempCurrentZero` had no distinct border
    treatment at all (just whatever the default quiet/dim style gave
    it) even though its badge icon already looked temp-specific; now
    all three short-range states (mastered/one-pass/current) share the
    same gold-border language. The "Ns" number label color moved from
    gold to yellow (`YELLOW`, not `GOLD`) on ALL THREE — gold-on-gold
    for the label was the same low-contrast problem as the numeral fix
    above, just for text instead of an SVG fill.
  - `TriangleMarkerTemp` (setup.jsx) is `tempCurrentZero`'s icon: a
    yellow triangle when untapped (`<TriangleMarker color="#FFF176" />`
    — `TriangleMarker` gained an optional `color` prop for this,
    defaulting to `currentColor` as before), or when tapped, a solid
    black circle (r=8.6 in a `viewBox="-3 -3 18 18"`, `1.89em`) behind
    the same yellow triangle — plain yellow-on-gold (the tapped
    background) had almost no contrast, hence the circle. The circle's
    size and the viewBox/physical-size scaling were worked out via an
    iterative visual preview (Visualizer widget), not calculated from
    a formula — an early version clipped the circle into a rounded
    square because the viewBox was too small for the enlarged radius.
  - `TriangleMarker`'s own shape was separately enlarged app-wide (not
    just for the temp variant): path changed from `M6,1 L8.2,11
    L3.8,11 Z` to `M6,0.25 L8.53,11.75 L3.47,11.75 Z` (~2px taller at
    the button's actual font-size, proportionately wider, same
    `viewBox="0 0 12 12"` and `1.26em` sizing so it still scales with
    the button like before). This affects every current-step triangle
    in the app, canonical or not, since both `TriangleMarker` and
    `TriangleMarkerTemp` share the one path.
- **Universal number/icon layout** (`hasShield` in setup.jsx's ladder
  render, and the equivalent in `BadgeGallery`'s `renderCell`): every
  icon-bearing button now shifts its "Ns" number to `left: -1.1em` and
  anchors its icon at `right: 0.73em` (or, for icons with their own
  already-tuned position — the short-range-current-step tapped circle
  at `right: 0.55em`, sized to avoid clipping — that specific position
  is left alone). This used to be inconsistent: the green numeral
  ("one clean pass") and the plain current-step triangle were NOT
  shifted at all, while star/temp-star/temp-one were. Settled through
  an iterative visual-preview pass (Visualizer widget, several rounds)
  rather than a single rule reasoned out up front — e.g. an early
  attempt shifted every icon uniformly, which revealed Crown (15) was
  fine but King (20, a 3.6em icon — double Crown's 1.8em) still
  overlapped the number even with the shift.
  - `hasShield` simplified to `mastered || tempMastered || isCurrent`
    (in the real ladder render) — covers every one-icon state in one
    check, since `tempOne` and `tempCurrentZero` are themselves both
    subsets of `isCurrent`, so listing them separately was redundant
    once the shift applies universally.
  - **King (20) is the one deliberate exception**, arrived at last:
    number shifts to `left: -1.6em` (not the usual -1.1em) and the
    crown icon moves to `right: 0.2em` (not the usual 0.73em) — both
    moved together by the same additional ~0.5em so their spacing
    relative to each other stayed the same as everywhere else, just
    the whole pairing shifted further left as a unit to clear the
    button's edge. Checked via `royalOrCrown === "king"` at both spots.
- **Diamond / Crown / King** (`DiamondIcon`, `CrownIcon` in
  components.jsx) — no shield behind them, gold fill: Diamond for
  11–14, Crown for 15–19, King for 20 — all only when that number was
  passed at End 20 (v49; 11–19 can also be green at End 10 or 12, which
  shows the plain green shield and star). King (20) gets the
  same Crown shape at DOUBLE size — an explicit placeholder for a
  "huge fancy crown" that's still to be designed (see Hold-off items).
  Computed via a `royalOrCrown` variable right next to the badge
  ternary in setup.jsx's ladder render.

**Titles** (`titleForNumber(n, endUsed)` in logic.js, returns
`{bare, numbered}`):
- 1–4: "Math Learner n". 5: bare "Junior Math Wiz" (6–9: "Jr. Math Wiz
  n"). 10: bare "Math Wiz!" (note the exclamation point — renamed from
  plain "Math Wiz" mid-session, in BOTH bare and numbered forms since
  they're identical for n=10).
- 11–12: "Senior Math Wiz n" if `endUsed===12`; "Royal Math Wiz n" if
  `endUsed===20` (bare form "Royal Math Wiz"); `null` otherwise.
- 13–14: "Royal Math Wiz n" only if `endUsed===20`, else `null`.
- 15: "Crown Math Wiz" — bare AND numbered are identical (no number),
  matching how 5 and 10 work — this was an explicit fix; don't let 15
  drift back to "Crown Math Wiz 15". 16–19: "Crown Math Wiz n" (WITH
  the number), only if `endUsed===20`, else `null`.
- 20: bare "Math Wiz King".
- Title icon sizes (`TitleWithIcon`): King 1.7em, Diamond 0.99em (see
  the Known issue note), every other tier 1.36em.

**Current-title display** (next to the username, `app.jsx` →
`currentTitle`, rendered via `TitleWithIcon` in the UserBar): now
always uses the **numbered** form (`titleForNumber(...).numbered`).
This was previously bugged — it always used `.bare`, which silently
dropped the number for every tier except Senior Math Wiz at 12 (the
one case with a special-cased override). Fixed two ways: (1)
`titleForNumber`'s bare value for n=1–4 was changed from `"Math
Learner"` to `"Math Learner ${n}"`, matching how 5/10/15/20 already
had bare===numbered by design; (2) `currentTitle` now just always
reads `.numbered` instead of conditionally picking `.bare`/`.numbered`
based on n===12. Net effect: every tier with a genuinely distinct
numbered form (2–4, 6–9, 11, 12, 13, 14, 16–19) now shows its number
next to the username, same as in the Levels list. Milestone tiers (5,
10, 15, 20) still display unnumbered, because bare and numbered are
identical strings for those — there's no number to show, not a
special case being applied.
Two independent "chains" (logic.js `chainHighestReached`, used by
`currentTitleFor` for the header and the pass messages, and by the
milestone pills — one shared rule since v45/v49):
- Chain A, 1–12 (Learner → Junior → Wiz → Senior): every number 1..n must
  be passed, including the 1s and 10s whatever SKIP is set to (v49, audit
  5b). 11 and 12 count only when passed at End 12 or more. Its 11/12 title
  is always the Senior form.
- Chain B, 11–20 (Royal → Crown → King): counts a number only when passed
  at End 20 (v49, audit 5a). Never gated by chain A.
- Chain B wins whenever it has begun; otherwise chain A. Neither is gated
  by `Start`.
- SKIP On hides the 1s and 10s as Ladder steps, so a Ladder note under the
  SKIP buttons (only when SKIP is On and the Range touches 1–10) says:
  "To win a title through Step 12, set SKIP the EASY FACTS to Let App
  Pick, or to Off. The 1s and 10s are steps you need to pass." (v50 wording)
- The old Royal tie-break (11/12 tie forced Royal) was removed in v49: it
  made 1–12 at End 12 show Royal instead of Senior (audit item 1).

**Milestone pill sequential gating** (`sequentialProgressReaches` in
setup.jsx's `LadderPanel`, used to gate the `milestone` variable):
the milestone pill (5/10/12/20 — see below) used to appear purely from
that number's own `mastered` flag, with no check that earlier numbers
were mastered first — so passing numbers out of order (allowed since
v43) could show a milestone pill
before it was genuinely earned in order. Fixed by computing the same
"stop at first gap" `chainAHighest`/`chainBHighest` logic locally in
`LadderPanel` (now the shared `chainHighestReached`) and requiring
`sequentialProgressReaches(n)` (`chainAHighest >= n` OR `chainBHighest
>= n`) before the pill can show. A number's own badge/icon on its
button (star/diamond/crown/king) is explicitly NOT gated by this — it
still shows honestly per-number the moment that number is mastered,
regardless of order; only the milestone pill (an actual title/
achievement banner) requires the uninterrupted chain.

**Milestone buttons** (`MilestoneButton` in components.jsx, shared by
the real ladder AND the Levels page so they can't drift apart) appear
next to a mastered badge at specific trigger numbers — computed inline
in setup.jsx's ladder render (the `milestone`/`milestoneTitle`
variables) and via the standalone `milestoneFor(n, endUsed)` helper for
the Levels page:
- **5** → Junior Math Wiz. **10** → Math Wiz!. **20** → Math Wiz King.
  Always fire, bare title.
- **12** → Senior Math Wiz 12 (the one exception that shows a number)
  — fires ONLY if `ladder.masteredEnd?.[12] !== 20` (i.e. NOT the Royal
  path). If 11/12 were earned under End=20, there is NO milestone
  button for that slot, ever — Royal Math Wiz has no milestone trigger
  at all, anywhere.
- **15** → Crown Math Wiz, bare. New trigger, didn't used to exist.
- 11, 13, 14, 16–19 never trigger a milestone button.
- Star tier gets a small gold star flanking BOTH sides of the title
  text (`flankStar` prop on `TitleWithIcon`) — pill icons pass
  `starIconSize="1.36em"` explicitly. Crown and King tiers ALSO flank
  with their own icon (Crown on both sides) — extended from star-only
  after the fact, so check `TitleWithIcon`'s flanking condition if this
  needs touching again. Diamond tier does not flank (never asked for).
- The gold text-glow (`text-shadow: 0 0 6px rgba(232,185,74,0.85)`)
  applies to every `TitleWithIcon` render — current title AND milestone
  buttons — added as a deliberate "make titles feel more impactful"
  pass partway through the session.
- **Icon-size bug fix**: `TitleWithIcon`'s size logic used to be `tier
  === "king" ? "1.7em" : tier === "star" && starIconSize ? starIconSize
  : "0.85em"` — the middle branch only honored a caller's `starIconSize`
  when the tier was literally `"star"`, so the Crown milestone pill
  (tier="crown") silently ignored the `1.36em` it was passed and fell
  back to 0.85em, while Junior/Wiz/Senior pills (tier="star") correctly
  got 1.36em — five milestone pills, three different rendered sizes,
  despite all five passing the same value. Fixed to `tier === "king" ?
  "1.7em" : (starIconSize || "1.36em")`, which also fixed a second bug:
  the username's `TitleWithIcon` call (components.jsx's `UserBar`)
  never passed `starIconSize` at all, so it fell back to the OLD
  0.85em default — now it gets the same 1.36em everything else gets.
  Net effect: pill icons and the username icon are now provably the
  same size for every tier except King (still separately 1.7em in
  both places, on purpose).

**UserBar two-line layout** (`UserBar` in components.jsx): name and
title used to share one wrapping flex row, with the Switch user button
always anchored to that same row — name+title together often didn't
fit on one line on narrow screens, especially once the icon-size fix
above made title icons bigger. Restructured to two separate rows: name
alone on row 1, title (if the user has one yet — a new user with no
title just gets row 1) alone on row 2. The Switch user button attaches
to whichever row is shorter, right-aligned via `s.userBarTopRow`'s
existing `justifyContent: "space-between"` on that row only —
`buttonOnNameLine = !currentTitle || nameLen <= titleLen`, comparing
`activeUser.length` against `currentTitle.length + 6` (a character-
count heuristic, not a true rendered-width measurement, so it can
occasionally pick the "wrong" line for edge-case lengths). The bonus
went from an initial `+3` to `+6` once the title started flanking with
an icon on both sides (below) instead of one.

**Username title flanks on both sides** — the username's
`TitleWithIcon` call now passes `flankStar`, matching what
`MilestoneButton` pills already did (star/crown/king tiers get the
icon on both sides of the text; diamond still doesn't flank, unchanged
from before). This is unconditional — no length-based cutoff — because
"Senior Math Wiz 12" (18 characters, the longest real title in the
app) was checked at a realistic ~320px mobile card width with both
icons and still fit on one line without wrapping, so there was no
shorter title that could possibly need a fallback to single-sided
flanking.

**Switch user button** (`s.userBarToggle` in styles.js): shrunk ~25%
(height 32→28, font-size 12→9, border-radius 8→6, padding tightened to
`"2px 12px"`) and its label restructured from the single string
`"Switch user"` to two stacked lines — `<span>Switch</span>
<span>User</span>` inside a `flexDirection: "column"` button — with
"User" now capitalized (was lowercase). The `open`/"CLOSE" state stays
a plain single string, unaffected by the stacking. `s.userBarTopRow`'s
padding became asymmetric (`"10px 8px 10px 14px"`, was symmetric
`"10px 14px"`) — tighter on the right specifically so the button (on
whichever row it lands on) sits closer to the card's actual edge
without spilling past it, while the left side (where the name/title
text starts) keeps its original spacing.

## Challenge Tests (new third tab, built v25-v26 — full design + UI)

A third tab alongside Ladder and Quizzes. Lets a student jump straight
to a milestone (Step 5/10/12/15/20) instead of climbing the Ladder one
number at a time — pass one with every answer right, and it backfills
mastery for every number it covers, so the title and Ladder-screen
shields show up immediately, same as if each number had been mastered
individually.

**Backend (`logic.js`)** — `CHALLENGE_LEVELS`: five fixed bands
`{ level, numbers, end, excludeEasy }`. 5/10/12 keep ones-and-tens
(`excludeEasy: false`) only for numbers 1-5, as a one-time proof of the
mechanics; 15 and 20 exclude them throughout (anyone reaching that
range already knows 1s/10s). `numberChallengeParams(n)` looks up which
band a number belongs to — this fixed lookup, not the level being
displayed, decides a number's own End/Exclude-Easy everywhere.

Three numbers shown per button, all computed fresh, never assuming
anything about progress:
- **Total** (`challengeTotalCount`) — the full comprehensive count for
  "own everything through this step," built from every number 1..level
  each tested under its own band. Deduped so each real-world question
  counts once ("present every qualifying question once"): multiplication
  by unordered pair (3×4 and 4×3 collapse), division by
  (divisor, quotient).
- **Left** (`challengeLeftCount` / `challengeRunPool`) — total minus
  whatever's covered by numbers *actually* in `ladder.mastered` right
  now (checked individually, from any source — free-play Ladder or an
  earlier Challenge pass). `challengeRunPool` is also literally what a
  Challenge run is built from, so the button's count always matches
  what's actually asked.
- **"X if last challenge passed"** (`challengeLeftIfPreviousPassed`) —
  a fixed reference number per level: what's left assuming the step
  immediately below it (in `CHALLENGE_LEVELS` order) had been fully,
  comprehensively passed. Doesn't look at real progress.

`isChallengePassed(level, masteredList)`: every number 1..level must be
mastered — not just that band's own numbers. A 100% pass backfills
`ladder.mastered`/`masteredEnd` for all of 1..level at once (each
number's own band End via `challengeMasteredEnd`), in `finishQuiz`
(`app.jsx`), under `runMode.kind === "challenge"`.

Historical note: total for Step 20 is 548, not the 495 once computed
early in the same conversation — that older number predates the
1s/10s-proof exception for Step 5 and is superseded.

**UI (`ChallengesPanel` in `setup.jsx`)** — one button per level,
`disabled` once `left === 0`, green/mastered-styled once passed:
- **Step number** — `Step {level}`, centered, sitting above the
  icon+title block (its own row, not tied to the stats column).
- **Title** — `TitleWithIcon` with `flankStar` (icon on both sides,
  real Steps-page sizes: 1.36em star/crown, 1.7em king — not a custom
  smaller size). `challengeTitleLines(bareTitle)`: titles with 3+ words
  force a break positioned so "Math" and "Wiz"/"Wiz!" always land
  together (glued with a non-breaking space) — a leading modifier word
  ("Junior", "Crown") sits alone on line 1, or a trailing word ("King")
  sits alone on line 2, whichever side doesn't split the pair. 2-word
  titles ("Math Wiz!") stay one glued line, no break. Centering is
  computed from the text alone (an inner `inline-block` span), so the
  flanking icons don't shift it.
- **Stats column** — order is left, then total, then "X if last
  challenge&nbsp;passed" ("challenge" and "passed" glued so that pair
  can't split across a wrap either). Has `maxWidth: 130` — without it,
  this line has no width limit and renders unbroken, overflowing left
  into the title (a real bug hit and fixed live: v25 shipped without
  it, screenshotted, then patched in v26).
- The whole button row uses `alignItems: "center"` (not `flex-start`)
  so the title block and stats column vertically center against each
  other regardless of which is taller — matters most for Step 10,
  whose single-line "Passed" would otherwise sit at the top next to a
  taller two-row title block.

**Chain-walk fix, shared helper (`chainHighestReached` in
`logic.js`)** — a Challenge pass backfilling 1 and 10 exposed a
pre-existing gap: the username-title and milestone-pill "how far up
the chain, no gaps" walk used to skip 1 and 10 ENTIRELY from the
walked sequence whenever Exclude Easy was on (`rangeNumbers` filters
them out) — so an already-mastered 10 (from a Challenge pass, or from
before Exclude Easy was toggled on) stopped counting, undercounting
the title (e.g. showing "Jr. Math Wiz 9" instead of "Math Wiz!").
Fixed by walking the FULL 1-12 range unfiltered and treating 1/10 as
"skippable" (not required to continue the chain) only when unmastered
AND Exclude Easy is on — if either is mastered, it still counts,
regardless of the current toggle. One shared function now backs both
the username title (`app.jsx`) and the milestone pill gating
(`setup.jsx`'s `LadderPanel`), so they can't drift apart again.
**v49: the "skippable" rule is gone** — chain A always needs the 1s and
10s (see "Two independent chains" above).

## Colors — the whole current palette

Every color the app uses, with hex and RGB. A full downloadable
reference (`color-reference.html`, two-column dark/light comparison)
was generated during this session — ask the user for it if you need
the visual version; the numbers below are the source of truth either
way.

| Color | Hex | RGB | Used for |
|---|---|---|---|
| Pure white | `#FFFFFF` | 255, 255, 255 | Elapsed-time value in history |
| Off-white / cream | `#EDEAE0` | 237, 234, 224 | Primary text everywhere; lower opacity for secondary text |
| Translucent white | `rgba(255,255,255,X)` | 255, 255, 255 @ 0.03–0.35 | Borders, faint backgrounds |
| Translucent black | `rgba(0,0,0,X)` | 0, 0, 0 @ 0.2–0.35 | Input backgrounds, card shadow |
| Dark slate navy | `#1F3040` | 31, 48, 64 | Card background |
| Darkest navy-charcoal | `#16232E` | 22, 35, 46 | Page background; text on gold buttons |
| Light yellow | `#FFF176` | 255, 241, 118 | Temp/short-range badges, untapped (shield, border, star/numeral all match this) |
| Gold | `#E8B94A` | 232, 185, 74 | Primary accent — active tabs, stars, Diamond/Crown/King icons, progress fill, title glow |
| Quiz-feedback green | `#8FBF8A` | 143, 191, 138 | Correct-answer highlight, history percentage — kept deliberately SEPARATE from mastery green, do not merge |
| Mastery green | `#46AB68` | 70, 171, 104 | Every mastery-related green in the app: shields, mastered button text/border, milestone buttons. Unified mid-session from two separate greens (`#7BA376` general + a briefly-separate milestone-specific shade) into this one color, chosen through several rounds of contrast testing (see history: went brighter, then back down ~15% for a kid-friendlier tone, landing here) |
| Blue | `#1E3A8A` | 30, 58, 138 | Scores History and Guide nav buttons |
| Coral | `#E0785A` | 224, 120, 90 | Repeat-question banner, missed-question chips, delete-user button |

Border variant of mastery green used throughout: `rgba(70,171,104,0.6)`.

## Guide page

**Current state (checked at V49 — the detail below is how it got here):**
two tabs, **Steps** (default; was "Levels") and **Buttons**. Steps intro:
"A title means you have passed every number step up through that step.
Anytime you do a full pass on a number you own the number. When you have
done a full pass on all the numbers below and through a number step, then
you get that title." (true again since v49 — the 1s and 10s are required).
Headers "Number" / "Title Won" / "Important Steps"; Steps-page pills use
`minWidth={150}` + `allowShrink`. 1–12 rows, then "These are learned
through times 20." and 11–20 (Royal/Crown/King need End 20 — true since
v49). Buttons tab: top line "These buttons only show what each one looks
like."; column headers "Ready" / "When Tapped" (shown in caps by CSS);
rows Passed / Your step / Not passed yet / Practice passed / Your practice
step; milestone caption "Important step button".

New top-level screen (`GuideScreen` in setup.jsx, `screen === "guide"`
in app.jsx, reached via a small blue "GUIDE" button under the username
bar — 40% wider than the 1-10/Auto preset buttons (minWidth 90,
padding "9px 14px"), same subtle border as the Scores History
button). Tabs are config-driven
(`GUIDE_TABS` array) specifically so future tabs are cheap to add:

- **Levels** (now **Steps**; default tab) — one intro paragraph at the top, explaining
  how titles work in plain language ("A title means you have passed
  every number step up to that level. The first gap sets your title on
  the one before the gap..."). Kid-facing wording, user's exact
  phrasing preserved rather than rewritten — went through several
  revision rounds (word choice discussions: "icons" vs "buttons," ruled
  out "buttons" as ambiguous for kids at first — physical buttons on
  clothes/devices — then settled it's fine since the Buttons tab's own
  name+images already disambiguates it). The second paragraph
  (non-canonical End → temporary/yellow status) that originally sat
  here too was later MOVED to the end of `RangeSection` instead (shows
  on both Quizzes and Ladder tabs, since that section is shared) —
  explicitly not staying duplicated in both places. Below the intro:
  every title in order. Header row reads "Number" / "Title Won"
  (aligned to row 1's title text, not exact for every row since icon
  widths vary slightly through 15–19). Rows 1–12 show green shield+star
  icons; the note "These are learned through times 20." introduces the
  11–20 restart, which shows Royal (Diamond)/Crown/King with their
  icons. Each row that has a milestone trigger shows that
  `MilestoneButton` on the right.
  - **Narrow-screen overlap fix**: on phone-width screens, the
    milestone pill used to overlap the title text to its left instead
    of wrapping its own text within its box the way it used to. Root
    cause: the row is a flex row with no `flexWrap`, the pill had a
    `minWidth` floor but no `maxWidth` ceiling (so it could grow
    instead of wrapping), and the title block on its left had no
    `minWidth: 0` (flex items default to `min-width: auto`, which
    blocks shrinking below content width). Fixed by adding `minWidth:
    0` to the title block's flex properties and passing a new
    `maxWidth={80}` prop through to `MilestoneButton` (matching its
    existing `minWidth={80}` here) so the pill is pinned to a fixed
    width and wraps its own text again instead of growing. This
    `maxWidth` prop only gets passed from this specific call site —
    the real ladder grid's own `MilestoneButton` call is untouched
    (different, grid-based layout, not reported as having the same
    overlap).
  - **Forced wrap point for Junior/Crown Math Wiz specifically**:
    `MilestoneButton` special-cases these two exact titles, inserting a
    literal `\n` after the first word ("Junior\nMath Wiz" / "Crown\n
    Math Wiz") and rendering with `whiteSpace: "pre-line"` so the break
    always lands after the first word rather than wherever the browser
    would naturally wrap. No other titles are touched — "Math Wiz!" and
    "Senior Math Wiz 12" have different word counts and weren't asked
    to follow this pattern.
- **Buttons** (renamed from "Buttons Gallery" — "Gallery" dropped as
  too grown-up a word for the target second/third-grade reading level;
  kept as "Buttons" alone rather than a replacement second word, since
  it already sits right next to "Levels" as a tab name) — a blank
  spacer (`<div style={{ height: 12 }} />`) sits above everything, then
  the intro line "The buttons here are not working here." (kid-facing,
  plain statement that these are non-interactive examples). The older,
  more technical note ("Badge gallery — untapped and tapped side by
  side for each style. Design preview only, not real data.") that used
  to sit below it was DELETED entirely in a later pass, once the
  kid-facing line existed and column headers (below) made the
  untapped/tapped structure self-evident without needing a caption to
  explain it. **READY** / **TAPPED** column headers (all-caps, centered
  above each column) plus a full-height vertical divider (absolutely
  positioned at 50%, `top: 0, bottom: 0`) sit above the
  `GALLERY_STYLES` grid. The milestone example (green "10s" + pill) is
  DELIBERATELY a separate block below/outside that divided grid, not
  part of it — it's not a same-badge untapped/tapped pair like the
  other rows, it's two different button roles shown together, so a
  divider running through it wouldn't mean anything and was removed by
  giving it its own `position:relative`-free flex row after the grid
  (`marginTop: 18`) instead of being the grid's last row. The row is
  `alignItems: "flex-start"` with the green button and a nested
  flex-column (pill + its own caption span, `alignItems: "center"`)
  as its two children — the caption ("Important level button," changed
  from "Milestone (e.g. after 10)" — simpler phrasing, avoiding the
  word "milestone" itself, which appears nowhere else user-facing)
  centers under ONLY the pill this way, not under both buttons combined
  — the green "10s" example stays deliberately uncaptioned. Every
  ladder button/badge state, one row per style, untapped and tapped
  side by side (two-column grid, top-aligned so cells keep their
  natural height and the grid doesn't stretch shorter rows to match
  taller ones). Captions wrap at 125% of the button's own width. This
  used to live behind the dev-preview toggle; it's a normal page now.
- Two tabs planned but deliberately NOT built yet: **Words Used**
  (glossary) and **FAQ** — see Hold-off items.

## Dev-preview toggle and app version (BD# usernames only)

`isDevUser(activeUser)` (logic.js) gates a small toggle
(`showDevToggle` in app.jsx) that only appears for usernames matching
"BD" + a number — **Current Settings** / **Default Settings** buttons
above the Setup screen, letting a dev preview the whole app as a
brand-new user would see it (`devPreview` state swaps in
`DEFAULT_QUIZ_SETTINGS`/`DEFAULT_LADDER_SETTINGS`/a fresh ladder, with
`onClick`s replaced with `noop` so nothing in preview mode actually
saves).

**`APP_VERSION`** (app.jsx, top of file, plain string constant e.g.
`"v7"`) renders as a small muted label directly right of "Default
Settings", inside the same `showDevToggle` block — bumped manually
with each build shipped. Built specifically to answer "is this
actually the latest build or a stale cached copy" after that question
kept coming up (file-preview caching by filename, and at least one
occasion where two milestone pills appeared to render at very
different icon sizes despite the source code showing no code path
for that difference — never fully resolved, possibly a caching
artifact more stubborn than the usual). Keep this in sync with the
shipped filename suffix (currently `v52`, keep incrementing) going
forward — if
they drift, the version label is the one to trust, since it lives in
the actual running code rather than a filename someone might rename
or leave stale.

**Version-tagged filenames (do this on every build, unasked):** the
shipped HTML file's OWN filename is `indexV{nn}.html` (e.g.
`indexV25.html` — not `index.html`), its `<title>` tag matches
(`indexV{nn}`), and the shipped source zip is named
`times-tables-source-V{nn}.zip` — all three using the same two-digit
number as `APP_VERSION` for that build, bumped together every time.
Why: on GitHub Pages, the live file must stay named `index.html`, so
the owner uploads the new version under its versioned name first
(alongside the still-live old one), then renames it to `index.html`
and deletes the old file — never deleting the live file before the
replacement is already up.

## Regression checks — run on EVERY build (added v44)

**Fast path (v51):** `sh tests/run_all.sh /tmp/prev NN` from the new source
folder does steps 1–5 in one go and prints one short report (uses the
previous zip's `build/indexV*.html` if present). Still read the removed code
lines and do step 6 yourself.

Older builds are not kept between chats (the container resets). The
baseline is always the PREVIOUS version's source zip — normally the one the
user uploads at the start of the chat. Steps:

1. Unzip the previous zip to e.g. /tmp/prev and build its HTML the same way
   (esbuild + HTML shell) → /tmp/prev.html. Build the new one as usual.
2. `sh tests/code_diff.sh /tmp/prev .` — lists every REMOVED non-comment
   source line. Read each: it must be an intentional replacement.
3. `python3 tests/text_inventory.py /tmp/prev.html NEW.html` — renders both
   through the same scripted states and prints visible text found in only
   one. Only the intended changes should appear. (Quiz-screen lines have
   digits and ×/÷ masked since questions are random.)
4. `node tests/logic_checks.mjs` — compares key numbers (Challenge sizes
   under several progress states, Challenge-sequence repeats, Test ALL /
   upgrade / New Facts Only pool sizes, miss allowance) with
   `tests/logic_snapshot.json`. After an INTENDED logic change, run with
   `--update` and say why in the changelog.
5. `python3 tests/scenario_tests.py NEW.html` — saved scenario tests
   (Playwright, ~1 min; added Oct 2026 in V48-tests): repeats (wrong,
   slow-correct, Fast/Fastest), In Order place (finish vs ✕, Quiz Length
   ALL, settings changes on both tabs), resume after closing (incl. during
   answer feedback), Ladder passing (green/yellow, fail pop-up, upgrade test
   and instant pop-up), Challenge backfill, titles, fail pop-up Stop. Uses
   `tests/scenario_logic.mjs` (Node) for expected counts/titles. Time is
   faked (page.clock), so delays are skipped. Results per test:
   PASS / FAIL (a "check" — FAIL is a regression);
   AWAITING FIX / FIXED (a "fix" test for an agreed fix not built yet —
   fails until built; once FIXED, change its kind to "check");
   KNOWN / CHANGED (a "known" test recording current behavior of an
   undecided issue — CHANGED means a decision was built, then rewrite it as a
   check, or a regression). Exit code 1 on any FAIL or CHANGED.
   `--list` lists the tests; extra ids after the file run only those.
   Requires Python Playwright + Chromium and Node.
6. Report the results to the user with the build: what changed, and
   confirm nothing else did. Include the "Changes-notes-vs-code audit": check
   only the app notes, Guide and README lines this build touched against the
   new code.

Add states to `text_inventory.py` and values to `logic_checks.mjs` whenever
a new feature or rare state appears (pop-ups, special progress), so the
checks keep covering what's been built. New behavior gets a saved test in
`scenario_tests.py` (not a one-off unsaved run).

## Pending — queued in conversation, NOT yet built

Nothing queued right now (v53 built everything that was pinned).

### Recently built (v53) — pop-up gaps, toggles, Ladder presets, Stopped rows

- **Password pop-up** (`ConfirmModal`: Teacher Settings and Delete user):
  10 px from the password box to Confirm and from Confirm to Go Back (was
  ~20 px and 0 px). With "Incorrect password." showing, the message sits
  10 px under the box and Confirm 10 px under the message.
- **Ladder "Ns — TYPE OF QUESTIONS - EASY TO HARD"** text at 80% like the
  other section titles; the number stays full bright. "Ladder Range" keeps
  60% (`s.subLabelColor`).
- **Custom and Practice Start toggle**: tapping the button again while its
  section is open closes it without changing anything (Go Back stays). Note:
  while open the Custom button reads "Custom Range: a–b".
- **No 1–20 preset on the Ladder** (`RangeSection allow1to20={false}`,
  `isDefaultRange(start, end, false)`). Quizzes keeps it. Custom 1–20 still
  works on the Ladder and shows as "Custom Range: 1–20" (and, like any custom
  range, opens the Custom boxes on load). Future "second ▲ in 11–20" stays.
- **Intro screen 3**: "This app shows you the right answers…".
- **"Lose your yellow badges?"**: "…This will take away your yellow practice
  badges. Green badges stay."
- **Stopped rows** in Scores History: a pass attempt (Test ALL that can pass,
  incl. upgrade / yellow-pill attempts, and every Challenge) stopped from the
  fail pop-up or with ✕, with at least 1 question answered, saves a row
  (`entry.stopped`, `answeredCount`, `missedCount` = answered − first-try
  correct). Row: "Test ALL · Stopped" / "Challenge N · Stopped", no %,
  questions "5 of 24Q". Left out of both averages and the "N finished
  quizzes" count (HistoryScreen filters them before Last 6). ✕ before any
  answer, practice quizzes and app close save nothing. ✕ path:
  `finishQuiz([], { stopped: true, quit: true })` saves the row and returns
  before the In Order / banner / results code; then the normal quit runs.
- **History**: normal rows "10q" → "10Q". Pass-attempt rows keep "24
  questions".
- APP_VERSION v53. Tests: P5, CH3 now expect the Stopped row; PS3 seeds End
  12 (1–20 loads as Custom on the Ladder now); new ST1, ST2, L20, TG1.

### Recently built (v52) — Practice Start button, Range note, titles, yellow on green 12

- **Range note** now says "…An End of 10 or 11 counts toward Math Wiz! …"
  and the WHOLE note shows only while Custom is open (`customStart`).
- **Practice Start is a button** (full width, like Custom). Tapping opens the
  Start spinner, Set Start, Go Back and the note; Set Start saves and closes,
  Go Back closes without changing anything. Above 1 the button shows its
  value and is gold: "Practice Start: 9". The v51 "Practice Start" sub-label
  is gone (the button replaces it).
- **Section titles** (capitalized `sectionLabel`) at 80% brightness (was 60%).
  Mixed-case sub-labels ("Ladder Range", "12s — TYPE OF QUESTIONS") keep 60%
  via `s.subLabelColor`.
- **Guide** badge example "Practice passed" shows "4s to 7" like the real
  yellow pill.
- **Yellow on a green-12 number** (`isYellowAboveAttempt`, logic.js): green
  at 12, NOT yellow, End 13–19 → Test ALL is a real pass attempt (History
  pass row, fail pop-up, miss allowance), handled like yellow attempts in
  1–10. Like an upgrade test it asks only the facts not yet passed (×13…×End
  and their divides; 9 questions for 12s at End 15). Pass adds the yellow
  pill; banner and History say "12s up to 15" (the End tested). Already
  yellow → practice only (v49 choice A). `runMode.yellowAttempt`.
- APP_VERSION v52. Tests: new PS3, Y2; PS2 opens the button first;
  logic_checks 1 new value.

### Recently built (v51) — Practice Start, Yellow above 12, extra time, return number

- **Practice Start (Ladder only)** — RANGE now has a "Ladder Range" sub-label
  over the range buttons, then "Practice Start" (Start spinner, default 1,
  1..End) and a Set Start button (gold while the box differs from the setting
  in use), note: "This picks where your practice questions start, so you can
  skip lower facts you already know well." `ladderSettings.practiceStart`;
  logic.js `practiceStartOf` / `practicePool` (partners >= Practice Start,
  matching divides included — `numberPool` tags every fact with its partner).
  Practice modes and New Facts Only use it; Test ALL ignores it. A smaller End
  pulls it down to the End (`patchLadderSettings`). Choice A: it is part of
  the Ladder In Order bookmark key (`|psN`, left off at 1 so older saved
  places still match), so changing it starts In Order at the new first fact.
  Quizzes tab unchanged.
- **Yellow above 12** — a Test ALL pass at End 13–19 is green at 12 (as v49)
  AND adds the number to `tempMastered` with `tempMasteredEnd` = the End
  (`yellowAboveTwelve`, finishQuiz). Yellow still counts for nothing. Yellow
  pills now show their End ("12s to 16", also for End 9 or lower yellows),
  shield on the right, and only yellow pills grow wider. A number with both
  shows two pills: green "12s", then yellow "12s to 16". Note: a Test ALL on a
  number ALREADY green at 12, at End 13–19, is practice (not a pass attempt),
  so it adds no yellow — only a fresh pass or an upgrade from End 10 does.
- **Tap notes** — green: "This number is already passed. You can still
  practice it." yellow: "This number has a practice pass through [End]. You
  can still practice it." Both show for a number with both badges.
- **Extra answer time** — Fast/Fastest Type In: +0.5 s for 2-digit answers,
  +1 s for 3 or more (`extraTimeMs`). Normal never. The slow check and the
  History over-limit count both use it (`answerExtrasRef`, saved with the
  run stats for resume). The History label keeps the base number.
- **Back to Math Wiz Ladder** stays on the number just quizzed (practice,
  failed Test ALL, practice Test ALL); after a pass or upgrade it goes to the
  ▲ (`ladderReturnNumber` in app.jsx, `initialPreview` prop on LadderPanel;
  cleared on tab or user change).
- **Wording** — Range note: "…An End of 10 or 11 counts toward Math Wiz. Any
  End of 12 to 19 counts toward Senior Math Wiz 12." SKIP note: "To win a
  title through Step 10 or Step 12, …". Intro screen 2 second paragraph:
  "Knowing your math facts makes it a lot harder for other people to fool
  you. It even makes it harder for leaders if they try to fool you." Speed
  caption (all tabs): "Wrong or slow answers get asked again. Normal is for
  learning. Fast has shorter times. Fastest has shorter times and no
  repeated questions."
- **Test tooling** — `tests/run_all.sh PREV_DIR VERSION` (builds, runs every
  check, text inventory and scenario tests in parallel, prints one report;
  ~2 min) and `tests/build_html.sh`. The built HTML is saved in the zip as
  `build/indexV{nn}.html`, so the next build uses it as its baseline without
  rebuilding the old source.
- Tests: new PS1, PS2 (Practice Start), B1 (return number), X1 (extra time);
  P11 now checks the yellow pill, both notes and Back → ▲; P3 new SKIP text;
  P8 clicks the yellow pill by its new label. logic_checks: 4 new values
  (snapshot updated for them only; all old values unchanged).
- Not changed: the Guide's badge examples still show a plain yellow "Ns" pill.
- Fix after first V51 delivery: APP_VERSION was still "v50"; now "v51", and
  `tests/build_html.sh` refuses to build when APP_VERSION doesn't match.

### Recently built (v50) — wording and resume tab

- Range note: "If your Custom End is 9 or lower…".
- SKIP note: "To win a title through Step 12, set SKIP the EASY FACTS to Let
  App Pick, or to Off. The 1s and 10s are steps you need to pass."
- Challenge Tests intro: "Longer tests let you miss 1 for every 100
  questions."
- ALL note: "…every math question that fits the settings, one time each."
  ("passes" was avoided: the app uses "pass" for passing numbers/tests.)
- A Quizzes quiz resumed after the app was closed now opens the Quizzes tab
  (`applyLoadedRunState`), so "Back to Quizzes" returns there (it landed on
  the Ladder, the default tab). Only Quizzes quizzes are resumed (test C3).
  Decided: with no quiz in progress the app still opens on the Ladder tab.
- Tests: new C5 (resume tab); P3 uses the new SKIP note text.
Also remember: show the Queue, Future and Maybe bin lists (see "Hold-off /
future items — Sorted Oct 2026") whenever the user asks for Q.

### Recently built (v49) — the audit's Q for V49

All from the Oct 2026 notes-vs-code audit (see the audit log at the top).
- **Titles (audit 1, 5a, 5b)** — logic.js `chainHighestReached(mastered,
  masteredEnd)` / `currentTitleFor(mastered, masteredEnd)` (the SKIP
  argument is gone): chain A needs every number 1..n incl. the 1s and 10s,
  and counts 11/12 only when passed at End 12+ (Senior form); chain B counts
  only numbers passed at End 20. Royal tie-break removed, so 1–12 at End 12
  now shows "Senior Math Wiz 12" (header, PASSED line, pill). app.jsx header
  now calls `currentTitleFor` (was its own copy of the rule). Ladder icons:
  Diamond/Crown/King only for a pass at End 20.
- **SKIP Off note (5b follow-up)** — Ladder only, under the SKIP buttons,
  when SKIP is On and the Range touches 1–10: "To win a title, set SKIP the
  EASY FACTS to Off. The 1s and 10s are steps you need to pass." SKIP On
  still hides the 1s and 10s as steps (user's choice).
- **Test ALL on 1–10 always asks ×1/×10/÷1/÷10 (audit 2, choice B)** —
  `masteryTestPool`. The too-small warning now shows only for End 9 or
  lower, reworded: "This range is too small to pass a Math Wiz Ladder step.
  You can win a yellow practice badge. Continue Practicing or Change
  Range." (`highestPartnerReached` is no longer used by the app.)
- **Rounded End (audit 4)** — `passEndFor`: 9 or lower yellow, 10–11 → 10,
  12–19 → 12, 20 → 20. Used for the pass, the upgrade test, the yellow ▲
  (End 9 or lower), the PASSED message and the History row. Range note:
  "If your Custom End is 9 or lower, you are playing for practice and can get
  yellow badges but no new title. An End of 11 counts for Step 10. Any End
  of 13 to 19 counts for Step 12." Choice A: the "Lose your yellow badges?"
  pop-up stays, so a yellow number is never a pass attempt; the unreachable
  yellow→green removal in finishQuiz was dropped.
- **Fail pop-up Stop on the last question (audit 3)** — counts as a normal
  finish when only repeats are left in the queue (Normal/Fast add an
  immediate repeat on a miss, so the queue was never empty).
- **Resume keeps the last answer (audit 10)** — the saved run stats are
  read live when the quiz state is saved (was a snapshot from before the
  answer). Covers closing during feedback and between questions.
- **Wording** — "Back to Quiz Ladder" → "Back to Math Wiz Ladder"; Quizzes
  "Start quiz" → "Start Quiz"; instant-upgrade pop-up adds "You are now a
  <title>!" when the title changes.
- Stale comment above `startLadderQuiz` fixed (no behavior change).
- Tests: fix tests → checks; P2, P3, P8 rewritten for the new rules; T1 and
  P10 updated for 5a/5b; new P11 (End 15 → green at 12). Quizzes tests use
  "Start Quiz".
- README: obsolete current-rule text fixed (Key design points, Speed, badge
  and title sections, Guide current state, file structure, HTML shell / zip
  names incl. tests/); entries v39 and older moved to CHANGELOG.md.
- Note: a 13–19 can now be green at End 12 (e.g. Range 1–15). It shows the
  plain green shield, counts for the Facts Passed Rule, and gives no title.

### Recently built (v48) — In Order place saved on finish, resumed quizzes keep their stats

- In Order place (app.jsx): was saved when a quiz STARTED (Quizzes
  `setSeqProgress` in startQuiz; Ladder `seqCursor` in reallyStartLadderQuiz),
  so a quiz quit with ✕ or lost when the app closed made the next quiz skip
  its unanswered questions — contradicting the note "After the last finished
  quiz…". Now the new place is held in `pendingSeqRef` and applied only in
  finishQuiz when the quiz finishes (not when stopped from the fail pop-up).
  Verified live: 2s Type In · In Order, Both, 10 questions — answer 3, quit,
  start again → same first question (v47 skipped ahead to 8÷4); finish a quiz
  → next quiz moves on.
- Resumed Quizzes-tab quizzes (app closed, reopened mid-quiz) now keep their
  first-try count, question total, answer times, missed facts and pending In
  Order place: saved as `runStats` + `missedFacts` with the quiz, restored in
  applyLoadedRunState. The saved stats are a snapshot taken as each question
  appears (`runStatsSnapRef`), so a quiz closed while feedback shows resumes
  on that question without counting it twice. (v49: replaced — the snapshot
  lagged one answer and lost it; stats are now read live when saving.) Verified live: 10 questions,
  1 miss, reload after 3 → results "9 correct on first try · 1 missed",
  History 90% / 10q with timing (v47: "8 correct · 0 missed", History 0% / 0q).
- The v47 fallback in ResultsScreen (old count for resumed quizzes) removed.
  One-time edge: a quiz saved mid-way by v47 or earlier and resumed in v48 has
  no saved stats, so its results / History count from zero.
- Ladder and Challenge quizzes still never resume (unchanged, by design).
- README: Audit plan section added near the top; #2 moved to the Maybe bin;
  #3 marked history (done by Challenge Tests); "full pass" kept (user likes it).

### Recently built (v47) — results count fix, SKIP label, Custom Go Back, wording

- Results screen (quiz.jsx ResultsScreen): "N correct on first try · N
  missed" now uses first-try counts only (correctFirstTryRef and
  answerTimesRef.length, passed from app.jsx) — the same count the pass rule
  and History use. Before, it was answeredCount - wrongCount, which counted
  repeated questions (showed "30 correct on first try" on a 29-question
  quiz; missed also counted repeats). Fallback to the old count only for a
  Quizzes-tab quiz resumed after the app was closed (no first-try data).
- SKIP section label (setup.jsx): "SKIP the EASY FACTS 1×, 10×, ÷1, ÷10".
  Section labels are uppercased by CSS, so "the" is a span with
  textTransform: "none" (user: all caps except "the").
- The two rare Ladder no-numbers messages reworded (3rd-grade, and they
  still said "mastered"): "No numbers fit your Range. Change the Range or
  the SKIP the EASY FACTS setting below." / "No numbers fit your Range and
  SKIP the EASY FACTS settings. Here are the numbers you already passed."
- Custom Range: "Go Back" button beside SET RANGE (same row on a phone).
  Closes the Start/End boxes, changes nothing, and the range in use is
  highlighted again. Note: while Custom is open, the Custom button already
  reads "Custom Range: <range in use>"; Go Back is still the clear way out.
- ALL note (Quiz Length): "…but not in Speed Fastest." → "…but not with
  Speed Fastest."

### Recently built (v46) — pass-attempt History rows, Challenge Type In, wording

- "Lose your yellow badges?" pop-up (setup.jsx): Continue button → "Yes
  Continue" (no comma, user's wording). "Go Back" unchanged.
- Pass title line (quiz.jsx): "You are now a <title>!" (added "a"), e.g.
  "You are now a Royal Math Wiz 12!", "You are now a Math Wiz!". All titles
  start with a consonant sound; a future vowel-sound title would need "an".
- Challenge Tests now use Type In (was Choose Answer / multiple choice —
  never a deliberate choice; it let Challenge grant green passes with an
  easier answer type than Test ALL). app.jsx startChallenge:
  `answerMode: "type"`. No Challenge wording mentioned the answer type.
- Scores History pass-attempt rows (app.jsx finishQuiz + quiz.jsx History).
  A pass attempt = every Challenge, or a Test ALL with
  `runMode.isMasteryAttempt` (unpassed in-range number, or an upgrade test).
  A Test ALL that is only practice (already passed at that End, or outside
  the Ladder range) keeps the normal row — user's decision.
  - Saved fields added: `passAttempt` ("test" | "challenge"),
    `correctCount`, `missedCount` (first try, same count the pass rule
    uses), `passed`; Test ALL `range` = "Ladder 7s up to 20" (adds the End).
  - Row: date · "Test ALL · Passed" (or "Challenge 5 · Not passed") · %;
    detail: [Ladder 7s up to 20] · N questions · N correct · N missed · avg
    · over-limit · Total. "N questions" replaces "Nq". Answer type and
    operation dropped (fixed by these modes). "Passed" / "Not passed" not
    in caps (user: caps belong to the results screen).
  - Rows saved before v46 have none of these fields and show as before.
  - Averages unchanged (pass-attempt rows still count, as before).
- README: "Still up for review (from v41)" line deleted (all three were
  already done in v44 or removed); old Mastery bullet in Key design points
  replaced with the current rule (old text below); hold-off #7 marked
  history; stopped Test ALL / Challenge tracking added to the Maybe bin.
- Old Mastery bullet, kept for context (described the pre-v18 two-pass
  streak and the pre-v43 current-number rule — both gone): "Mastery requires
  passing Type In · Random with 100% first-try correct, twice in a row
  (`ladder.streak`), for whichever number is currently
  `ladder.currentNumber`. A pass in any other mode, or on a number that
  isn't the current track, logs to History but does not advance
  streak/mastery."

### Recently built (v45) — PASSED messages, intro screens, wording

**Results / pass messages** (quiz.jsx ResultsScreen):
- Title "Quiz Done!" on every finished quiz; "Quiz Stopped" (capital S) when
  Stop is tapped on the fail pop-up before the end.
- Ladder pass: "Ns up to E PASSED!" + THREE non-breaking spaces (plain
  spaces collapse — the user wants a visible gap for emphasis), then:
  a newly earned title → "You are now <title>!" (replaces Next up / the
  whole-ladder line; a title already ending in "!" like "Math Wiz!" gets no
  second "!"); else "Next up: the Ms."; else "You have passed the whole
  ladder." Showing the End ("up to 20") makes Senior 12 vs Royal 12 clear.
  New title = `currentTitleFor()` (logic.js, same rule as the header; the
  header still computes it inline) differs before vs after the pass; green
  passes only. Out-of-order passes or a small Custom range (5–10) earn no
  title, so they show Next up / whole ladder instead.
- Challenge pass: "Challenge N PASSED!   You have won the title and every
  number below it." (one shared message for all levels 5/10/12/15/20).
- Instant-upgrade pop-up: "12s up to 20 PASSED!" / "…so there is nothing
  new to test." Contractions (you've, there's) replaced with full words
  for young readers.

**Intro screens** (components.jsx `IntroScreen`, `INTRO_SCREENS`; app.jsx
`intro` state, `startIntroFor`): 4 short screens, Next on each, last button
"Let's Go!". Counted PER USER (`times-tables-intro-v1:<user>`, logic.js
`readIntroCount`/`writeIntroCount`; removed on user delete; NOT in Backup
files), once EACH TIME THE APP IS OPENED (initial load) and right after a
brand-new first user enters their name; switching users mid-session does
not show it. Showing 1 → Next fades in after 10 s on every screen, 2 → 5 s,
3 → 3 s, 4+ → Next right away + "Skip Intro" on every screen except the last
(where it would equal Let's Go!). No countdown shown (kids would watch the
numbers instead of reading). A screen's 2nd paragraph has a 34px gap above
it. While the intro shows, every other screen is hidden. Text:
1. "This app will let you go at your own speed. You can start with
   multiplying by 1." ¶ "Knowing your math facts makes your future math,
   science, and computer classes much, much easier. It helps you become a
   Wiz with money too!"
2. "Do a few quizzes every day, and you will learn because you keep going
   over the math facts again and again."
3. "This app shows you the right answers every time, right after you answer, so
   just look at and think about each fact for a couple seconds. If you put a
   lot of attention on the math facts, you can learn them faster."
4. "There are two extra sections for students who want more work: Quizzes
   has longer quizzes, and Challenge Tests is for skipping ahead if you know
   it all." ¶ "Keep Quizzing, and you will become a Math Wiz!"
FUTURE: once the Words section exists, a 5th screen with the TIP ("TIP:
Knowing what words mean is VERY important to doing well in any subject.
Use the Words section. Don't guess what words mean!").

**Wording:** "Practice Facts" → "Which Facts"; ALL note "…one time each.
Wrong or slow answers are repeated, but not in Speed Fastest."; Ladder intro
adds "2s is said TWOS. It means the 2 times facts: 2×1, 2×2, 2×3, and so on."
/ "3s is said THREES. It means the 3 times facts, and so on." (the user
avoids parentheses and quotes in kid-facing text); Guide Buttons "Practice
step" → "Your practice step".

**Tests:** text_inventory.py taps Skip Intro after each load (the intro
shows on every open) and has a new "intro screens" state.

### Recently built (v44) — Facts Passed Rule, upgrade tests, miss allowance, fail pop-up

**Facts Passed Rule** (user's name; logic.js `factPassed`, `passedEndOf`):
a fact counts as passed if either of its numbers was passed (GREEN only —
yellow never counts) with an End that reaches the other number. Worked out
on demand from `ladder.mastered` + `ladder.masteredEnd` — the app does NOT
track individual facts; nothing new is saved. Missing End (very old data)
falls back to the number's Challenge band End.
- Ladder (one number at a time): skip that number's facts already passed —
  by its own earlier pass or the partner's pass. Used by **New Facts Only**
  (was: skip if the partner number was passed, ignoring End) and the
  **upgrade test**.
- Challenge Tests (a whole level at once): `challengeRunPool(level,
  mastered, masteredEnd)` starts from the level's full set and removes every
  fact either of whose numbers covers it, counting ANY passed number (even
  above the level). Was: each passed number <= level removed its fixed band
  set, ignoring the real End. Compared before switching: identical in normal
  in-order use; only ever asks fewer (e.g. 1–10 passed at End 20: Level 20
  goes 395 → 155). `challengeLeftIfPreviousPassed` unchanged (assumes band Ends).
- Known gap (both old and new): only the End is saved, not whether SKIP was
  on, so ×1/×10 facts of a number passed with SKIP on count as passed though
  never asked (matters for 2–5, ~24 questions at Levels 5/10). Fixing needs
  SKIP state saved per pass — separate decision.

**Upgrade test** (`isUpgradeTest`, `ladderTestPool`): Test ALL on a GREEN
number when the current End is canonical and bigger than the End it was
passed with (e.g. Senior 12 at End 12 → Royal 12 at End 20) is a mastery
attempt that asks only the facts not yet passed (12 from End 12 → 20 with
nothing else passed: 24 questions, not ~53). A pass records the new End.
If nothing is left to ask, it upgrades on Start with a one-button pop-up
("12s passed up to 20!"). A regular first-time Test ALL still asks every
fact (deliberately — the repeats are review).

**Challenge pass keeps the bigger End:** passing a Challenge sets each
number's End to max(existing, band End). Was overwritten with the band End,
which would have un-proven Ladder facts under the Facts Passed Rule.

**Miss allowance** (`allowedMisses`): 1 first-try miss per FULL 100
questions (under 100 → 0, 100–199 → 1, 200–299 → 2). Applies to every
pass attempt; in practice only Challenge Tests reach 100 (Ladder Test ALL
max ~59). Pass = first-try misses <= allowance (replaces `percent === 100`).
Challenge intro text gained: "Long tests let you miss 1 for every 100 questions."

**Fail pop-up** (app.jsx `failInfo`): on a pass attempt (Ladder Test ALL /
upgrade test, Challenge), the moment first-try misses exceed the allowance
the quiz pauses after that answer and shows "You did not pass this time. /
You can keep going to practice. / Work on: …" [Keep Going] [Stop]. Ladder
lists the missed facts; Challenge lists the numbers the misses came from
(`workOnList`, skips 1s). Keep Going resumes (no pass possible). Stop ends
it: results screen titled "Quiz stopped", NOT saved as a normal Scores
History row (v53: saved as a "Stopped" row, kept out of the averages — see
v53) — unless the failing answer was the
last question, then it's a normal finish (v49: "last" = only repeats left
in the queue, since Normal/Fast add a repeat on a miss). Challenge fail banner now reads
"You did not pass the N challenge this time." + Work on list. Ladder Test
ALL allows 0 misses, so the pop-up appears on the first miss — by design.
YesNoModal gained `cancelLabel={null}` (one button) and `backdropClose`.

**Yellow badges warning moved to the Range section:** on the Ladder, SET
RANGE or a preset tap whose new End is bigger than `tempMasteredEnd` (with
yellow badges present) shows "Lose your yellow badges? / Your new End number
is bigger. This will take away your yellow practice badges." [Continue]
[Go Back] instead of "Change range?". Continue sets the range AND clears
the yellow badges. The old "Make the range bigger?" pop-up at Start is
removed (`tempWipeConfirm` gone). Otherwise "Change range?" as before.

**New Facts Only with nothing left** (Ladder practice modes): shows "All
these facts are passed. Pick All Facts to practice them." and disables
Start Quiz.

**Scores History labels:** "Skip the worst quiz score:" (On/Off), "Last 6
Quizzes", "All Quizzes" ("average" is ~5th–6th grade).

### Recently built (v43) — pass any number, notes cleanup

- **Pass any unpassed number:** Test ALL on ANY unpassed (not green, not
  yellow) number inside the Ladder range is a mastery attempt — not just the
  ▲ current step (app.jsx `reallyStartLadderQuiz`). After a pass the ▲ moves
  to the FIRST unpassed number in the whole range (was: next after the passed
  number), or stays if all are passed. The title chain already requires
  in-order passes, so out-of-order passes can't earn titles early.
  Verified: with nothing passed, Test ALL on the 4s passed it; ▲ stayed on 1s.
- **Removed** the "This isn't your current ladder step…" note and its
  "move the current ladder step to here" link (`onSetLadderTrack` prop kept,
  unused by the panel now).
- **Unpassed numbers no longer faded** (the 0.55 opacity "locked" style is
  gone, both on the Ladder and in the Guide gallery); tapped = normal gold.
  Guide row renamed "Not passed yet".
- **Removed dead "out of range" dashed style:** the Ladder only shows
  out-of-range numbers that are passed (green), so the dashed style could never
  render. Guide row "Outside your range" (+ tapped) removed; the gallery's
  `outOfRange` branch is left in code but no row uses it.
- **One note for any tapped passed number** (green or yellow, in or out of
  range), right after the number buttons: "This number is already passed. You
  can still practice it." Replaces the old outside-range note under the
  Type of Questions title.
- Standard 36px gap before RANGE (was 18).
- Ladder intro: "…with all answers correct to pass a number." (was "unlock
  the next number" — numbers aren't locked any more).
- In Order note: "The In Order types remember your place. After the last
  finished quiz, this app will start next time right where you left off. You
  have to leave all the settings the same for this to work." ("After the last
  finished quiz" is what makes it true for ALL: a finished ALL quiz covered
  everything, so starting at the beginning IS where you left off.)

### Recently built (v42) — Test ALL pass mode + first-unpassed rule

**Ladder: 5th mode, "Type In · Random · Test ALL"** (key `type-test`,
`LADDER_TEST_MODE` / `LADDER_MODES` in logic.js; Ladder only — Quizzes tab
still uses the 4 `QUESTIONS_MODES`). It's what Type In · Random used to be:
random, every question for the number, both operations, ignores Quiz Length
and Practice Facts, and it is the ONLY mode that can pass a number
(`isMasteryAttempt = mode === "type-test" && number === currentNumber`).
**Type In · Random is now practice**: random order, uses Quiz Length,
Math Types and Practice Facts like the other three, never passes.
- `ladderModeOrder(mode)` replaces `mode.endsWith("random")` (type-test
  doesn't end in "random").
- LadderPanel renders its own stacked SegGroup of LADDER_MODES, so Test ALL
  is a 5th full-width row. Math Types shows "Both" (disabled) and the
  "range too small" warning appear for type-test (were type-random).
- Text updated: Ladder intro ("Pass Type In · Random · Test ALL…"), the note
  under the modes ("…gives ALL questions for that number — both Multiply and
  Divide. It is the only way to pass a number."), and the Practice Facts note.
  The In Order note needed no change.
- Existing users whose saved `lastMode` was "type-random" (the old test)
  now land on practice Type In · Random; they pick Test ALL to pass.
- Verified in Playwright: a full, all-correct Type In · Random (20 q) did
  not pass; Test ALL (29 q for the 1s) passed and advanced to the 2s.

**First-unpassed rule on Range/SKIP change (app.jsx):** when the SAME user
changes Ladder Range or SKIP, the current step now always moves to the first
unpassed number in the new range (`withFirstUnpassed`; falls back to
`withValidTrack` if all are passed). Example: SKIP On with nothing passed →
current 2; SKIP Off → current 1 (the 1s are a step again and block the title
chain). Only the in-range numbers count (11–20 never goes to 1). First load
and user switches still use `withValidTrack` (only fixes an invalid step), so
a chosen step isn't reset by opening the app. `trackRangeRef` remembers
which user the effect last ran for, to tell a real change from a switch.

### Recently built (v41) — 3rd-grade vocabulary pass + Range/SKIP layout

Goal: visible text at ~3rd-grade reading level. "Range" deliberately kept
(no better word; kids can learn it). "Custom" kept (kids know it from games).

Text changes:
- Scores History type: "Multiple Choice" → "Choose Answer" ("Type Answer" kept).
- Division Symbols labels (logic.js DIVIDE_SYMBOLS): "Divide sign", "Slash",
  "Fraction bar", "Long division sign" — no symbols in parentheses (young kids
  may not know "( )"). Note: "Each of these equals 3. Pick the signs you want to use."
- Guide › Buttons: top line "These buttons only show what each one looks like.";
  column "Tapped" → "When Tapped"; rows Passed / Your step / Not reached yet /
  Outside your range / Practice passed / Practice step. "Mastered, out of range"
  row REMOVED — it rendered identically to "Mastered" (dashed look only applies
  to unpassed numbers).
- Ladder results: "5s mastered!" → "5s passed!"; "Quiz complete" → "Quiz done!".
- Scores History: "completed" → "finished" (2 spots).
- Quiz screen: "N left in queue" → "N left" (2 spots).
- Widen pop-up: title "Make the range bigger?"; "yellow progress buttons" → "yellow buttons".
- Cancel → "Go Back" everywhere kids can see it: widen pop-up + ConfirmModal
  (password pop-ups behind Delete user and Teacher Settings).
- Range note: "yellow icons" → "yellow badges" (only visible use of "icon").
- SKIP: "Auto" → "Let App Pick", moved last: Off · On · Let App Pick. Wraps
  naturally to its own row if the phone is too narrow (fits one row at 390px
  default font size).

Range section (RangeSection, both tabs):
- Custom button is full width on its own row. While Custom is the selected mode
  it reads "Custom Range: S–E" using the range IN USE (settings), never the unsaved
  draft boxes; plain "Custom" when a preset is in use.
- Dash between Start and End removed (dangled on phones). Start and End now fit
  on one row at 390px; SET RANGE wraps below.
- Last custom range remembered per tab per user as `settings.lastCustom`
  ({start,end}), saved on SET RANGE confirm — and also when leaving a non-preset
  range for a preset (covers ranges set before v41). Tapping Custom fills the
  boxes with lastCustom, or the range in use if none. Still needs SET RANGE.
- Bug fix: `isDefaultRange` (logic.js) was missing 1–12, so after a reload with
  1–12 in use, Custom (not 1–12) was highlighted. Now lists all four presets.

### Recently built (v40) — user-switch Ladder bug fix + "Go Back"

**Bug:** switching to (or creating) a user whose ladder had never been
saved left `ladder.currentNumber` null. The "keep the ladder track valid"
effect only ran on `ready` or a Ladder Range/SKIP change — not on a user
switch. With no current number, the Ladder tab hid the TYPE OF QUESTIONS
section (4 mode buttons + notes), the SPEED section, and the ▲ marker,
and Quiz Length showed ALL: 0 (Start Quiz still showed).

**Fix (app.jsx):** the rule was pulled into a module-level pure helper,
`withValidTrack(ladder, ladderSettings)`, used by the settings-change
effect AND applied at every ladder load point: initial load, `loadUserBundle`
(user switch), `createUser`, `createFirstUser`. NOT done by adding
`activeUser` to the effect's deps — `switchUser` sets `activeUser`
before the new user's data loads, so the effect would have run on the
old user's ladder and saved it under the new user's key.
Verified with a two-user Playwright test (second user with no saved
mastery): both users now show the same sections.

**"Go Back":** the plain Back buttons on the Guide (shared by the Steps
and Buttons tabs, setup.jsx) and Scores History (quiz.jsx) now read
"Go Back". The results screen's "Back to Quizzes / Quiz Ladder /
Challenge Tests" buttons are unchanged.

### Known issue, accepted tradeoff — diamond icon sizing vs. Android text-size boost

User reports (on Android 12, Chrome): with the OS accessibility "Font size" slider at their normal daily setting, the diamond icon next to "Royal Math Wiz" text renders at only ~3/4 the height of the adjacent capital letters. Dialing that OS slider down one step made them "almost identical."

**Root cause, confirmed** (not the font-substitution theory floated in v20/v21 — that was tested and largely ruled out): precise cap-height measurement (at 200px, where integer-pixel rounding is negligible) showed Roboto (Android's fallback for this font stack), DejaVu Sans, and Arial/Helvetica all cluster within 0.69–0.73 cap-height-to-font-size ratio — not meaningfully different. The actual cause is Android's **Font size** accessibility slider (distinct from "Display size"): on Android 12+ it applies a non-linear text-rendering boost that inflates how glyphs are drawn without changing the element's computed `font-size` — so a CSS `em` value, which reads computed `font-size`, can't see or track that boost at all. The user's desktop zoom (~25%) doesn't have this problem because it scales the whole page (text and images) together as one unit, which is a different mechanism.

Because the boost is invisible to CSS and non-linear (small text is boosted proportionally more than large text, per Android's own scaling curve), there's no single `em` value that's correct both with and without it — any fixed size either matches the boosted case or the unboosted case, not both.

**Decision**: user chose to accept this tradeoff rather than leave it unfixed. Diamond icon size bumped +10% (`0.9em` → `0.99em` at both real occurrences — `setup.jsx`'s Levels-list row and `components.jsx`'s `TitleWithIcon` diamond branch) to look better on their own typically-boosted Android setup, with the explicit, agreed cost that it will now overshoot cap-height (render slightly too tall) on unboosted text — their own desktop included. If this needs revisiting: reverting is just changing `0.99em` back to `0.9em` in those same two spots. Crown/king/star icon sizes were never part of this — only the diamond ("Royal") branch was ever calibrated to cap-height, so "crown" in earlier session notes was a mislabel.

## Unresolved question — RESOLVED Oct 2026: moved to the Maybe bin

(Answered: the user said it would be nice in theory but isn't worth the
coding and overhead — most Quizzes-tab quizzes cover partial numbers,
which would need per-fact tracking. See Maybe bin below.) Original note:

A suggestion was floated (not by the user, by Claude, mid-discussion
of hold-off item #7): let an ordinary Quizzes-tab quiz ALSO grant real
ladder mastery for a number, if it happens to satisfy the same
requirements the Ladder tab demands (full partner coverage 1/2 through
canonical End, both operations, two clean passes) — instead of only a
dedicated Ladder-tab Type-In-Random attempt being able to grant
mastery. The user asked "explain," got the explanation, then the
conversation moved to a different topic without ever answering yes/no
on whether to queue it. Not decided either way — surface this
explicitly next chat rather than assuming an answer.

## Hold-off / future items — confirmed as intentional, not forgotten

**Sorted Oct 2026 (v45) — read this first.** Three lists now:
QUEUE (pinned for the next build), FUTURE (decided, not yet built), and the
MAYBE BIN (the user's term: undecided ideas that may never happen). Show all
three when the user asks for Q.
- FUTURE: #5 Words Used / FAQ tabs — merge into the
  planned Words / Good Words section (its drafted "average answer time" text
  needs a 3rd-grade pass, "average" is ~5th–6th grade); #10 the King Test;
  NEW: with a 1–20 Ladder range, show a second ▲ in 11–20 once the kid has
  passed a number there (small leftover of #1); NEW: the intro TIP screen
  (above); NEW: Words / Good Words section + "What is Math?" page (drafts
  kept in conversation memory).
- MAYBE BIN: #2 King's fancy crown (moved from Future, Oct 2026); #1 two-track current number (mostly moot since v42/v43: the ▲
  moves to the first unpassed number in the new range on every Range/SKIP
  change, and passing is no longer tied to the ▲; its long text below still
  describes removed features); #4 Fast Mode;
  #9 Quizzes-tab passes counting on the Ladder (needs per-fact tracking —
  not worth it); NEW: Guide → Steps intro "full pass" → "pass" (Oct 2026:
  the user LIKES "full pass" — leave it, keep this item here); NEW: save
  whether SKIP was on with each pass (closes the Facts Passed Rule ×1/×10 gap).
  NEW (Oct 2026): loosen the miss allowance? (current rule: see "Miss
  allowance" under v44). Decision for now: KEEP it, gather Scores History
  screenshots from parents/siblings, look for fails with only 1-2 misses.
  Why it matters: the rule needs about 100+ questions to tell "knows it
  cold" from "small gaps", and pass/fail depends on question COUNT, not % of
  the pool (mastery-testing research: Millman 1973; Hambleton & Novick 1973;
  sequential stopping: Wald SPRT, Ferguson 1969, Kingsbury & Weiss 1983).
  Chance to PASS by true knowledge 99/97/95/90% (binomial, slips random):
    current 1 per 100:  40q/0 miss 67/30/13/1   100q/1 74/19/4/0   200q/2 68/6/0/0
    1 per 50:           40q/0 miss 67/30/13/1   100q/2 92/42/12/0  200q/4 95/28/3/0
    1 + 1 per 100:      40q/1 miss 94/66/40/8   100q/2 92/42/12/0  200q/3 86/15/1/0
  Trade-off: failing a kid who knows it vs passing a kid with gaps. Current
  rule is strictest. Data gaps to check in code first: a stopped quiz is not
  saved to History, so screenshots undercount slip-fails; confirm History
  shows the miss count and marks a failed Test ALL as failed. (v46: History
  now shows the miss count and Passed / Not passed on pass attempts; the
  stopped-quiz gap is the Maybe bin item below.)
  BUILT v53: stopped Test ALL / Challenge quizzes (fail pop-up Stop or ✕)
  get a "Stopped" Scores History row, kept OUT of the averages (see v53).
  NEW (Oct 2026): Spanish version — maybe. Users would be US and Mexico
  first, then Argentina. Plan if done: one neutral Latin American Spanish
  (tú, US/Mexico long-division layout); Argentine variant (vos, its own
  division layout, "dividido por" vs Mexico's "entre") only if asked for.
  Needs a one-time move of all visible text into per-language files
  (en.js / es.js with whole-sentence templates) + a language picker, and a
  native-speaker check. Full notes: translation-notes.pdf (from chat).
  BUILT v53: "Lose your yellow badges?" adds "Green badges stay."; also
  built v53 from this bin: no 1–20 preset on the Ladder. Range note
  does not mention the extra yellow pill for End 13–19 (leave for now);
  Quizzes: ask each pair in one direction only (3×14 but not 14×3).
- BUILT: "Yellow above 12" — built in v51 (two separate pills, see v51).
- HISTORY ONLY: #3 (Oct 2026: done by Challenge Tests — a Challenge is a
  mixed test for a title level, and a pass gives the title AND every number
  below it, which answers #3's open question); #6, #7, #8 (#7 marked history at v46: its text describes
  "locked" numbers and the "move ladder step here" link, both removed in v43;
  kept for context). Also: the old two-pass Mastery bullet, moved out of
  "Key design points" at v46 (see the v46 changelog entry).

1. **`ladder.currentNumber` split into two independent tracks** —
   highest priority once picked back up. Right now there is a single
   global current-number pointer, so switching between (say) an 11-20
   range and a 1-12/1-20 range makes whichever range was touched LAST
   overwrite the other's progress pointer, even when the other range
   has earlier untouched numbers that should arguably take precedence.
   Confirmed as a real bug via the user's own repro. This is a genuine
   structural change (touches ~6-8 call sites: triangle rendering,
   locked/dimmed calc, "move ladder step here" target, isMasteryAttempt
   check, self-heal effect, results-screen "next number" banner) — the
   user explicitly said not a quick patch, wants to think it through
   fully before it's attempted. UPDATE: the design is now fully settled
   (two independent chain pointers; each shows only if its number is in
   the viewed range; chain B additionally requires ≥1 real mastered
   number in 11-20 before showing at all; visibility is purely rule-
   driven per view, never sticky from whichever range was last touched;
   temp/short-range mastery stays a SINGLE shared pool across both
   chains on purpose — no per-chain temp split; the temp/short-range
   current-step triangle is colored live from the current End setting,
   not from any stored per-number history, so it needs no new state).
   Still NOT built — after walking through a concrete example (numbers
   1 and 13 both mastered, nothing else), the user judged the actual
   real-world impact of the bug fairly minor for confident skip-ahead
   use and wants to use the app more before deciding whether to spend
   the ~6-8-call-site effort. Explicitly wants the ability to revert
   cleanly if it's built and turns out to break something — keep the
   pre-change version easy to restore, don't build this as a one-way
   door.
2. **King's "huge fancy crown"** — the current double-size Crown icon
   at 20 is an explicit stand-in until a distinct, fancier design is
   made.
3. **Comprehensive/mixed test as an alternate path to any milestone**
   — open design question, not just for King at 20: would a
   comprehensive-test pass also retroactively grant individual
   numbers' green stars on the grid, or just the title?
4. **Fast Mode** (a variable-speed quiz mode with more granularity
   than the current 3-way Speed section) — still a separate,
   not-yet-built idea; unrelated to the Speed section's "Fast"/"Fastest"
   buttons already shipped.
5. **Words Used / FAQ tabs on the Guide page** — deliberately stubbed
   out; `GUIDE_TABS` is structured so adding them later is just new
   array entries plus a render branch, not a restructure. One piece of
   content is already drafted and waiting for this to get built —
   NOT a Q&A/FAQ-style entry, just plain info text (explicitly
   requested as such, not framed as a question):
   > Average answer time only counts first attempts, not repeats.
   > Repeats are usually answered faster since the fact was just seen
   > seconds earlier — including them would blend "knows it cold" with
   > "can echo it right after seeing it," making the average less
   > meaningful. The separate total time stat does include repeats,
   > since it's meant to reflect actual time spent, not recall speed.
6. ~~**Non-qualifying-range history log**~~ — DECLINED. User confirmed no, not wanted.
7. **[HISTORY ONLY since v46 — describes removed features]** **The "small range still counts toward mastery" gap** — SETTLED, permanently: leave standalone mastery as-is, no gating on lower numbers required. Also confirmed as a related, already-true behavior (not a gap needing a fix): an already-mastered number stays clickable for re-testing (only numbers *ahead* of the current step are ever locked), and `ladder.mastered` is append-only everywhere in the code — no path removes a number from it, so re-testing can never cost you a status you already have. For reference, what this was about: mastery-granting code only checks `mode===type-random && number===currentNumber`; it never enforces or warns about range size. This is NOT about partner-fact coverage within a single number's quiz — that's already always 1/2-to-End for every pass, and whether that's real vs. temp is already fully governed by `isCanonicalEnd`, so a range going up to 15 already correctly gets temp/yellow, not a false real pass. The actual point: jumping straight to an isolated number at a canonical End (e.g. "move ladder step here" to 12, mastering only 12) grants full real, permanent credit for that number alone, having never separately attempted the numbers before it — and that's fine, by design, going forward. Titles are unaffected either way (they already require no gaps below them, per the Levels intro's "first gap sets your title" rule — a separate, already-correct mechanic).
8. ~~**Possible bug: "Repeating" showing up in Choose (multiple choice)
   mode**~~ — RESOLVED, not a bug. The repeat-scheduling redesign (see
   "Repeat-scheduling logic" under Speed section above) made Choose-mode
   wrong answers immediate too, same as Type In — so "Repeating" in
   Choose mode is now correct, expected behavior.
9. **Quizzes-tab passes counting toward Ladder mastery** — open design
   question: should an ordinary Quizzes-tab quiz (not just a Challenge
   Test or the Ladder itself) be able to grant mastery credit? Raised,
   discussed, then parked as a future maybe rather than pursued now —
   felt like a lot of interacting rules to track (Quizzes' own
   start/end/exclude-easy vs. Ladder's per-number partner coverage) for
   an already-solved need, now that Challenge Tests (see the dedicated
   section above) cover "test straight through to a milestone without
   grinding the Ladder number-by-number." Related to item 3 above,
   which Challenge Tests may have already substantially answered.
10. **The King Test** (future, design notes, not built). Definition: the
   test after the 20s are passed and before the King title is awarded —
   an EXTRA requirement for King, not a shortcut (differs from item 3's
   "alternate path"). Notes so far:
   - Random sample, not every question. Split into 2 tests: (1) anything
     with a number 1–10 (1–10 × 1–20: 155 multiply facts / 455 with
     divides) and (2) 11–20 × 11–20 (55 / 155). 1–10 × 1–10 must be in it
     because the 11–20 path (for people who learned 1–10 but not 11–20)
     never passes 1–10. Same question count for both despite pool sizes.
   - "Work on" list from the misses (numbers), even on a pass.
   - Per-question time limits by answer length, first approximation:
     1 digit 3 s, 2 digits 3.5 s, 3 digits 4 s (research: ~2–3 s is the
     usual "from memory" fluency benchmark; typing time not well studied).
     Teacher adjustment should shift all three by the same amount.
   - Timing rule: fails if more than 10% of answers are slow; any answer
     over 2× its limit counts as a miss (people are inconsistent on timing).
   - Misses: 1 per full 100 questions (built in v44 for pass attempts).
   - Possible later: measure each kid's own typing speed with a short
     warm-up and set limits from it (Rocket Math idea).

## Passcode / user data compatibility note

`localStorage` keys are unchanged since the very first version
(`times-tables-users-v1`, `times-tables-state-v1:<user>`,
`times-tables-log-v1:<user>`, `times-tables-mastery-v1:<user>`,
`tt_unlocked`) — real user data depends on these never being renamed.
